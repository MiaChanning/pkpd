from pathlib import Path
import sys,unittest,tempfile,json,copy
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from interfaces import ConcentrationBoundary,EvidenceGap,load_measured_input
from transport import TransportParameters,simulate,observation
from pd import ReadoutParameters,simulate_readout

def fixture():
    # Pure numerical coordinates, not a candidate physiological configuration.
    return TransportParameters(1,2,3,[.2,.3],[.1,.2],[.4,.3],[.4,.5],[.1,.2],[1,1],[.2,.3],[.4,.5],[0,0],0,0,0)
def boundary(c=1):return ConcentrationBoundary([0,.5,2],[[c,c]]*3,analytes=['free_parent_SFN','free_parent_NAC'],origin='synthetic_numerical_test',role='internal_test')
def pd_fixture():return ReadoutParameters('GSH_total','numerical fixture','arbitrary readout','software test only',1,.5,2,.3,.4,.2,1)

class InputChecks(unittest.TestCase):
    def test_piecewise_linear_no_extrapolation(self):
        b=ConcentrationBoundary([0,1,2],[[0,0],[2,4],[0,0]],analytes=['free_parent_SFN','free_parent_NAC'],origin='fixture')
        np.testing.assert_allclose(b(.5),[1,2]);np.testing.assert_allclose(b.integral(),[2,4])
        with self.assertRaises(EvidenceGap):b(2.01)
    def test_duplicates_and_negative_rejected(self):
        for t,c in [([0,0],[[1,1],[2,2]]),([0,1],[[-1,1],[2,2]])]:
            with self.assertRaises(ValueError):ConcentrationBoundary(t,c,analytes=['free_parent_SFN','free_parent_NAC'],origin='fixture')
    def test_total_signal_rejected(self):
        with self.assertRaises(EvidenceGap):ConcentrationBoundary([0,1],[[1,1],[1,1]],analytes=['recoverable_SFN','total_thiol'],origin='fixture')
    def test_nonfinite_rejected(self):
        with self.assertRaises(EvidenceGap):ConcentrationBoundary([0,1],[[np.nan,1],[1,1]],analytes=['free_parent_SFN','free_parent_NAC'],origin='fixture')
    def test_missing_metadata_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d);(p/'m.json').write_text('{}')
            with self.assertRaises(EvidenceGap):load_measured_input(p/'data.csv',p/'m.json')

class TransportChecks(unittest.TestCase):
    def test_open_supply_ledger_and_input_integral(self):
        p=fixture();r=simulate(boundary(),p,mode='external_concentration',start=0,end=2)
        self.assertLess(np.abs(r['ledger']).max(),1e-9)
        np.testing.assert_allclose(r['amounts'][11:13,-1],[.4,.6],atol=1e-9)
        self.assertEqual(r['amounts'][:3].max(),0)
    def test_external_no_duplicate_chemistry(self):
        p=fixture();p=TransportParameters(**{**p.__dict__,'kf':1})
        with self.assertRaises(EvidenceGap):simulate(boundary(),p,mode='external_concentration',start=0,end=2)
    def test_finite_supply_and_reversible_conjugation(self):
        p=fixture();p=TransportParameters(**{**p.__dict__,'kf':4,'kr':.2,'k_nasal_loss':[.1,.2],'k_conjugate_loss':.1})
        r=simulate(None,p,mode='finite_supply',start=0,end=2,source=lambda t:[.1,.2],initial_nasal=[1,2,.3])
        self.assertLess(np.abs(r['ledger']).max(),1e-8);self.assertGreaterEqual(r['amounts'].min(),-1e-9)
        self.assertLessEqual(r['amounts'][11,-1],.200000001)
    def test_closed_conjugation_equivalents(self):
        q=fixture().__dict__;q.update(PS_ep=[0,0],CL_brain=[0,0],CL_plasma=[0,0],PS_pb=[0,0],kf=2,kr=.3)
        r=simulate(None,TransportParameters(**q),mode='finite_supply',start=0,end=2,source=lambda t:[0,0],initial_nasal=[1,2,0])
        np.testing.assert_allclose(r['amounts'][0]+r['amounts'][2],1,atol=1e-9)
        np.testing.assert_allclose(r['amounts'][1]+r['amounts'][2],2,atol=1e-9)
    def test_no_fixed_and_finite_donor_combination(self):
        with self.assertRaises(ValueError):simulate(boundary(),fixture(),mode='finite_supply',start=0,end=2,source=lambda t:[0,0],initial_nasal=[0,0,0])
    def test_zero_input(self):
        r=simulate(boundary(0),fixture(),mode='external_concentration',start=0,end=2)
        self.assertEqual(r['amounts'].max(),0)
    def test_zero_direct_systemic_can_still_deliver(self):
        p=TransportParameters(**{**fixture().__dict__,'f_direct':[0,0]})
        r=simulate(boundary(),p,mode='external_concentration',start=0,end=2)
        self.assertEqual(r['amounts'][3:5].max(),0);self.assertGreater(r['brain_free_uM'].max(),0)
    def test_all_brain_paths_zero(self):
        p=TransportParameters(**{**fixture().__dict__,'f_direct':[0,0],'PS_pb':[0,0]})
        r=simulate(boundary(),p,mode='external_concentration',start=0,end=2)
        self.assertEqual(r['brain_free_uM'].max(),0)
    def test_unknowns_rejected(self):
        p=TransportParameters(**{**fixture().__dict__,'PS_ep':[None,None]})
        with self.assertRaises(EvidenceGap):p.validate()
    def test_observation_identity(self):
        with self.assertRaises(EvidenceGap):observation({},'total14C')
    def test_fraction_constraints(self):
        p=TransportParameters(**{**fixture().__dict__,'f_direct':[1,1]})
        with self.assertRaises(ValueError):p.validate()
    def test_reference_and_step_convergence(self):
        args=dict(mode='external_concentration',start=0,end=2)
        a=simulate(boundary(),fixture(),**args,max_step=.1);b=simulate(boundary(),fixture(),**args,max_step=.01);c=simulate(boundary(),fixture(),**args,method='Radau')
        np.testing.assert_allclose(a['amounts'],b['amounts'],atol=1e-8,rtol=1e-6);np.testing.assert_allclose(a['amounts'],c['amounts'],atol=1e-8,rtol=1e-6)
    def test_delay_analytic_constant_input(self):
        p=fixture();r=simulate(boundary(),p,mode='external_concentration',start=0,end=2)
        np.testing.assert_allclose(r['amounts'][3],p.f_direct[0]*p.PS_ep[0]*p.tau_direct[0]*(1-np.exp(-r['time_h']/p.tau_direct[0])),atol=1e-9)

class PDChecks(unittest.TestCase):
    def test_no_drug_baseline(self):
        t=np.linspace(0,4,101);r=simulate_readout(t,np.zeros_like(t),pd_fixture())
        np.testing.assert_allclose(r['observed_readout'],1,atol=1e-10)
    def test_washout_recovery(self):
        t=np.linspace(0,12,601);c=np.where(t<1,5,0);r=simulate_readout(t,c,pd_fixture())
        self.assertGreater(r['observed_readout'].max(),1);self.assertLess(abs(r['observed_readout'][-1]-1),1e-8)
    def test_effect_site_analytic(self):
        t=np.linspace(0,3,121);p=pd_fixture();r=simulate_readout(t,np.ones_like(t)*2,p)
        np.testing.assert_allclose(r['effective_uM'],.8*(1-np.exp(-t/.2)),atol=1e-9)
    def test_static_marker_not_flux(self):
        p=ReadoutParameters(**{**pd_fixture().__dict__,'name':'autophagic_flux'})
        with self.assertRaises(EvidenceGap):p.validate()
    def test_unconstrained_pd_rejected(self):
        p=ReadoutParameters(**{**pd_fixture().__dict__,'EC50_uM':None})
        with self.assertRaises(EvidenceGap):p.validate()
    def test_inhibition_nonnegative(self):
        p=ReadoutParameters(**{**pd_fixture().__dict__,'name':'Notch1_total','direction':-1,'max_fraction_change':.9})
        r=simulate_readout(np.linspace(0,4,101),np.ones(101)*100,p)
        self.assertGreaterEqual(r['observed_readout'].min(),.1)

if __name__=='__main__':unittest.main(verbosity=2)
