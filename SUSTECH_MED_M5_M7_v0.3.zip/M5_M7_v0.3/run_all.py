"""Offline evidence/data rebuild; missing project data is an explicit status, not a fake run."""
from pathlib import Path
import subprocess,sys,os,json,hashlib,platform
ROOT=Path(__file__).resolve().parent
os.environ['PYTHONUTF8']='1'
def main():
    for d in ['tables','configs','literature_data','figures','input_templates','reference_v02']:(ROOT/d).mkdir(exist_ok=True)
    result=subprocess.run([sys.executable,'-m','unittest','discover','-s','tests','-v'],cwd=ROOT,capture_output=True,text=True,encoding='utf8')
    (ROOT/'tables/test_log.txt').write_text(result.stdout+result.stderr,encoding='utf8')
    print(result.stdout+result.stderr)
    if result.returncode:raise SystemExit(result.returncode)
    for script in ['scripts/build_project.py','scripts/make_figures.py']:
        r=subprocess.run([sys.executable,str(ROOT/script)],cwd=ROOT,capture_output=True,text=True,encoding='utf8')
        print(script,r.stdout)
        if r.returncode:print(r.stderr);raise SystemExit(r.returncode)
    import numpy,scipy,matplotlib
    (ROOT/'requirements-lock.txt').write_text(f'numpy=={numpy.__version__}\nscipy=={scipy.__version__}\nmatplotlib=={matplotlib.__version__}\n',encoding='utf8')
    (ROOT/'tables/environment.json').write_text(json.dumps(dict(python=sys.version,platform=platform.platform()),indent=2),encoding='utf8')
    manifest=[dict(path=p.relative_to(ROOT).as_posix(),sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in sorted(ROOT.rglob('*')) if p.is_file() and '__pycache__' not in p.parts and p.name!='file_manifest.json']
    (ROOT/'file_manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf8')
    print('Completed evidence and literature mode. Project prediction: evidence insufficient, not executed.')
if __name__=='__main__':main()
