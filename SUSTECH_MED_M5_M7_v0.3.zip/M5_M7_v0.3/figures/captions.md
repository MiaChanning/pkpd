# Figure captions v0.3

## Figure 1

Mechanism audit distinguishes parallel direct/systemic transport and two separately evidenced PD branches. Dashed arrows denote unquantified project-setting links, not a required anatomical chain. Sources Son2021/Kurano2022/Shen2025/Danilov2009/Zhang2023/Reyes2016/Townsend2016; no axis for diagram. Parameter/data version: v0.3; frozen original-study PK coefficients in configs/literature_frozen.json, dataset roles in validation_registry.csv, sources in references.bib.

## Figure 2

Computational contract: external measured concentration and finite donor are mutually exclusive. Effective delay and brain-side clearance are implemented; PD requires assay-specific calibration. All target coefficients remain in configs/project_unparameterized.json; no physiological prediction. Parameter/data version: v0.3; frozen original-study PK coefficients in configs/literature_frozen.json, dataset roles in validation_registry.csv, sources in references.bib.

## Figure 3

Missing-input audit; the user confirmed experiments ongoing. No measured time series exists in the inspected workspace. Figure is status information, not a fabricated curve. Parameter/data version: v0.3; frozen original-study PK coefficients in configs/literature_frozen.json, dataset roles in validation_registry.csv, sources in references.bib.

## Figure 4

Frozen Son2021 parent SFN oral high-dose late-point failure and Kurano2022 plasma total14C formulation holdout. Son time label conflict preserved; Kurano errors are approximately digitized SE. Curves are study-specific and cannot parameterize intact-parent nasal/brain exposure. Parameter/data version: v0.3; frozen original-study PK coefficients in configs/literature_frozen.json, dataset roles in validation_registry.csv, sources in references.bib.

## Figure 5

Published means and SEM, exactly transcribed (not fitted curves). Rat astrocyte SFN post-treatment differs from 5uM pretreatment. Mouse slice NAC GSH readout is total glutathione per protein. The studies are separate; no cross-study causal network or EC50 inferred. Parameter/data version: v0.3; frozen original-study PK coefficients in configs/literature_frozen.json, dataset roles in validation_registry.csv, sources in references.bib.

## Figure 6

Protein endpoint directions in Zhang2023. NICD was measured in cells and is separated from total Notch1. Static LC3/p62 abundance cannot quantify autophagic flux. Source figures could not be downloaded for reliable magnitude digitization; no magnitude/error is invented. Parameter/data version: v0.3; frozen original-study PK coefficients in configs/literature_frozen.json, dataset roles in validation_registry.csv, sources in references.bib.

## Figure 7

New implementation internal checks use isolated test-only coordinates. Ledger residuals and count of tests are numerical evidence; no biological parameter has been identified from these runs. Parameter/data version: v0.3; frozen original-study PK coefficients in configs/literature_frozen.json, dataset roles in validation_registry.csv, sources in references.bib.

## Figure 8

Every readable SFN late point and every Kurano held-out time point included. The 10fold screen is permissive and not a general accuracy criterion. Observed approximate SE distances do not include full parameter and time covariance. Parameter/data version: v0.3; frozen original-study PK coefficients in configs/literature_frozen.json, dataset roles in validation_registry.csv, sources in references.bib.