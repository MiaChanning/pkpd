# Results: numerical checks and retained evidence gaps

All 24 staged-interface and numerical tests passed, including finite/open supply ledgers, conjugate equivalents, parallel-route zero controls, analytic delay, effect-site kinetics, washout recovery and solver comparisons. These are software checks using isolated fixtures, not evidence of target-setting biological efficacy.

For the retrospective held-out Kurano2022 micelle group, the frozen plasma total-carbon-14 model had log10-RMSE 0.071 and maximum fold discrepancy 1.27. A stricter approximate two-SE requirement was not met at every point. The frozen Son2021 high-dose oral SFN late tail failed the permissive ten-fold screen (maximum absolute log10 discrepancy 9.36); no parameters were adjusted to hide this failure.

Published antioxidant and Notch/autophagy measurements were organized by assay and condition. Single-dose endpoints were not used to fit EC50, maximal effect and multiple time constants. Zhang2023 includes a NICD measurement, while its static autophagy markers do not quantify autophagic flux. The NAC CSF bridge remains distinct from intracellular free concentration.

The team's experiments are ongoing and no measured input was available. Project prediction and PD calibration have therefore not been executed. No matched independent external validation or ASD clinical claim is made. The next authorized step is to ingest the existing planned concentration measurements with complete assay and sampling metadata and freeze only supportable parameters.
