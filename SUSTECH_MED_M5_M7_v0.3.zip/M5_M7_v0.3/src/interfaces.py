"""Read-only measured-input contract. No extrapolation, source reconstruction or BQL imputation."""
from pathlib import Path
import csv,json,hashlib
import numpy as np

class EvidenceGap(ValueError):pass

class ConcentrationBoundary:
    def __init__(self,time_h,values_uM,*,analytes,origin,role='project_input'):
        self.t=np.asarray(time_h,dtype=float);self.c=np.asarray(values_uM,dtype=float)
        if self.t.ndim!=1 or len(self.t)<2 or self.c.shape!=(len(self.t),2):raise ValueError('At least two paired SFN/NAC times required')
        if not np.isfinite(self.t).all() or not np.isfinite(self.c).all():raise EvidenceGap('Missing, censored or nonfinite values require explicit handling')
        if np.any(np.diff(self.t)<=0) or np.any(self.c<0):raise ValueError('Times must increase; concentrations must be nonnegative')
        if analytes!=['free_parent_SFN','free_parent_NAC']:raise EvidenceGap('Transport needs free-parent-specific input; no assumed conversion from total signal')
        self.analytes=analytes;self.origin=origin;self.role=role
    def __call__(self,t):
        if t<self.t[0]-1e-10 or t>self.t[-1]+1e-10:raise EvidenceGap('Input extrapolation is not permitted')
        return np.array([np.interp(t,self.t,self.c[:,j]) for j in range(2)])
    def integral(self):return np.trapezoid(self.c,self.t,axis=0)

def load_measured_input(csv_path,metadata_path):
    path=Path(csv_path);meta=json.loads(Path(metadata_path).read_text(encoding='utf8'))
    required=['dataset_id','matrix','culture_mode','analytes','concentration_unit','time_unit','culture_volume_mL',
              'sampling_scheme','assay','replicates','sterile_control','stability_control','precursors',
              'initial_added_drug','background_subtraction','LOD','LLOQ','recovery','input_mode']
    missing=[k for k in required if k not in meta or meta[k] is None]
    if missing:raise EvidenceGap('Input metadata unresolved: '+', '.join(missing))
    if meta['input_mode']!='external_concentration':raise EvidenceGap('This loader supplies concentration boundaries, not replenishment rates')
    if meta['culture_volume_mL']<=0:raise ValueError('Positive culture volume required')
    if meta['concentration_unit'] not in ['uM','nmol/mL'] or meta['time_unit']!='h':raise EvidenceGap('Provide explicitly converted uM and hour data; no silent conversion')
    with path.open(encoding='utf-8-sig',newline='') as f:rows=list(csv.DictReader(f))
    if not rows:raise EvidenceGap('No project measurements supplied')
    if any(row.get('qualifier') not in ['quantified'] for row in rows):raise EvidenceGap('BQL/missing values cannot be replaced by zero or LLOQ/2')
    # Replicates must be handled explicitly upstream; no silent pooling or duplicate-time averaging.
    boundary=ConcentrationBoundary([float(r['time_h']) for r in rows],[[float(r['SFN_free_uM']),float(r['NAC_free_uM'])] for r in rows],
          analytes=meta['analytes'],origin=meta['dataset_id'])
    meta['raw_sha256']=hashlib.sha256(path.read_bytes()).hexdigest()
    return boundary,meta
