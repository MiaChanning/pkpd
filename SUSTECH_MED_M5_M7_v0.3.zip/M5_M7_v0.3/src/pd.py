"""Endpoint-specific response and effect-site filters, never relabelled as a network.

Each assay/readout requires its own calibrated record. GSH synthesis is an
effective response here, not NAC -> GSH stoichiometry. Static LC3/p62 output
is abundance only; no autophagic flux can be inferred.
"""
from dataclasses import dataclass
import numpy as np
from scipy.integrate import solve_ivp
from interfaces import EvidenceGap

@dataclass(frozen=True)
class ReadoutParameters:
    name:str;assay:str;unit:str;study_context:str
    baseline:float;max_fraction_change:float;EC50_uM:float;tau_response_h:float
    effective_fraction:float;tau_effect_h:float;direction:int
    hill:float=1.0  # structural choice; never fitted from a single endpoint
    def validate(self):
        if any(not isinstance(s,str) or not s.strip() for s in [self.name,self.assay,self.unit,self.study_context]):raise EvidenceGap('Each readout needs an assay, unit and matching context')
        vals=[self.baseline,self.max_fraction_change,self.EC50_uM,self.tau_response_h,self.effective_fraction,self.tau_effect_h,self.hill]
        if any(v is None for v in vals):raise EvidenceGap(self.name+': insufficient identifiable PD/observation parameters')
        if not np.isfinite(vals).all() or min(vals)<0:raise ValueError('Finite nonnegative PD values required')
        if min(self.EC50_uM,self.tau_response_h,self.tau_effect_h,self.hill)<=0 or not 0<=self.effective_fraction<=1:raise ValueError('Invalid effect-site filter')
        if self.direction not in [-1,1] or self.direction==-1 and self.max_fraction_change>1:raise ValueError('Inhibitory change cannot exceed baseline')
        if self.name=='autophagic_flux':raise EvidenceGap('LC3/p62 static data cannot parameterize autophagic flux')

def simulate_readout(time_h,exposure_uM,p,*,method='DOP853',max_step=.02):
    p.validate();t=np.asarray(time_h);c=np.asarray(exposure_uM)
    if t.ndim!=1 or c.shape!=t.shape or len(t)<2 or np.any(np.diff(t)<=0) or c.min()<0 or not np.isfinite(c).all() or not np.isfinite(t).all():raise ValueError('Invalid exposure input')
    def rhs(s,y):
        ce=y[0];cdriver=np.interp(s,t,c)
        h=ce**p.hill/(p.EC50_uM**p.hill+ce**p.hill)
        target=p.baseline*(1+p.direction*p.max_fraction_change*h)
        return [(p.effective_fraction*cdriver-ce)/p.tau_effect_h,(target-y[1])/p.tau_response_h]
    result=solve_ivp(rhs,(t[0],t[-1]),[0,p.baseline],t_eval=t,method=method,max_step=max_step,rtol=1e-9,atol=1e-11)
    if not result.success or result.y.min()<-1e-8:raise RuntimeError('PD integration failed')
    return dict(time_h=t,effective_uM=result.y[0],observed_readout=result.y[1],name=p.name,assay=p.assay,unit=p.unit,
                interpretation='assay-specific effective response; no causal network or clinical score')

def inference_boundary(name):
    return {'Notch1_total':'protein abundance, not NICD or receptor activity',
            'Hes1_protein':'protein abundance, not Hes1 transcript',
            'LC3B_II_I':'static ratio, not autophagy formation/degradation flux',
            'p62_protein':'static abundance with synthesis and degradation confounding',
            'GSH_total':'effective intracellular glutathione readout; not total antioxidants',
            'IL6_mRNA':'qPCR expression, not secreted IL6 protein'}.get(name,'Use exact assay mapping')
