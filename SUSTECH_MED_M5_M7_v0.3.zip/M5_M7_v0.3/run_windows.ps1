param([string]$PythonPath='')
$ErrorActionPreference='Stop'
$env:PYTHONUTF8='1'
if (-not $PythonPath) {
    $venvPython=Join-Path $PSScriptRoot '.venv\Scripts\python.exe'
    $bundledPython=Join-Path $env:USERPROFILE '.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe'
    if (Test-Path -LiteralPath $venvPython) { $PythonPath=$venvPython }
    elseif (Get-Command python -ErrorAction SilentlyContinue) { $PythonPath=(Get-Command python).Source }
    elseif (Test-Path -LiteralPath $bundledPython) { $PythonPath=$bundledPython }
    else { throw 'Pass -PythonPath with a Python executable.' }
}
$localDeps=Join-Path (Split-Path $PSScriptRoot -Parent) 'python_deps'
if (Test-Path -LiteralPath $localDeps) { $env:PYTHONPATH=$localDeps+[IO.Path]::PathSeparator+$env:PYTHONPATH }
& $PythonPath (Join-Path $PSScriptRoot 'run_all.py')
if ($LASTEXITCODE -ne 0) { throw 'Build failed; inspect the original error. Install locked requirements in a project .venv if necessary.' }
