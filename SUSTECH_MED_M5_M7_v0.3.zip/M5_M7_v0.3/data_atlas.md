# 全部应用数据与角色

| dataset_id | file | reference | purpose | variable | extraction | source_location | original_source_files | processing_code | uncertainty | comparison_level | limitations |
|---|---|---|---|---|---|---|---|---|---|---|---|
| Son2021_calibration | literature_data/Son2021_calibration.csv | Son2021 | calibration | rat plasma parent SFN IV/PO | exact text/table or qualitative observation definition | Table1, IV and PO0.1mg/kg | sources/Son2021.txt;sources/Son2021.xml;sources/Son2021_metadata.json | scripts/build_project.py; legacy pixels: reference_v02/scripts/extract_data.py | SD/SEM/pixel fields retained in data; absence not imputed | within-study retrospective | original study only |
| Son2021_IV_digitized | literature_data/Son2021_IV_digitized.csv | Son2021 | same-study reproduction | parent SFN | digitized means | Fig8a | sources/Son2021.txt;sources/Son2021.xml;sources/Son2021_metadata.json | scripts/build_project.py; legacy pixels: reference_v02/scripts/extract_data.py | SD/SEM/pixel fields retained in data; absence not imputed | within-study retrospective | time h/min conflict; not independent |
| Son2021_PO05_digitized | literature_data/Son2021_PO05_digitized.csv | Son2021 | retrospective same-study heldout subset | parent SFN | digitized means | Fig8b late subset | sources/Son2021.txt;sources/Son2021.xml;sources/Son2021_metadata.json | scripts/build_project.py; legacy pixels: reference_v02/scripts/extract_data.py | SD/SEM/pixel fields retained in data; absence not imputed | within-study retrospective | 4 early unreadable points; late failure retained |
| Kurano2022_free_NAC | literature_data/Kurano2022_free_NAC.csv | Kurano2022 | calibration | plasma total14C | digitized means | Fig2A open circles | sources/Kurano2022.txt;sources/Kurano2022.xml;sources/Kurano2022_metadata.json | scripts/build_project.py; legacy pixels: reference_v02/scripts/extract_data.py | SD/SEM/pixel fields retained in data; absence not imputed | within-study retrospective | not intact NAC or brain ECF |
| Kurano2022_micelle | literature_data/Kurano2022_micelle.csv | Kurano2022 | retrospective same-study heldout formulation | plasma total14C | digitized means | Fig2A closed circles | sources/Kurano2022.txt;sources/Kurano2022.xml;sources/Kurano2022_metadata.json | scripts/build_project.py; legacy pixels: reference_v02/scripts/extract_data.py | SD/SEM/pixel fields retained in data; absence not imputed | within-study retrospective | formulation mismatch; not independent |
| Son2021_stability_summaries | literature_data/Son2021_stability_summaries.csv | Son2021 | context and tautological summary reproduction | plasma disappearance half-lives | exact text/table or qualitative observation definition | Results3.2.1, Fig5 | sources/Son2021.txt;sources/Son2021.xml;sources/Son2021_metadata.json | scripts/build_project.py; legacy pixels: reference_v02/scripts/extract_data.py | SD/SEM/pixel fields retained in data; absence not imputed | within-study retrospective | no curve-level test; not nasal chemistry |
| human_SAS_constraints | literature_data/human_SAS_constraints.csv | Zolnourian2025 | left-censored plausibility context not scored | SFN/conjugate plasma/CSF | exact text/table or qualitative observation definition | CSF Results and Fig3 LLOQ caption | sources/Zolnourian2025_v02.html;sources/Zolnourian2025_v02.txt | scripts/build_project.py; legacy pixels: reference_v02/scripts/extract_data.py | SD/SEM/pixel fields retained in data; absence not imputed | context_only | oral/NG, no matched transport simulation |
| Danilov2009_Fig6_text | literature_data/Danilov2009_Fig6_text.csv | Danilov2009 | PD context only | cell death percent | exact text/table or qualitative observation definition | Results C, Fig6 | sources/Danilov2009_metadata.json;sources/Danilov2009_v02.html;sources/Danilov2009_v02.txt | scripts/build_project.py; legacy pixels: reference_v02/scripts/extract_data.py | SD/SEM/pixel fields retained in data; absence not imputed | context_only | single dose/time, no Hill fit |
| NAC_slice2026_Table2 | literature_data/NAC_slice2026_Table2.csv | NAC_slice2026 | PD context only | slice total GSH nmol/mg protein | exact text/table or qualitative observation definition | Table2 | sources/NAC_slice2026.raw | scripts/build_project.py; legacy pixels: reference_v02/scripts/extract_data.py | SD/SEM/pixel fields retained in data; absence not imputed | context_only | single time, differing doses not a transport bridge |
| Reyes2016_CSF_text | literature_data/Reyes2016_CSF_text.csv | Reyes2016 | PK/PD bridge context only | CSF total/reduced NAC | exact text/table or qualitative observation definition | CSF Results, Fig6A/Fig6E | sources/Reyes2016.txt;sources/Reyes2016_springer.raw | scripts/build_project.py; legacy pixels: reference_v02/scripts/extract_data.py | SD/SEM/pixel fields retained in data; absence not imputed | context_only | human Fig6E is reused original dataset, not independent duplication |
| Zhang2023_observation_definitions | literature_data/Zhang2023_observation_definitions.csv | Zhang2023 | protocol and direction only | Notch/NICD/Hes/LC3/p62 WB | exact text/table or qualitative observation definition | Fig7 and Fig8 caption/results | sources/Zhang2023_metadata.json;sources/Zhang2023_v02.html;sources/Zhang2023_v02.txt | scripts/build_project.py; legacy pixels: reference_v02/scripts/extract_data.py | SD/SEM/pixel fields retained in data; absence not imputed | context_only | no numerical means digitized; not calibrated |
| PD_exposure_contexts | literature_data/PD_exposure_contexts.csv | Danilov2009;Zhang2023 | nominal exposure context | culture bath dose | exact text/table or qualitative observation definition | cell-treatment methods | sources/Zhang2023_metadata.json;sources/Zhang2023_v02.html;sources/Zhang2023_v02.txt;sources/Danilov2009_metadata.json;sources/Danilov2009_v02.html;sources/Danilov2009_v02.txt | scripts/build_project.py; legacy pixels: reference_v02/scripts/extract_data.py | SD/SEM/pixel fields retained in data; absence not imputed | context_only | not EC50 or brain threshold |

## Son2021_calibration

| route | dose_mg_kg | AUC_last_ug_min_mL | AUC_last_SD | AUC_inf_ug_min_mL | AUC_inf_SD | half_life_min | half_life_SD | Cmax_ug_mL | Cmax_SD | Tmax_min | Tmax_SD | reported_F_percent | CL_mL_min_kg | Vss_mL_kg |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| IV | 0.1 | 2.35 | 0.154 | 2.47 | 0.205 | 61.3 | 36.2 |  |  |  |  | 0 | 40.7 | 2268 |
| PO | 0.1 | 1.85 | 0.377 | 1.92 | 0.411 | 41.9 | 7.6 | 0.036 | 0.01 | 15 | 0 | 77.8 |  |  |

## Son2021_IV_digitized

| time_min | value_ng_mL | pixel_x | pixel_y | pixel_log10_uncertainty | analyte | extraction | purpose |
|---|---|---|---|---|---|---|---|
| 1 | 105.0211079636667 | 83 | 81 | 0.06382978723404255 | parent SFN by LC-MS/MS | digitized_manual | reproduction_same_study_not_independent |
| 5 | 58.33879397552119 | 88 | 93 | 0.06382978723404255 | parent SFN by LC-MS/MS | digitized_manual | reproduction_same_study_not_independent |
| 15 | 34.034148825183074 | 99 | 104 | 0.06382978723404255 | parent SFN by LC-MS/MS | digitized_manual | reproduction_same_study_not_independent |
| 30 | 22.9986385396121 | 117 | 112 | 0.06382978723404255 | parent SFN by LC-MS/MS | digitized_manual | reproduction_same_study_not_independent |
| 45 | 14.090816855117318 | 134 | 122 | 0.06382978723404255 | parent SFN by LC-MS/MS | digitized_manual | reproduction_same_study_not_independent |
| 60 | 9.521895354084075 | 151 | 130 | 0.06382978723404255 | parent SFN by LC-MS/MS | digitized_manual | reproduction_same_study_not_independent |
| 120 | 2.5366194557577995 | 220 | 157 | 0.06382978723404255 | parent SFN by LC-MS/MS | digitized_manual | reproduction_same_study_not_independent |
| 180 | 1.6321721285632753 | 289 | 166 | 0.06382978723404255 | parent SFN by LC-MS/MS | digitized_manual | reproduction_same_study_not_independent |
| 240 | 1.2775649214671143 | 358 | 171 | 0.06382978723404255 | parent SFN by LC-MS/MS | digitized_manual | reproduction_same_study_not_independent |

## Son2021_PO05_digitized

| time_min | value_ng_mL | pixel_x | pixel_y | pixel_log10_uncertainty | analyte | extraction | purpose |
|---|---|---|---|---|---|---|---|
| 15 |  |  |  | 0.061855670103092786 | parent SFN by LC-MS/MS | unresolved_marker_overlap | heldout_condition_subset_not_whole_curve |
| 30 |  |  |  | 0.061855670103092786 | parent SFN by LC-MS/MS | unresolved_marker_overlap | heldout_condition_subset_not_whole_curve |
| 45 |  |  |  | 0.061855670103092786 | parent SFN by LC-MS/MS | unresolved_marker_overlap | heldout_condition_subset_not_whole_curve |
| 60 |  |  |  | 0.061855670103092786 | parent SFN by LC-MS/MS | unresolved_marker_overlap | heldout_condition_subset_not_whole_curve |
| 120 | 63.69769416995303 | 508 | 85 | 0.061855670103092786 | parent SFN by LC-MS/MS | digitized_manual | heldout_condition_subset_not_whole_curve |
| 180 | 45.68712340164291 | 520 | 92 | 0.061855670103092786 | parent SFN by LC-MS/MS | digitized_manual | heldout_condition_subset_not_whole_curve |
| 240 | 29.800723235589526 | 532 | 101 | 0.061855670103092786 | parent SFN by LC-MS/MS | digitized_manual | heldout_condition_subset_not_whole_curve |
| 480 | 13.942154687651545 | 579 | 117 | 0.061855670103092786 | parent SFN by LC-MS/MS | digitized_manual | heldout_condition_subset_not_whole_curve |
| 1440 | 2.646551883316156 | 770 | 152 | 0.061855670103092786 | parent SFN by LC-MS/MS | digitized_manual | heldout_condition_subset_not_whole_curve |

## Kurano2022_free_NAC

| dataset | group | time_min | value | SE_approx | pixel_uncertainty | unit | analyte | pixel_x | pixel_y | extraction | purpose |
|---|---|---|---|---|---|---|---|---|---|---|---|
| Kurano2022_Fig2A | free_NAC | 0 | 1.569767441860465 | 0.09966777408637874 | 0.024916943521594685 | %ID/mL plasma | total 14C signal; not intact NAC | 92 | 154 | digitized_manual | calibration |
| Kurano2022_Fig2A | free_NAC | 3 | 1.43687707641196 | 0.1287375415282392 | 0.024916943521594685 | %ID/mL plasma | total 14C signal; not intact NAC | 102 | 170 | digitized_manual | calibration |
| Kurano2022_Fig2A | free_NAC | 15 | 1.1710963455149501 | 0.09551495016611296 | 0.024916943521594685 | %ID/mL plasma | total 14C signal; not intact NAC | 141 | 202 | digitized_manual | calibration |
| Kurano2022_Fig2A | free_NAC | 30 | 0.813953488372093 | 0.08305647840531562 | 0.024916943521594685 | %ID/mL plasma | total 14C signal; not intact NAC | 191 | 245 | digitized_manual | calibration |
| Kurano2022_Fig2A | free_NAC | 60 | 0.6146179401993356 | 0.12043189368770764 | 0.024916943521594685 | %ID/mL plasma | total 14C signal; not intact NAC | 290 | 269 | digitized_manual | calibration |
| Kurano2022_Fig2A | free_NAC | 90 | 0.5066445182724253 | 0.09551495016611296 | 0.024916943521594685 | %ID/mL plasma | total 14C signal; not intact NAC | 389 | 282 | digitized_manual | calibration |

## Kurano2022_micelle

| dataset | group | time_min | value | SE_approx | pixel_uncertainty | unit | analyte | pixel_x | pixel_y | extraction | purpose |
|---|---|---|---|---|---|---|---|---|---|---|---|
| Kurano2022_Fig2A | micelle | 0 | 1.802325581395349 | 0.1536544850498339 | 0.024916943521594685 | %ID/mL plasma | total 14C signal; not intact NAC | 92 | 126 | digitized_manual | heldout_group |
| Kurano2022_Fig2A | micelle | 3 | 1.6528239202657806 | 0.24916943521594684 | 0.024916943521594685 | %ID/mL plasma | total 14C signal; not intact NAC | 102 | 144 | digitized_manual | heldout_group |
| Kurano2022_Fig2A | micelle | 15 | 1.004983388704319 | 0.1287375415282392 | 0.024916943521594685 | %ID/mL plasma | total 14C signal; not intact NAC | 141 | 222 | digitized_manual | heldout_group |
| Kurano2022_Fig2A | micelle | 30 | 0.8222591362126246 | 0.132890365448505 | 0.024916943521594685 | %ID/mL plasma | total 14C signal; not intact NAC | 191 | 244 | digitized_manual | heldout_group |
| Kurano2022_Fig2A | micelle | 60 | 0.6229235880398671 | 0.132890365448505 | 0.024916943521594685 | %ID/mL plasma | total 14C signal; not intact NAC | 290 | 268 | digitized_manual | heldout_group |
| Kurano2022_Fig2A | micelle | 90 | 0.5066445182724253 | 0.09551495016611296 | 0.024916943521594685 | %ID/mL plasma | total 14C signal; not intact NAC | 389 | 282 | digitized_manual | heldout_group |

## Son2021_stability_summaries

| source | species | matrix | analyte | starting_uM | half_life_min | first_order_surrogate_h_inv | role | source_location | restriction |
|---|---|---|---|---|---|---|---|---|---|
| Son2021 | rat | plasma | SFN | 1 | 76 | 0.5472214583367989 | summary_reproduction_not_independent_validation | Methods2.3.1;Results3.2.1;Fig5 | not nasal; net disappearance not kf/kr |
| Son2021 | human | plasma | SFN | 1 | 57.4 | 0.7245440911776432 | summary_reproduction_not_independent_validation | Methods2.3.1;Results3.2.1;Fig5 | not nasal; net disappearance not kf/kr |
| Son2021 | rat | plasma | SFN-NAC | 1 | 23.3 | 1.7849283619569405 | summary_reproduction_not_independent_validation | Methods2.3.1;Results3.2.1;Fig5 | not nasal; net disappearance not kf/kr |
| Son2021 | human | plasma | SFN-NAC | 1 | 19 | 2.1888858333471957 | summary_reproduction_not_independent_validation | Methods2.3.1;Results3.2.1;Fig5 | not nasal; net disappearance not kf/kr |

## human_SAS_constraints

| analyte | location | statistic | value | unit | samples_above_LLOQ | samples_tested | LLOQ_ng_mL |
|---|---|---|---|---|---|---|---|
| SFN | plasma | AUC_last | 16.2 | ng h/mL |  |  | 5 |
| SFN-GSH | plasma | AUC_last | 277 | ng h/mL |  |  | 10 |
| SFN-NAC | plasma | AUC_last | 415 | ng h/mL |  |  | 5 |
| SFN | CSF substudy | above_LLOQ_count |  | count | 5 | 95 | 5 |
| SFN-GSH | CSF substudy | above_LLOQ_count |  | count | 5 | 96 | 10 |
| SFN-NAC | CSF substudy | above_LLOQ_count |  | count | 0 | 96 | 5 |

## Danilov2009_Fig6_text

| dataset_id | condition | nominal_SFN_uM | treatment_timing | cell_death_percent | SEM_percent | n | source_id | source_location | extraction | purpose |
|---|---|---|---|---|---|---|---|---|---|---|
| DAN_F6 | vehicle_sham | 0 | no OGD | 2.3 | 0.5 | 8–9 (Fig6 caption) | Danilov2009 | Results C and Fig6; Statistical Analysis defines mean ± SEM | exact_text_transcription | descriptive_PD_context_not_calibration_or_validation |
| DAN_F6 | SFN_sham | 2.5 | no OGD | 3.4 | 0.5 | 8–9 (Fig6 caption) | Danilov2009 | Results C and Fig6; Statistical Analysis defines mean ± SEM | exact_text_transcription | descriptive_PD_context_not_calibration_or_validation |
| DAN_F6 | vehicle_OGD | 0 | after 4h OGD; 48h REOX | 37.5 | 1.4 | 8–9 (Fig6 caption) | Danilov2009 | Results C and Fig6; Statistical Analysis defines mean ± SEM | exact_text_transcription | descriptive_PD_context_not_calibration_or_validation |
| DAN_F6 | SFN_OGD | 2.5 | after 4h OGD; 48h REOX | 25.6 | 2.5 | 8–9 (Fig6 caption) | Danilov2009 | Results C and Fig6; Statistical Analysis defines mean ± SEM | exact_text_transcription | descriptive_PD_context_not_calibration_or_validation |

## NAC_slice2026_Table2

| source | condition | NAC_uM | GSH_total_nmol_mg_protein | SEM | n | treatment | role | location |
|---|---|---|---|---|---|---|---|---|
| NAC_slice2026 | control | 0 | 2.8 | 0.4 | 5 | NAC 1h after OGD; harvest48h | context_not_calibration_or_validation | Table2 |
| NAC_slice2026 | OGD | 0 | 3.4 | 0.8 | 5 | NAC 1h after OGD; harvest48h | context_not_calibration_or_validation | Table2 |
| NAC_slice2026 | OGD_NAC_0.1mM | 100 | 6.3 | 1.1 | 5 | NAC 1h after OGD; harvest48h | context_not_calibration_or_validation | Table2 |
| NAC_slice2026 | OGD_NAC_1mM | 1000 | 5.2 | 0.6 | 5 | NAC 1h after OGD; harvest48h | context_not_calibration_or_validation | Table2 |

## Reyes2016_CSF_text

| source | species | route | dose_mg_kg | time_min | analyte | value_uM | SEM_uM | role | location |
|---|---|---|---|---|---|---|---|---|---|
| Reyes2016 | EAAC1 knockout mouse | intraperitoneal | 25 | 20 | CSF NAC (reduced and total separately measured; quoted peak) | 0.126 | 0.015 | context_not_external_validation | Results CSF levels, Fig6A |
| Reyes2016 | human Parkinson disease cohort | oral repeated every12h, four doses | 70 | 90 | CSF TOTAL NAC after fourth dose | 10.1 | 0.8 | context_not_external_validation | Results human CSF, Fig6E; original data replot from cited Ref24 |

## Zhang2023_observation_definitions

| source | figure | context | endpoint | assay | contrast | direction | magnitude | error | role | limitation |
|---|---|---|---|---|---|---|---|---|---|---|
| Zhang2023 | Fig8 | SH-SY5Y:VPA4mM24h;NAC2mM2h | Notch1 | WB normalized GAPDH | VPA+NAC vs VPA | decrease | not extracted | original SD; n=3, numerical SD unavailable | mechanism_direction_only | total protein, not NICD |
| Zhang2023 | Fig8 | SH-SY5Y:VPA4mM24h;NAC2mM2h | NICD | WB normalized GAPDH | VPA+NAC vs VPA | decrease | not extracted | original SD; n=3, numerical SD unavailable | mechanism_direction_only | cleaved intracellular domain abundance, not calibrated receptor kinetics |
| Zhang2023 | Fig8 | SH-SY5Y:VPA4mM24h;NAC2mM2h | Jagged1 | WB normalized GAPDH | VPA+NAC vs VPA | decrease | not extracted | original SD; n=3, numerical SD unavailable | mechanism_direction_only | ligand protein abundance |
| Zhang2023 | Fig8 | SH-SY5Y:VPA4mM24h;NAC2mM2h | Hes1 | WB normalized GAPDH | VPA+NAC vs VPA | decrease | not extracted | original SD; n=3, numerical SD unavailable | mechanism_direction_only | protein, not transcript |
| Zhang2023 | Fig8 | SH-SY5Y:VPA4mM24h;NAC2mM2h | Hes5 | WB normalized GAPDH | VPA+NAC vs VPA | decrease | not extracted | original SD; n=3, numerical SD unavailable | mechanism_direction_only | protein, not transcript |
| Zhang2023 | Fig7 | SH-SY5Y:VPA4mM24h;NAC2mM2h | LC3B_II_I | WB normalized GAPDH | VPA+NAC vs VPA | increase | not extracted | original SD; numerical SD unavailable | mechanism_direction_only | static abundance cannot identify autophagic flux |
| Zhang2023 | Fig7 | SH-SY5Y:VPA4mM24h;NAC2mM2h | Beclin1 | WB normalized GAPDH | VPA+NAC vs VPA | increase | not extracted | original SD; numerical SD unavailable | mechanism_direction_only | static abundance cannot identify autophagic flux |
| Zhang2023 | Fig7 | SH-SY5Y:VPA4mM24h;NAC2mM2h | p62 | WB normalized GAPDH | VPA+NAC vs VPA | decrease | not extracted | original SD; numerical SD unavailable | mechanism_direction_only | static abundance cannot identify autophagic flux |

## PD_exposure_contexts

| source | analyte | nominal_concentration_uM | time_h | model | endpoint | purpose |
|---|---|---|---|---|---|---|
| Danilov2009 | SFN | 5 | 48 | rat cortical astrocytes; 48h SFN PRE-treatment before OGD | NRF2/NQO1 and protection | context_not_EC50_or_brain_threshold |
| Zhang2023 | NAC | 2000 | 2 | SH-SY5Y VPA | Notch/autophagy related | context_not_EC50_or_brain_threshold |
| Danilov2009 | SFN | 2.5 | 48 | rat cortical astrocytes; POST-treatment during REOX | Fig6 cell death | context_not_EC50_or_brain_threshold |
