# SUSTECH-MED staged M5–M7 v0.3

Read results_summary.md, scope_and_audit.md and evidence_report.html. This deliverable runs literature and numerical modes; project prediction is explicitly blocked by missing measured input and unparameterized physiology. Tests contain synthetic numerical fixtures only. No fixture is loaded by project prediction.

## Rebuild

Python3.12 with requirements-lock.txt. In a project venv, install `python -m pip install -r requirements-lock.txt`, then `python -X utf8 run_all.py`. All input archives required for offline rebuilding are included. Optional source refetch scripts are separate. The first build used the adjacent v0.2 project; portable rebuild falls back to reference_v02 and sources/literature_data copies.

## Later project run

Fill input_templates/concentration.csv with explicitly processed free-parent means and metadata.json with assay, sampling and error provenance. Keep raw files read-only. Configure independently justified transport and endpoint-specific parameters in a NEW JSON; project_unparameterized.json is deliberately not runnable as a biological prediction. `python scripts/run_project.py --input measured.csv --metadata metadata.json --config frozen.json --output project_results` refuses unknown coefficients or incompatible analytes. Do not set frozen=true merely to bypass missing evidence.

No M1/M2 growth reconstruction, brain diffusion PDE, clinical dosage optimization or new team animal experiment is included. Model/data/source/code version and hashes are recorded. A–E provenance is separate from pass/fail status. Original-study comparisons do not validate L168 brain exposure.
