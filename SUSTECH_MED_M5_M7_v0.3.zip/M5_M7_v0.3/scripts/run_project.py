"""Explicit project run. Will refuse missing free-parent input or transport parameters."""
from pathlib import Path
import argparse,json,sys,csv
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from interfaces import load_measured_input,EvidenceGap
from transport import TransportParameters,simulate
from pd import ReadoutParameters,simulate_readout

def main():
    a=argparse.ArgumentParser();a.add_argument('--input',required=True);a.add_argument('--metadata',required=True);a.add_argument('--config',required=True);a.add_argument('--output',required=True);args=a.parse_args()
    boundary,meta=load_measured_input(args.input,args.metadata)
    config=json.loads(Path(args.config).read_text(encoding='utf8'))
    if config.get('project_parameters_frozen') is not True:raise EvidenceGap('Project parameters and observation bridges are not frozen')
    p=TransportParameters(**config['transport'])
    p.validate()
    for record in config['pd_readouts']:
        if record['drug_index'] not in [0,1]:raise EvidenceGap('Readout driver must be explicitly justified as SFN or NAC; no default assignment')
        ReadoutParameters(**record['parameters']).validate()
    out=simulate(boundary,p,mode='external_concentration',start=boundary.t[0],end=boundary.t[-1])
    rows=[]
    for t,c in zip(out['time_h'],out['brain_free_uM'].T):rows.append(dict(time_h=t,SFN_effective_brain_free_uM=c[0],NAC_effective_brain_free_uM=c[1],interpretation='conditional_model_output_not_measured_brain'))
    target=Path(args.output);target.mkdir(parents=True,exist_ok=True)
    with (target/'brain_exposure.csv').open('w',newline='',encoding='utf8') as f:w=csv.DictWriter(f,fieldnames=rows[0]);w.writeheader();w.writerows(rows)
    for record in config['pd_readouts']:
        drug=record['drug_index'];p=ReadoutParameters(**record['parameters']);r=simulate_readout(out['time_h'],out['brain_free_uM'][drug],p)
        with (target/(p.name+'.csv')).open('w',newline='',encoding='utf8') as f:
            w=csv.writer(f);w.writerow(['time_h','effective_uM',p.name,p.unit]);w.writerows(zip(r['time_h'],r['effective_uM'],r['observed_readout'],[p.unit]*len(r['time_h'])))
    (target/'run_provenance.json').write_text(json.dumps(dict(input=meta,config=config,max_ledger_drift=float(abs(out['ledger']).max())),ensure_ascii=False,indent=2),encoding='utf8')
if __name__=='__main__':
    try:main()
    except EvidenceGap as e:raise SystemExit('Evidence gap: '+str(e))
