from pathlib import Path
import re,html,sys
root=Path(__file__).resolve().parents[1]
old=root.parent/'pkpd_project'/'literature_sources'
t=(old/'Zhang2023.html').read_text(encoding='utf8')
urls=list(dict.fromkeys(re.findall(r'https[^\s"<>]+(?:jpg|png)',t)))
print('\n'.join(urls))
for match in re.finditer(r'id="[^"]*(?:fig8|F8)[^"]*"',t,re.I):print(t[match.start():match.start()+3500])
