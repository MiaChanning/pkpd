from fetch_primary import get,ROOT
import json
out=ROOT/'literature_data';out.mkdir(exist_ok=True)
urls={'Zhang2023_Fig8':'https://cdn.ncbi.nlm.nih.gov/pmc/blobs/71ec/10525405/ed1bb6f5644c/10.1177_15353702231179924-fig8.jpg',
      'Zhang2023_Fig7':'https://cdn.ncbi.nlm.nih.gov/pmc/blobs/71ec/10525405/266719c609c8/10.1177_15353702231179924-fig7.jpg'}
rows=[]
for key,url in urls.items():
    try:
        raw=get(url)
        if not raw.startswith(b'\xff\xd8'):raise ValueError('Not a JPEG; access page rejected')
        (out/(key+'.jpg')).write_bytes(raw);rows.append(dict(id=key,url=url,status='retrieved',bytes=len(raw)))
    except Exception as e:rows.append(dict(id=key,url=url,status='failed',error=str(e)))
(out/'figure_retrieval_log.json').write_text(json.dumps(rows,indent=2),encoding='utf8');print(json.dumps(rows,indent=2))
