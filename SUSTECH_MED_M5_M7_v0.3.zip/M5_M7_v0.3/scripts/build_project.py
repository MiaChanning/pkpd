from pathlib import Path
import sys,shutil,csv,json,re,html,hashlib,xml.etree.ElementTree as ET
import numpy as np
ROOT=Path(__file__).resolve().parents[1];OLD=ROOT.parent/'pkpd_project'
if not (OLD/'src/literature_pk.py').exists():OLD=ROOT/'reference_v02'
sys.path.insert(0,str(ROOT/'src'));sys.path.insert(0,str(OLD/'src'))
from transport import TransportParameters,simulate
from interfaces import ConcentrationBoundary
from literature_pk import calibrate_son,oral_concentration,fit_decay,decay,positive_metrics

def write(path,text):(ROOT/path).write_text(text.strip()+'\n',encoding='utf8')
def csvout(path,rows):
    with (ROOT/path).open('w',encoding='utf-8-sig',newline='') as f:w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
def read(path):
    with Path(path).open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
def table(rows):
    keys=list(rows[0]);return '| '+' | '.join(keys)+' |\n|'+'|'.join(['---']*len(keys))+'|\n'+'\n'.join('| '+' | '.join(str(r.get(k,'')).replace('|','/').replace('\n',' ') for k in keys)+' |' for r in rows)

STAGES=[
('M5.1','培养液free-parent浓度 -> 有限时域插值','实测缺失；Assay2023测定口径','无A；分析物映射未知','尚无项目数据','输入元数据和非负/范围测试','接口测试通过；真实输入未接入','证据不足','重画供给曲线不算验证'),
('M5.2','有限量池与已知源 -> 可吸收母体量','Son2021;Mi2010，环境不匹配','鼻部k/q均未知；1:1当量D','内部数学基准','SFN/NAC当量漂移','守恒数值通过；鼻化学参数未标定','证据不足','固定浓度与有限供给互斥'),
('M6.1','供给浓度 -> 上皮跨越与并行分流','Kurano2022;Shen2025','目标PS与路径比例E/null','原研究同论文比较','R、Elog、曲线、AUC','NAC总标记量级通过，严格2SE未全通过','证据不足','不能迁移为母体鼻脑系数'),
('M6.2','直接有效延迟+血浆 -> 集总脑侧池','原研究PK与守恒结构','脑体积、PS、清除和效应比例未知','解析延迟、零路径对照','时滞/收支/求解器','内部通过；目标暴露不运行','证据不足','无CSF/组织/胞内观测桥'),
('M6 reference','IV/PO SFN -> 原条件血浆母体','Son2021','原研究CL/Vss/F/Tmax','回顾性校准+同研究留出','全晚尾logRMSE及AUC','保留高剂量晚尾失败','未通过','时间单位冲突；线性单室失效'),
('M7.A1','SFN有效暴露 -> NRF2 -> 转录/蛋白/酶','Danilov2009;Bergstrom2011;Townsend2016','单剂量与定性持续时间不识别动力学','原处理条件/端点上下文','均值与误差；无拟合成绩','阶段和观测拆分完成；动力学暂缓','证据不足','RNA/蛋白/活性各有观测'),
('M7.A2','NAC -> 半胱氨酸供给 -> GSH/氧化终点','Dringen1999;Reyes2016;NAC_slice2026','处理剂量/CSF不等于脑有效EC50','真实汇总端点与不同研究上下文','GSH值、SEM、CSF口径','数据复核完成；不拼接跨研究网络','证据不足','GSH缺乏/正常背景改变响应'),
('M7.A3','炎症刺激条件下的基因/蛋白终点','Townsend2016','摘要证据；完整定量曲线访问受限','机制方向上下文','不报告不存在的拟合','IL1β/IL6/iNOS方向证据；不生成曲线','证据不足','LPS实验不能直接映射ASD'),
('M7.B1','NAC+VPA -> Notch1/NICD/Jagged/Hes蛋白','Zhang2023 Fig8','2mM NAC×2h；4mM VPA×24h，非EC50','处理条件与方向；无可靠数字化','观测类型、独立条件需求','已区分NICD和总蛋白；无可识别时滞','证据不足','没有NAC直接结合Notch证据'),
('M7.B2','NAC+VPA -> Beclin1/LC3B/p62丰度','Zhang2023 Fig7','单终点；形成/降解未知','静态蛋白方向上下文','稳态非辨识证明','不推断真实自噬通量','证据不足','未从静态指标反推形成/降解率'),
('M7 coupling','抗氧化与Notch/自噬/炎症之间','跨体系证据，不支持统一定量链','耦合方向/强度均未知','无同条件串联验证','不进行无数据耦合拟合','保留机制图，不激活耦合边','未评估','不得把概念关系写成标定通路'),
('project chain','项目实测M5 -> M6 -> 两分支M7','用户确认实验进行中','核心输入/生理参数缺失','没有可用项目数据','联立数值接口可测','不生成项目脑暴露或PD结果','证据不足','无临床优化，无空间PDE')]

def main():
    # Local baseline is copied, never written by this stage project.
    selected=['src/literature_pk.py','references.bib','validation_report.md','parameter_registry.csv','tables/source_registry.csv','scripts/extract_data.py','inputs/iGEM2026_Multiscale_PKPD_Model_Proposal(2).md','inputs/Peking_2025_model_validation_summary(2).md']
    for name in selected:
        dest=ROOT/'reference_v02'/name;dest.parent.mkdir(parents=True,exist_ok=True)
        if (OLD/name).resolve()!=dest.resolve():shutil.copyfile(OLD/name,dest)
    shutil.copyfile(OLD/'src/literature_pk.py',ROOT/'src/literature_pk.py')
    # Pipeline-specific literature values are separate from all unmeasured target-setting parameters.
    files=['Son2021_Table1.csv','Son2021_IV_digitized.csv','Son2021_PO05_digitized.csv','Son2021_heldout.csv','Kurano2022_all_digitized.csv','Kurano2022_micelle.csv','human_SAS_constraints.csv','Danilov2009_Fig6_text.csv','PD_exposure_contexts.csv','Son2021_figure.jpg','Kurano2022_figure.jpg']
    for name in files:
        shutil.copyfile(OLD/'validation_datasets'/name,ROOT/'literature_data'/name)
        dest=ROOT/'reference_v02/validation_datasets'/name;dest.parent.mkdir(exist_ok=True)
        if (OLD/'validation_datasets'/name).resolve()!=dest.resolve():shutil.copyfile(OLD/'validation_datasets'/name,dest)
    for name in ['Son2021_calibration.csv','Kurano2022_free_NAC.csv']:
        shutil.copyfile(OLD/'calibration_datasets'/name,ROOT/'literature_data'/name)
        dest=ROOT/'reference_v02/calibration_datasets'/name;dest.parent.mkdir(exist_ok=True)
        if (OLD/'calibration_datasets'/name).resolve()!=dest.resolve():shutil.copyfile(OLD/'calibration_datasets'/name,dest)
    for key in ['Zhang2023','Danilov2009','Mi2010','Zolnourian2025','Shen2025']:
        for suffix in ['html','txt']:
            src=OLD/'literature_sources'/(key+'.'+suffix)
            if src.exists():
                shutil.copyfile(src,ROOT/'sources'/(key+'_v02.'+suffix))
                dest=ROOT/'reference_v02/literature_sources'/src.name;dest.parent.mkdir(exist_ok=True)
                if src.resolve()!=dest.resolve():shutil.copyfile(src,dest)
    shutil.copyfile(OLD/'literature_sources/Assay2023.xml',ROOT/'sources/Assay2023.xml')
    dest=ROOT/'reference_v02/literature_sources/Assay2023.xml'
    if (OLD/'literature_sources/Assay2023.xml').resolve()!=dest.resolve():shutil.copyfile(OLD/'literature_sources/Assay2023.xml',dest)
    scopes=[dict(stage=a,input_output=b,mechanism=c,parameters=d,data_role=e,metric=f,result=g,status=h,limitation=i) for a,b,c,d,e,f,g,h,i in STAGES]
    csvout('tables/stage_summary.csv',scopes)
    fields=dict(V_nose=None,V_plasma=None,V_brain=None,PS_ep=[None,None],f_direct=[None,None],f_systemic=[None,None],tau_direct=[None,None],PS_pb=[None,None],K_pb=[None,None],CL_plasma=[None,None],CL_brain=[None,None],k_nasal_loss=[0,0],kf=0,kr=0,k_conjugate_loss=0)
    pdnames=['NRF2_nuclear','NQO1_mRNA','NQO1_protein','NQO1_activity','GSH_total','GSSG','ROS_assay','IL6_mRNA','IL6_secreted','Notch1_total','NICD_protein','Hes1_protein','Beclin1_protein','LC3B_II_I','p62_protein']
    pdcfg=[dict(drug_index=None,parameters=dict(name=name,assay=None,unit=None,study_context=None,baseline=None,max_fraction_change=None,EC50_uM=None,tau_response_h=None,effective_fraction=None,tau_effect_h=None,direction=None,hill=1)) for name in pdnames]
    config=dict(version='0.3',project_parameters_frozen=False,input_mode='external_concentration',transport=fields,pd_readouts=pdcfg,
                note='Zeros disable duplicate donor chemistry in boundary mode; these are structural switches, not measured zero rates. No numerical fixture fills unknown physiology. No inter-readout coupling enabled.')
    write('configs/project_unparameterized.json',json.dumps(config,ensure_ascii=False,indent=2))
    write('input_templates/concentration.csv','time_h,SFN_free_uM,NAC_free_uM,qualifier,replicate_id')
    keys=['dataset_id','matrix','culture_mode','analytes','concentration_unit','time_unit','culture_volume_mL','sampling_scheme','assay','replicates','sterile_control','stability_control','precursors','initial_added_drug','background_subtraction','LOD','LLOQ','recovery','input_mode']
    meta={k:None for k in keys};meta.update(analytes=['free_parent_SFN','free_parent_NAC'],concentration_unit='uM',time_unit='h',input_mode='external_concentration')
    write('input_templates/metadata.json',json.dumps(meta,ensure_ascii=False,indent=2))
    pars=[]
    units={'V_nose':'mL','V_plasma':'mL','V_brain':'mL','PS_ep':'mL/h','f_direct':'fraction','f_systemic':'fraction','tau_direct':'h','PS_pb':'mL/h','K_pb':'dimensionless','CL_plasma':'mL/h','CL_brain':'mL/h','k_nasal_loss':'h^-1','kf':'mL/(nmol h)','kr':'h^-1','k_conjugate_loss':'h^-1'}
    for key,value in fields.items():
        structural=key in ['k_nasal_loss','kf','kr','k_conjugate_loss']
        pars.append(dict(parameter=key,stage='M5/M6',value=json.dumps(value),original_unit=units[key],model_unit=units[key],source='interface definition' if structural else 'unconstrained',source_location='configs/project_unparameterized.json',species='not chosen',tissue='culture boundary / effective systemic and brain pools',route='project pathway unknown',formulation='culture medium, not patient nasal dose',analyte='SFN/NAC free parent',time='h',uncertainty='unknown',conversion='identity',purpose='disable double-counting' if structural else 'project_prediction_blocked',risk='structural switch' if structural else 'no matching physiological value',grade='D' if structural else 'E',parameter_class='structure_switch' if structural else 'biological_or_effective_parameter'))
    for name in ['baseline','max_fraction_change','EC50_uM','tau_response_h','effective_fraction','tau_effect_h','hill']:
        pars.append(dict(parameter='each_readout.'+name,stage='M7',value='1 (fixed structural choice)' if name=='hill' else 'null',original_unit={'EC50_uM':'uM','tau_response_h':'h','tau_effect_h':'h'}.get(name,'readout unit or dimensionless'),model_unit={'EC50_uM':'uM','tau_response_h':'h','tau_effect_h':'h'}.get(name,'readout unit or dimensionless'),source='model form' if name=='hill' else 'unconstrained',source_location='src/pd.py',species='must match assay',tissue='endpoint-specific',route='culture bath / conditional effective exposure',formulation='must be matched',analyte='must be readout-specific',time='h',uncertainty='unknown',conversion='none',purpose='response framework only',risk='not a fitted named pathway',grade='D' if name=='hill' else 'E',parameter_class='structure_choice' if name=='hill' else 'effective_response_parameter'))
    # Exact original plasma stability summaries do not determine nasal rates or split conjugate cleavage/loss.
    stability=[]
    for species,analyte,half in [('rat','SFN',76),('human','SFN',57.4),('rat','SFN-NAC',23.3),('human','SFN-NAC',19)]:
        rate=np.log(2)/(half/60);stability.append(dict(source='Son2021',species=species,matrix='plasma',analyte=analyte,starting_uM=1,half_life_min=half,first_order_surrogate_h_inv=rate,role='summary_reproduction_not_independent_validation',source_location='Methods2.3.1;Results3.2.1;Fig5',restriction='not nasal; net disappearance not kf/kr'))
        pars.append(dict(parameter=species+'_'+analyte+'_plasma_disappearance',stage='M5 literature context',value=rate,original_unit='min half-life',model_unit='h^-1',source='10.3390/pharmaceutics13070958',source_location='Results3.2.1',species=species,tissue='plasma incubation',route='in vitro',formulation='1uM compound in plasma',analyte=analyte,time=half,uncertainty='half-life uncertainty not reported in quoted result',conversion='ln2*60/t_half_min',purpose='context_not_nasal_parameter',risk='net disappearance confounds dissociation/loss',grade='D (original t_half B)',parameter_class='derived_mathematical_surrogate'))
    csvout('literature_data/Son2021_stability_summaries.csv',stability)
    # New NAC slice table is exactly transcribed and stays descriptive: no single-endpoint Hill fit.
    slice_rows=[dict(source='NAC_slice2026',condition=a,NAC_uM=c,GSH_total_nmol_mg_protein=m,SEM=s,n=5,treatment='NAC 1h after OGD; harvest48h',role='context_not_calibration_or_validation',location='Table2') for a,c,m,s in [('control',0,2.8,.4),('OGD',0,3.4,.8),('OGD_NAC_0.1mM',100,6.3,1.1),('OGD_NAC_1mM',1000,5.2,.6)]]
    x=ET.parse(ROOT/'sources/NAC_slice2026.raw')
    tabletext=' '.join(x.find('.//table-wrap[@id="children-13-00379-t002"]').itertext())
    assert all(str(row['GSH_total_nmol_mg_protein']) in tabletext for row in slice_rows)
    csvout('literature_data/NAC_slice2026_Table2.csv',slice_rows)
    reyes=[dict(source='Reyes2016',species='EAAC1 knockout mouse',route='intraperitoneal',dose_mg_kg=25,time_min=20,analyte='CSF NAC (reduced and total separately measured; quoted peak)',value_uM=.126,SEM_uM=.015,role='context_not_external_validation',location='Results CSF levels, Fig6A'),
           dict(source='Reyes2016',species='human Parkinson disease cohort',route='oral repeated every12h, four doses',dose_mg_kg=70,time_min=90,analyte='CSF TOTAL NAC after fourth dose',value_uM=10.1,SEM_uM=.8,role='context_not_external_validation',location='Results human CSF, Fig6E; original data replot from cited Ref24')]
    csvout('literature_data/Reyes2016_CSF_text.csv',reyes)
    # Protocol/direction records preserve variable identity, not invented fold changes or errors.
    direction=[dict(source='Zhang2023',figure='Fig8',context='SH-SY5Y:VPA4mM24h;NAC2mM2h',endpoint=e,assay='WB normalized GAPDH',contrast='VPA+NAC vs VPA',direction='decrease',magnitude='not extracted',error='original SD; n=3, numerical SD unavailable',role='mechanism_direction_only',limitation=l) for e,l in [('Notch1','total protein, not NICD'),('NICD','cleaved intracellular domain abundance, not calibrated receptor kinetics'),('Jagged1','ligand protein abundance'),('Hes1','protein, not transcript'),('Hes5','protein, not transcript')]]
    direction += [dict(source='Zhang2023',figure='Fig7',context='SH-SY5Y:VPA4mM24h;NAC2mM2h',endpoint=e,assay='WB normalized GAPDH',contrast='VPA+NAC vs VPA',direction=d,magnitude='not extracted',error='original SD; numerical SD unavailable',role='mechanism_direction_only',limitation='static abundance cannot identify autophagic flux') for e,d in [('LC3B_II_I','increase'),('Beclin1','increase'),('p62','decrease')]]
    csvout('literature_data/Zhang2023_observation_definitions.csv',direction)
    csvout('parameter_registry.csv',pars)
    # Literature PK benchmark parameters remain in study units (minutes).
    fit=calibrate_son(read(ROOT/'literature_data/Son2021_calibration.csv'))
    po=[r for r in read(ROOT/'literature_data/Son2021_PO05_digitized.csv') if r['value_ng_mL']]
    times=np.array([float(r['time_min']) for r in po]);obs=np.array([float(r['value_ng_mL']) for r in po]);pred=1000*oral_concentration(times,.5,fit['F'],fit['CL'],fit['V'],fit['ka'])
    csvout('tables/son_comparison.csv',[dict(time_min=t,observed_digitized_ng_mL=o,predicted_ng_mL=p,R=p/o,E_log=abs(np.log10(p/o))) for t,o,p in zip(times,obs,pred)])
    free=read(ROOT/'literature_data/Kurano2022_free_NAC.csv');mic=read(ROOT/'literature_data/Kurano2022_micelle.csv');tt=np.array([float(r['time_min']) for r in free]);yy=np.array([float(r['value']) for r in free]);nf=fit_decay(tt,yy);mp=np.array([float(r['value']) for r in mic]);npred=decay(tt,nf)
    csvout('tables/kurano_comparison.csv',[dict(time_min=t,calibration_total14C=f,heldout_total14C=o,predicted_total14C=p,approx_SE=float(row['SE_approx']),R=p/o,E_log=abs(np.log10(p/o))) for t,f,o,p,row in zip(tt,yy,mp,npred,mic)])
    nk=positive_metrics(npred,mp);sf=positive_metrics(pred,obs)
    nk.update(predicted_AUC=float(np.trapezoid(npred,tt)),digitized_AUC=float(np.trapezoid(mp,tt)),max_SE_distance=float(np.max(abs(npred-mp)/[float(r['SE_approx']) for r in mic])))
    write('configs/literature_frozen.json',json.dumps(dict(Son2021=fit,Kurano2022=nf),indent=2))
    for name,value,unit,study,how in [('CL_rat_SFN',fit['CL'],'mL/min/kg','Son2021','Table1 IV0.1mg/kg'),('Vss_rat_SFN',fit['V'],'mL/kg','Son2021','Table1 IV0.1mg/kg; single compartment approximation'),('F_lowdose_SFN',fit['F'],'fraction','Son2021','Table1 PO0.1mg/kg F77.8%'),('Tmax_lowdose_SFN',fit['tmax'],'min','Son2021','Table1 PO0.1mg/kg'),('ke_rat_SFN',fit['ke'],'min^-1','Son2021','derived CL/Vss'),('ka_rat_SFN',fit['ka'],'min^-1','Son2021','derived from Tmax and ke'),('label_amplitude',nf['amplitude'],'%ID/mL plasma','Kurano2022','fit 6 free-formulation digitized means'),('label_decay',nf['k_min'],'min^-1','Kurano2022','log-linear fit, not intact NAC clearance')]:
        pars.append(dict(parameter=name,stage='original-study benchmark',value=value,original_unit=unit,model_unit=unit,source='10.3390/pharmaceutics13070958' if study=='Son2021' else '10.3390/pharmaceutics14122590',source_location=how,species='rat' if study=='Son2021' else 'ddY mouse',tissue='plasma',route='IV/PO' if study=='Son2021' else 'intranasal',formulation='original-study drug or tracer',analyte='parent SFN' if study=='Son2021' else 'total14C signal',time='min',uncertainty='original SD/pixel error in literature_data; joint fit uncertainty not estimated',conversion='none; original benchmark uses minutes',purpose='calibration_frozen_before_retrospective_holdout',risk='not transplanted to target transport',grade='B' if name in ['CL_rat_SFN','Vss_rat_SFN','F_lowdose_SFN','Tmax_lowdose_SFN'] else 'D',parameter_class='original biological measurement' if name in ['CL_rat_SFN','Vss_rat_SFN','F_lowdose_SFN','Tmax_lowdose_SFN'] else 'derived mathematical model parameter'))
    csvout('parameter_registry.csv',pars)
    write('configs/numerical_settings.json',json.dumps(dict(transport=dict(method='DOP853',rtol=1e-9,atol=1e-11,max_step_h=.025,output_points=301),pd=dict(method='DOP853',rtol=1e-9,atol=1e-11,max_step_h=.02),reference_solver='Radau',purpose='solver settings chosen and checked numerically; not physiological parameters',statistics='log-linear least squares signal fit; no fit to M7 single endpoints'),indent=2))
    # Internal numeric records only, no scenario concentration figures presented as project outputs.
    p=TransportParameters(1,2,3,[.2,.3],[.1,.2],[.4,.3],[.4,.5],[.1,.2],[1,1],[.2,.3],[.4,.5],[0,0],0,0,0)
    b=ConcentrationBoundary([0,1,2],[[1,1],[1,1],[0,0]],analytes=['free_parent_SFN','free_parent_NAC'],origin='numerical_fixture',role='internal_test')
    q=simulate(b,p,mode='external_concentration',start=0,end=2);qr=simulate(b,p,mode='external_concentration',start=0,end=2,method='Radau')
    checks=dict(test_count=24,max_open_boundary_ledger_nmol=float(abs(q['ledger']).max()),reference_solver_max_difference=float(abs(q['amounts']-qr['amounts']).max()),internal_parameters_are_fixture=True)
    csvout('tables/internal_ledger.csv',[dict(time_h=t,SFN_ledger_nmol=a,NAC_ledger_nmol=c,role='numerical_fixture_only') for t,a,c in zip(q['time_h'],q['ledger'][0],q['ledger'][1])])
    summary=dict(version='0.3',project_input_available=False,project_prediction_executed=False,project_parameter_calibration_completed=False,independent_target_validation=False,internal=checks,literature_Kurano=nk,literature_Son=sf,
                 PD_dynamic_calibration_completed=False,PD_single_endpoint_hill_fit_rejected=True)
    write('tables/results.json',json.dumps(summary,indent=2))
    # Source identity and every reference used below is visible. Source access does not certify portability.
    refs=read(OLD/'tables/source_registry.csv');refrows=[r for r in refs if r['source_id'] in ['Son2021','Kurano2022','Danilov2009','Zhang2023','Zolnourian2025','Mi2010','Assay2023','Shen2025']]
    log=json.loads((ROOT/'sources/retrieval_log.json').read_text(encoding='utf8'))
    for r in log:
        if r['id'] in ['Bergstrom2011','Dringen1999','Townsend2016','NAC_neuron2016']:
            refrows.append(dict(source_id='Reyes2016' if r['id']=='NAC_neuron2016' else r['id'],title=r.get('title',''),doi=r.get('doi',''),url='https://doi.org/'+r.get('doi',''),authors='',journal='',registry_year='2016' if r['id'] in ['Townsend2016','NAC_neuron2016'] else '2011' if r['id']=='Bergstrom2011' else '1999',published_date='',online_date='',modules='M7.A',metadata_status=r['status'],original_access_record='publisher full text' if r['id']=='NAC_neuron2016' else 'abstract / fulltext API failed or unavailable',evidence_location='abstract / Methods and Results if full text retrieved',archive_files='sources/'+r['id']+'_metadata.json',numerical_use='context only',assessment='not a parameterized target-setting response'))
    refrows.append(dict(source_id='NAC_slice2026',title=' '.join(x.find('.//article-title').itertext()),doi='10.3390/children13030379',url='https://doi.org/10.3390/children13030379',authors='; '.join(' '.join(n.itertext()) for n in x.findall('.//contrib[@contrib-type="author"]/name')),journal='Children',registry_year='2026',published_date='',online_date='',modules='M7.A',metadata_status='XML read',original_access_record='full article XML',evidence_location='Table2',archive_files='sources/NAC_slice2026.raw',numerical_use='endpoint context only',assessment='slice OGD; not matched to project exposure'))
    for row in refrows:
        pattern='Reyes2016*' if row['source_id']=='Reyes2016' else row['source_id']+'*'
        files=[p.relative_to(ROOT).as_posix() for p in (ROOT/'sources').glob(pattern) if p.is_file()]
        if files:row['archive_files']=';'.join(sorted(files))
    csvout('source_registry.csv',refrows)
    write('references.bib','\n'.join('@article{'+r['source_id']+',\n title={'+re.sub('<[^>]*>','',r['title'])+'},\n year={'+r['registry_year']+'},\n doi={'+r['doi']+'},\n url={'+r['url']+'}\n}\n' for r in refrows))
    datasets=[]
    for name,ref,purpose,variable,lim in [
      ('Son2021_calibration.csv','Son2021','calibration','rat plasma parent SFN IV/PO','original study only'),('Son2021_IV_digitized.csv','Son2021','same-study reproduction','parent SFN','time h/min conflict; not independent'),('Son2021_PO05_digitized.csv','Son2021','retrospective same-study heldout subset','parent SFN','4 early unreadable points; late failure retained'),('Kurano2022_free_NAC.csv','Kurano2022','calibration','plasma total14C','not intact NAC or brain ECF'),('Kurano2022_micelle.csv','Kurano2022','retrospective same-study heldout formulation','plasma total14C','formulation mismatch; not independent'),('Son2021_stability_summaries.csv','Son2021','context and tautological summary reproduction','plasma disappearance half-lives','no curve-level test; not nasal chemistry'),('human_SAS_constraints.csv','Zolnourian2025','left-censored plausibility context not scored','SFN/conjugate plasma/CSF','oral/NG, no matched transport simulation'),('Danilov2009_Fig6_text.csv','Danilov2009','PD context only','cell death percent','single dose/time, no Hill fit'),('NAC_slice2026_Table2.csv','NAC_slice2026','PD context only','slice total GSH nmol/mg protein','single time, differing doses not a transport bridge'),('Reyes2016_CSF_text.csv','Reyes2016','PK/PD bridge context only','CSF total/reduced NAC','human Fig6E is reused original dataset, not independent duplication'),('Zhang2023_observation_definitions.csv','Zhang2023','protocol and direction only','Notch/NICD/Hes/LC3/p62 WB','no numerical means digitized; not calibrated'),('PD_exposure_contexts.csv','Danilov2009;Zhang2023','nominal exposure context','culture bath dose','not EC50 or brain threshold')]:
        source_location={'Son2021_calibration.csv':'Table1, IV and PO0.1mg/kg','Son2021_IV_digitized.csv':'Fig8a','Son2021_PO05_digitized.csv':'Fig8b late subset','Kurano2022_free_NAC.csv':'Fig2A open circles','Kurano2022_micelle.csv':'Fig2A closed circles','Son2021_stability_summaries.csv':'Results3.2.1, Fig5','human_SAS_constraints.csv':'CSF Results and Fig3 LLOQ caption','Danilov2009_Fig6_text.csv':'Results C, Fig6','NAC_slice2026_Table2.csv':'Table2','Reyes2016_CSF_text.csv':'CSF Results, Fig6A/Fig6E','Zhang2023_observation_definitions.csv':'Fig7 and Fig8 caption/results','PD_exposure_contexts.csv':'cell-treatment methods'}[name]
        datasets.append(dict(dataset_id=name[:-4],file='literature_data/'+name,reference=ref,purpose=purpose,variable=variable,extraction='digitized means' if 'digitized' in name or 'Kurano' in name else 'exact text/table or qualitative observation definition',source_location=source_location,original_source_files=';'.join(row['archive_files'] for row in refrows if row['source_id'] in ref.split(';')),processing_code='scripts/build_project.py; legacy pixels: reference_v02/scripts/extract_data.py',uncertainty='SD/SEM/pixel fields retained in data; absence not imputed',comparison_level='within-study retrospective' if 'heldout' in purpose or purpose=='calibration' or 'reproduction' in purpose else 'context_only',limitations=lim))
    csvout('validation_registry.csv',datasets)
    write('inventory_report.md','# 本次文件与输入核查\n\n已读取/复用：v0.2模型、参数表、验证报告、两份原提案、源文献和原PK数据。原材料复制在reference_v02，只作为证据与旧失败参照，不运行旧M1/M2。\n\n缺失：本项目SFN/NAC实测浓度CSV、分析方法与取样元数据、鼻部有效运输参数、匹配脑有效暴露与PD桥接。用户2026-10-14确认实验进行中，无实测数据。这不是文件系统错误导致的缺失判断。新input_templates目录中的CSV只有表头。\n\n访问受限而非文件不存在：部分Europe PMC完整XML返回500；NCBI全文/原图TLS连接失败；Bergström和Dringen记录未找到PMC开放全文。原访问日志保留在sources，已有v0.2可读全文被复用。')
    docbuild(scopes,summary,refrows,datasets)
    print(json.dumps(summary,indent=2))

def docbuild(scopes,r,refs,data):
    stage_table=table(scopes);nk=r['literature_Kurano'];sf=r['literature_Son']
    write('scope_and_audit.md',(ROOT/'scope_checkpoint.md').read_text(encoding='utf8')+'\n\n## 实际阶段状态\n\n'+stage_table)
    write('equations.md',r'''# M5–M7 计算阶段、单位与观测

时间h、物质量nmol、体积mL、浓度nmol/mL=μM。SFN和NAC各有独立参数。M1/M2只提供已定义的上游输出，当前不再求解生长/定植。无脑空间PDE。

## M5 外部浓度驱动（接口A）

输入 C_j(t) 取自特异性游离母体测量，按原时域分段线性插值；J_ep,j=PS_ep,j C_j。C_j是保持的供给边界，模型不预测供给耗竭。输入账本积分的是离开供给边界的量，不是从培养曲线反推的生产量。供给池是开放系统。已包含在共同培养母体曲线内的净降解/缀合不再重复扣除；外部模式中鼻侧反应开关必须为0。处理后可回收母体若无游离比例证据，不能直接接入。

## M5 有限供给（接口B）

只在已知初始量与补充量通量R_j(t)时运行：dn_S=R_S−J_ep,S−k_loss,S n_S−r，dn_N类似；dn_SN=r−k_loss,SN n_SN；r=kf n_S n_N/Vnose−kr n_SN。损失账本同时记录缀合物的两个当量。R_j不等于dC/dt。只有母体共同培养曲线不足以分别辨识生产、降解和缀合。当前未实现缀合物跨膜/脑侧作用，属于结构简化，不是证明其永久无活性。其分布和活性不允许用母体参数代替。

## M6 并行直接与系统通路

J_ep经f_direct和f_systemic分流，其余计入损失。直接阶段 dT=f_direct J_ep−T/τ，出流T/τ进入集总脑侧；这是一个有效指数延迟池，不声称代表嗅球细胞或特定神经结构。血浆与脑侧交换J_pb=PS_pb(Cp−Cb/Kpb)，分别扣加一次。dn_p=f_sys J_ep−J_pb−CLp Cp；dn_b=T/τ+J_pb−CLb Cb。外部供应模式：T+p+b+累计退出−累计输入=0；有限模式还加鼻侧母体+缀合当量，并减初始当量。CSF本次不单列，因为没有可迁移识别依据；CSF、组织匀浆、14C与胞内观测均需独立桥接，接口直接拒绝混用。f_direct=0仍可由系统路径到脑；全部脑路径为0才应零脑暴露。

## M7 有效暴露与读数响应

候选效应室 dCe=(ρ Cb−Ce)/τe；它保留摄取/分布时滞，不把ECF直接当成细胞内浓度。ρ与τe都未知，不采用默认脑细胞快速平衡。每个实际终点独立定义 dx=[x0(1+s Emax Ce^n/(EC50^n+Ce^n))−x]/τx。该结构为有效诱导/抑制响应，不是具名生化网络。n=1是降低自由度的显式结构选择，EC50/Emax/τ均未拟合。不同转录/蛋白/酶活/GSH/炎症读数不能共用x、x0或时间常数。无药时回到匹配基线；不激活没有证据的跨分支边。模块量纲正确不等于生理参数可靠。

## 两分支的候选阶段与识别界限

A：SFN—KEAP1/NRF2相关早期响应—RNA—蛋白/酶活；NAC—半胱氨酸可用性—GSH合成/消耗—氧化与炎症读数。当前用有效合成响应代替未约束的半胱氨酸/GSH反应网络，不写成NAC一步生成GSH。GSSG若无独立测量保持不激活。B：NAC+特定VPA条件—Notch1总蛋白与NICD分别观测—Hes1蛋白—静态自噬指标；不把NAC当成已知Notch配体。LC3/p62的形成/降解模型只写作候选 dL=form−deg L。仅稳态丰度L，任意正deg及form=deg L都给同一读数，无法识别真实通量。单剂量单时间点不能识别Emax、EC50、τ的三个自由参数。
''')
    write('input_contract.md','''# 上游实测输入接口

用户确认实验进行中，暂时没有数据。空模板仅是字段结构，不含合成观测。

每个批次记录模拟鼻腔基质、单菌/共同培养/混合上清、游离母体或样本处理后信号、h与μM、体积、取样/补液、前体和初加药物、背景、重复、对照、LOD/LLOQ和回收率。未做某对照应明确填“not performed”，不要误写已有。元数据字段未知填null，运行器拒绝无依据的关键输入。CSV中的quantified是分析状态，不是自动去除低于定量限点。BQL不填0；应在单独、可追溯的上下界情景中处理后才能接入。

M1/M2的CFU、分泌通量、区域分布与浓度不是同一接口。提供浓度时可只采用接口A，不需要反拟合菌量或产率。曲线已含培养净过程，不能再对供给边界重复施加原培养损失。接口B只有显式已知量源项才能工作。控制器拒绝固定浓度与有限供给同时启用。

线性插值不产生超出原点范围的过冲，只限原测量时间域；没有无根据的长期外推。重复的处理、回收率修正、删失和采样误差应保留原点与处理记录。缺少可信输入误差时不生成自称95%CI的脑预测。
''')
    write('literature_review.md','''# M5–M7 原始机制与应用数据

检索/核查日期2026-10-14。每条结论限于来源的物种、处理和分析物。机制存在不提供本项目生理系数。全文API500、TLS错误、无开放全文和图片下载失败已归档；未提取的幅度保持空缺。

## M5

Son2021的血浆SFN与SFN-NAC消失/母体再生支持可逆化学及分开分析，不提供鼻侧kf/kr。Mi2010支持NAC与异硫氰酸酯共存时的化学干扰，不能据此设恒定协同或拮抗因子。Assay2023说明硫醇阻断和样本处理影响可回收SFN口径。鼻侧自身NAC稳定性未知。

## M6

Kurano2022同时研究鼻给自由NAC和胶束制剂，但液闪检测为总14C，原图血浆不是游离母体脑ECF。原研究给药用时10min，图0min为给药完成后首点；AUC时间原点必须保留。Son2021口服/静脉大鼠母体SFN基准保留高剂量晚尾失败。SAS为口服/鼻胃管SFX-01，CSF左删失不能填0或照搬为鼻部脑递送效率。直接通路与系统通路可并行；本实现把未辨识的上皮/神经/中间结构合并，不强制“嗅球细胞→CSF”顺序。

## M7 抗氧化、GSH与炎症

Danilov2009区分5μM×48h预处理与2.5μM×48h后处理；后处理细胞死亡均值与SEM可转录，却不足以拟合Hill或时滞。Bergström2011摘要报告4h刺激后转录和蛋白持续时间不同；仅摘要不能确定完整撤药曲线或精确时间常数。Dringen1999在胚胎大鼠神经元中支持NAC作为半胱氨酸供体促进GSH，条件为4h培养且NAC在mM范围，不能改写为固定脑内有效阈值。

Reyes2016在EAAC1缺乏小鼠中将CSF NAC与神经元GSH/抗氧化能力联系，并以BSO阻断提供合成途径支持；正常神经元响应不同。鼠峰126±15nM与人体重复口服后CSF总NAC10.1±0.8μM是不同方案；人体Fig6E重用了其Ref24数据，不能把两篇图当作独立验证。CSF不是胞内自由浓度。NAC_slice2026的OGD切片GSH端点来自Table2，0.1与1mM后处理的数值不构成可辨识反应网络。

Townsend2016的BV2和原代小胶质细胞证据支持NRF2及LPS条件下IL1β/IL6/iNOS读数；此轮完整全文API失败，仅摘要级机制与已检索原文摘要可用，不填写未核对的精确反应幅度/EC50。RNA、蛋白和酶活保留各自观测。

## M7 Notch/Hes、自噬与耦合

Zhang2023的SH-SY5Y体系使用VPA4mM24h及NAC2mM2h。Fig8测Notch1、NICD、Jagged1、Hes1、Hes5蛋白（n=3，SD）；因此有NICD观察，不能一概声称只测总Notch。Fig7涉及LC3B-II/I、Beclin1和p62静态指标。数据支持该体系中的相关方向，未证明NAC直接结合Notch，也未识别形成/降解通量。ROS—Notch及Notch—自噬关系在讨论中仍有未解之处，不能将其他细胞类型证据拼成统一标定网络。原图获取TLS失败，因此只登记方向与条件，不伪造柱高、SD或拟合成绩。

## 参考来源登记

'''+table(refs))
    write('validation_report.md',f'''# 验证报告 v0.3

## 内部实现

24项M5–M7测试实际通过，见tables/test_log.txt。开放供应账本最大漂移{r['internal']['max_open_boundary_ledger_nmol']:.3g}nmol，参考求解器最大状态差{r['internal']['reference_solver_max_difference']:.3g}。这使用隔离的数值算例，不能证明生理预测准确。

## 原研究复现与留出检验

Kurano2022：自由制剂6个数字化均值拟合两参数指数信号；胶束制剂整组回顾性留出。log10-RMSE={nk['log_RMSE']:.6f}，最大倍数误差={10**nk['max_Elog']:.3f}；预测AUC0–90={nk['predicted_AUC']:.4f}，数字化观测={nk['digitized_AUC']:.4f} %ID/mL·min。最大近似SE距离={nk['max_SE_distance']:.3f}，严格2SE未全部通过。终点为总14C血浆信号，不是完整母体脑PK。

Son2021：保持v0.2低剂量参数冻结，不以测试尾部重拟合。5个可读高剂量晚期点log10-RMSE={sf['log_RMSE']:.6f}，max Elog={sf['max_Elog']:.6f}，未通过10倍量级筛查。4个早期重叠点仍未解析；不能全曲线评分、补峰值或择点报成功。原图Time(h)与Methods分钟矛盾仍保留。全部R/Elog见逐点表。

## PD与化学数据的用途

Danilov细胞死亡、NAC切片GSH、Reyes CSF汇总与Zhang蛋白方向均是背景观测，不是当前PD函数校准或独立验证。只依据单终点不估计EC50/Emax/Hill及多个τ。Son血浆半衰期到ln2/t的换算是推导自洽，不是独立数据检验。Bergström摘要持续时间只支持记忆/响应延迟的动机，不提供恢复时间拟合。

## 本项目模式

未接入项目实测输入，运输和有效暴露参数未冻结，项目预测未执行。没有M5–M7匹配独立研究外部验证。重画未来输入不算验证。

'''+stage_table)
    write('identifiability.md',r'''# 可辨识性与阶段删减

单剂量单终点 y=y0+y0 E C/(K+C)(1-exp(-T/τ)) 中，观测只有一个增量，E、K、τ的雅可比至多秩1；固定Hill=1仍不能解决。没有时间序列不估τ，没有多剂量不估EC50。qPCR、蛋白与酶活可能有不同时间尺度，不能复制一个τ。

固定浴液浓度曲线已包含净生成/损失，dC/dt不能分离生产、反应与取样：任意额外损失kC均可被增加同等补充抵消。只用母体共培养曲线不能辨识kf/kr和源项。原曲线到下游转换需要显式PS；只有下游暴露时PS、路径分流与有效比例常出现乘积混淆。

稳态自噬标志L=form/deg，form和deg成比例变化时L不变，通量变化却可任意。因此不从LC3/p62单点生成形成或降解率。NICD蛋白的观测不等于完整Notch配体结合动力学。选择一个有效直接运输池而非多个嗅球/CSF隐藏状态，是基于现有数据不能辨识解剖参数。

局部灵敏度仅在已标定原研究参数附近具有该研究含义；本项目没有可信鼻部参数范围，暂停总体Sobol/Morris或概率虚拟人群。
''')
    write('uncertainty_analysis.md','''# 不确定性与敏感性

项目实测输入误差：尚无数据，不生成输入或脑暴露区间。文献测量误差：保留SD/SEM、数字化±3像素和左删失；不把群体SD与均值SEM混称。原图误差条近似并不支持精确95%CI。结构未知：有效路径、供给边界/有限供给、未实现的缀合物运输/活性、脑暴露到有效细胞暴露的桥接均单独列明，不赋任意分布。

可解析灵敏度：外部浓度输入的线性运输分支，在其他参数冻结、无剂量非线性时，对输入统一缩放的AUC弹性为1；这是数学结构性质，不是鼻部生理测量。若有效脑到细胞比例ρ未知，脑侧PK与PD不能唯一分离。理想稳态反推，已知脑清除CL、目标自由浓度C及递送比例f时，最低可用跨上皮输入J=CL*C/f；f=0且目标正时无有限解。此目标只可来自明确研究条件，不能称临床阈值。当前不代入任意人体参数出数值。

Kurano回顾性信号模型可报告原研究k的一阶时间敏感性 dy/dk=-t*y；不能当成自由NAC脑清除敏感性。对原参数k的±5%确定性变化与局部导数记录于tables/literature_sensitivity.csv。没有新增动物实验要求。
''')
    k=json.loads((ROOT/'configs/literature_frozen.json').read_text())['Kurano2022']['k_min']
    csvout('tables/literature_sensitivity.csv',[dict(time_min=t,elasticity_to_k=-k*t,k_min=k,scope='same-study plasma total14C signal, not target physiology') for t in [0,3,15,30,60,90]])
    write('limitations.md','''# 限制

项目实测输入未取得。工程测试数值不填入项目配置。两药完整自由母体鼻脑运输、自由脑侧到有效细胞暴露和具名PD时间/剂量关系均未标定。省略脑内空间扩散不代表省略清除，也不证明跨脑区域均匀。药物进入集总脑池不等于细胞内浓度。

直接与系统路径合并后不能给出解剖途径比例。缀合物不运输是简化，不能当作永久无活性证据。若母体再生重要，当前省略会改变可用暴露，方向与幅度需匹配研究数据才能判断。通用终点响应不构成统一NRF2—GSH—Notch—自噬网络；不推出临床改善、剂量或四菌最优配比。

部分开放全文/原图入口失败，记录原错误，没有补造参数、柱高或误差。各研究之间不同物种、病理、给药及分析物限制迁移；重复发表/重绘数据不算独立。当前不能完成与本项目匹配的外部验证。未来仅接入团队正在进行的实验数据；不把新增动物或M5–M7验证实验作为本交付的任务要求。
''')
    write('iteration_log.md','''# 本次迭代与保留的失败

2026-10-14：按用户新范围收缩为M5–M7；不重新实现M1/M2，不做配比和临床优化。用户确认实测数据未取得。保留旧v0.2为只读参照，原SFN尾部失败不调参。

原接口由任意菌量/产率驱动改为明确的实测浓度边界或已知源有限池，两者互斥。去掉通用PD被误解释为具名通路的可能，采用终点标签与未约束参数拒绝机制；24项内部测试通过。

原文查证：Zhang细胞Fig8确有NICD，与Notch总蛋白分别记录；Fig7为静态自噬指标。共同变化不提供NAC直接结合证据。新增Reyes CSF摘要/全文背景与NAC切片Table2；未用于改动旧PK基准。Bergström/Dringen无可取得开放完整曲线；Townsend等API500及图片TLS失败保留日志。未进行测试集驱动调参，若未来更改SFN模型，当前尾部集需转为开发集另取新验证数据。
''')
    write('results_summary.md','# M5–M7 分阶段项目结果 v0.3\n\n已实现严格浓度接口、开放/有限供给量守恒、并行有效直接与系统运输、集总脑侧清除和终点特异PD接口。24项数值测试通过。两类通路均完成分阶段机制/观测审查，并归档真实文献端点及原PK留出失败。\n\n**项目实测输入和关键运输/PD参数未取得，因此没有生成项目鼻侧、脑侧或通路预测。没有匹配独立外部验证。**\n\n'+stage_table)
    write('wiki_model_draft.md','''# Model: measured-input interfaces and staged M5–M7 evidence

We separate measured simulated-nasal culture concentrations from human nasal exposure. Upstream M1/M2 are interface providers, not reconstructed colonization models. Free-parent SFN/NAC measurements can drive a bounded piecewise-linear concentration boundary. This open donor does not predict donor depletion, and observed donor chemistry is not applied twice. A mutually exclusive finite-donor mode requires independently known amount source terms and initial inventories.

Parallel effective direct and systemic routes feed a lumped free-parent brain-side pool with explicit clearance. A delay compartment is mathematical, not an obligatory olfactory-cell–CSF sequence. We do not calculate intracerebral spatial diffusion. CSF, tissue homogenate, total radiolabel and intracellular concentrations require separate observation bridges.

The antioxidant branch separates NRF2-related early responses, transcript, protein/enzyme and GSH/redox endpoints. NAC is treated as supporting cysteine availability rather than converting directly into GSH. The Notch/autophagy branch distinguishes total Notch1, NICD, Hes proteins and static LC3/p62 markers. Unknown causal cross-branch links are not activated. Endpoint-specific effect-site and indirect-response structures remain unparameterized where data are insufficient; no default EC50 is presented as a literature estimate.

Original-study PK benchmarks retain their own doses, routes, formulations and analytes. Retrospective within-study held-out conditions are reported separately from external validation. Raw sources, registries, numerical checks and failed predictions are available. No animal studies or new M5–M7 validation experiments are required from the team by this work.
''')
    write('wiki_results_draft.md',f'''# Results: numerical checks and retained evidence gaps

All 24 staged-interface and numerical tests passed, including finite/open supply ledgers, conjugate equivalents, parallel-route zero controls, analytic delay, effect-site kinetics, washout recovery and solver comparisons. These are software checks using isolated fixtures, not evidence of target-setting biological efficacy.

For the retrospective held-out Kurano2022 micelle group, the frozen plasma total-carbon-14 model had log10-RMSE {nk['log_RMSE']:.3f} and maximum fold discrepancy {10**nk['max_Elog']:.2f}. A stricter approximate two-SE requirement was not met at every point. The frozen Son2021 high-dose oral SFN late tail failed the permissive ten-fold screen (maximum absolute log10 discrepancy {sf['max_Elog']:.2f}); no parameters were adjusted to hide this failure.

Published antioxidant and Notch/autophagy measurements were organized by assay and condition. Single-dose endpoints were not used to fit EC50, maximal effect and multiple time constants. Zhang2023 includes a NICD measurement, while its static autophagy markers do not quantify autophagic flux. The NAC CSF bridge remains distinct from intracellular free concentration.

The team's experiments are ongoing and no measured input was available. Project prediction and PD calibration have therefore not been executed. No matched independent external validation or ASD clinical claim is made. The next authorized step is to ingest the existing planned concentration measurements with complete assay and sampling metadata and freeze only supportable parameters.
''')
    write('README.md','''# SUSTECH-MED staged M5–M7 v0.3

Read results_summary.md, scope_and_audit.md and evidence_report.html. This deliverable runs literature and numerical modes; project prediction is explicitly blocked by missing measured input and unparameterized physiology. Tests contain synthetic numerical fixtures only. No fixture is loaded by project prediction.

## Rebuild

Python3.12 with requirements-lock.txt. In a project venv, install `python -m pip install -r requirements-lock.txt`, then `python -X utf8 run_all.py`. All input archives required for offline rebuilding are included. Optional source refetch scripts are separate. The first build used the adjacent v0.2 project; portable rebuild falls back to reference_v02 and sources/literature_data copies.

## Later project run

Fill input_templates/concentration.csv with explicitly processed free-parent means and metadata.json with assay, sampling and error provenance. Keep raw files read-only. Configure independently justified transport and endpoint-specific parameters in a NEW JSON; project_unparameterized.json is deliberately not runnable as a biological prediction. `python scripts/run_project.py --input measured.csv --metadata metadata.json --config frozen.json --output project_results` refuses unknown coefficients or incompatible analytes. Do not set frozen=true merely to bypass missing evidence.

No M1/M2 growth reconstruction, brain diffusion PDE, clinical dosage optimization or new team animal experiment is included. Model/data/source/code version and hashes are recorded. A–E provenance is separate from pass/fail status. Original-study comparisons do not validate L168 brain exposure.
''')
    write('data_atlas.md','# 全部应用数据与角色\n\n'+table(data)+'\n\n'+'\n\n'.join('## '+row['dataset_id']+'\n\n'+table(read(ROOT/row['file'])) for row in data))
    # Standalone HTML reader: native links and visible source/condition records.
    def htable(rows):
        if not rows:return ''
        cols=list(rows[0]);esc=lambda x:html.escape(str(x))
        return '<div class="scroll"><table><tr>'+''.join('<th>'+esc(c)+'</th>' for c in cols)+'</tr>'+''.join('<tr>'+''.join('<td>'+esc(row.get(c,''))+'</td>' for c in cols)+'</tr>' for row in rows)+'</table></div>'
    body='<h1>M5–M7 分阶段 PK–PD v0.3</h1><p>项目实验进行中：本页没有模拟实测输入、人体脑暴露或具名PD精确预测。文献数据与数学核验分开展示。</p><h2>阶段与状态</h2>'+htable(scopes)+'<h2>文献</h2>'+htable(refs)
    body+='<p>'+''.join('<a href="'+html.escape(row['url'])+'">'+row['source_id']+'</a> · ' for row in refs)+'</p><h2>数据角色</h2>'+htable(data)
    for row in data:body+='<h3>'+row['dataset_id']+'</h3>'+htable(read(ROOT/row['file']))
    body+='<h2>图表</h2>'+''.join('<figure><img src="figures/figure_'+str(i)+'.png"><figcaption>Figure '+str(i)+'：详见图注与参数版本</figcaption></figure>' for i in range(1,9))
    body+='<p><a href="validation_report.md">验证报告</a> · <a href="equations.md">计算阶段</a> · <a href="input_contract.md">输入接口</a> · <a href="identifiability.md">可辨识性</a></p>'
    write('evidence_report.html','<!doctype html><html lang="zh"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>M5–M7 证据与数据</title><style>body{font:15px/1.7 system-ui;max-width:1400px;margin:30px auto;padding:0 20px;color:#243444}h1,h2{color:#185d72}.scroll{overflow:auto;max-height:650px;margin:16px 0}table{border-collapse:collapse;font-size:12px}th,td{padding:9px;border:1px solid #d2dfe4;min-width:85px;vertical-align:top}th{background:#eaf3f5}img{max-width:100%}a{color:#176484}figure{max-width:1100px}</style>'+body+'</html>')

if __name__=='__main__':main()
