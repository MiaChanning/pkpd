from fetch_primary import ROOT,OUT,get
import concurrent.futures,json,html,re
URLS={'Townsend2016_bioc':'https://www.ncbi.nlm.nih.gov/research/bionlp/RESTful/pmcoa.cgi/BioC_json/PMC4713291/unicode',
      'Reyes2016_bioc':'https://www.ncbi.nlm.nih.gov/research/bionlp/RESTful/pmcoa.cgi/BioC_json/PMC4720670/unicode',
      'Townsend2016_pmc':'https://pmc.ncbi.nlm.nih.gov/articles/PMC4713291/?report=xml',
      'Reyes2016_springer':'https://link.springer.com/article/10.1007/s13311-015-0404-4',
      'NAC_slice2026':'https://www.ebi.ac.uk/europepmc/webservices/rest/PMC13025480/fullTextXML'}
def fetch(item):
    key,url=item
    try:
        raw=get(url);(OUT/(key+'.raw')).write_bytes(raw)
        status='retrieved_unverified_content'
        if key.endswith('bioc'):
            d=json.loads(raw);text='\n'.join(p.get('text','') for doc in d for passage in doc.get('documents',[]) for p in passage.get('passages',[]))
            if not text:raise ValueError('No BioC scientific text')
            (OUT/(key+'.txt')).write_text(text,encoding='utf8');status='scientific_text_retrieved'
        return dict(id=key,url=url,status=status,bytes=len(raw))
    except Exception as e:return dict(id=key,url=url,status='failed',error=str(e))
if __name__=='__main__':
    with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:rows=list(pool.map(fetch,URLS.items()))
    (OUT/'alternative_log.json').write_text(json.dumps(rows,indent=2),encoding='utf8')
    print(json.dumps(rows,indent=2))
