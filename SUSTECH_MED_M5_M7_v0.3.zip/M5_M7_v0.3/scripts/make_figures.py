from pathlib import Path
import csv,json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch
ROOT=Path(__file__).resolve().parents[1]
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,'axes.spines.right':False,'svg.fonttype':'none','savefig.dpi':220})
BLUE='#24647d';ORANGE='#c76d30';GREEN='#348060';GRAY='#606c76';PURPLE='#74589b'
def read(file):
    with (ROOT/file).open(encoding='utf-8-sig') as f:return list(csv.DictReader(f))
def finish(fig,n,title,note):
    fig.suptitle(title,fontsize=14,fontweight='bold',y=.98)
    fig.text(.02,.015,'v0.3 | '+note,fontsize=8,color=GRAY,wrap=True)
    fig.tight_layout(rect=[0,.09,1,.93])
    for ext in ['svg','png']:fig.savefig(ROOT/'figures'/f'figure_{n}.{ext}',bbox_inches='tight')
    plt.close(fig)
def box(ax,x,y,w,h,text,color=BLUE):
    ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle='round,pad=.06',facecolor='#eff4f6',edgecolor=color,lw=1.4))
    ax.text(x+w/2,y+h/2,text,ha='center',va='center',fontsize=9)
def arrow(ax,a,b,*,hyp=True,label=''):
    ax.annotate('',xy=b,xytext=a,arrowprops=dict(arrowstyle='->',color=ORANGE if hyp else GREEN,lw=1.5,linestyle='--' if hyp else '-'))
    if label:ax.text((a[0]+b[0])/2,(a[1]+b[1])/2+.1,label,ha='center',fontsize=8,color=GRAY)
def main():
    fig,ax=plt.subplots(figsize=(14,8));ax.set_xlim(0,14);ax.set_ylim(0,8);ax.axis('off')
    box(ax,.2,6.4,2.6,.9,'M5: culture measurements\nfree SFN / free NAC')
    box(ax,3.5,6.4,2.4,.9,'SFN + NAC <-> SFN-NAC\n1:1 equivalents / matrix loss')
    box(ax,6.6,6.4,2.7,.9,'Epithelial crossing\nparacellular / transcellular')
    box(ax,10.2,6.4,3.3,.9,'Unresolved proportions\nnot tracer-derived coefficients')
    arrow(ax,(2.9,6.8),(3.4,6.8));arrow(ax,(6,6.8),(6.5,6.8));arrow(ax,(9.4,6.8),(10.1,6.8))
    box(ax,4.4,4.6,3,.9,'Direct extracellular / cellular\nolfactory or trigeminal routes')
    box(ax,8.2,4.6,2.5,.9,'Systemic blood route\nplus barrier crossing')
    arrow(ax,(7.4,6.3),(6,5.6));arrow(ax,(8.2,6.3),(9.3,5.6))
    box(ax,5.3,2.9,4.6,.9,'Brain-side exposure with clearance\nECF, CSF, homogenate and intracellular\nconcentrations are distinct observations')
    arrow(ax,(6,4.5),(6.3,3.9));arrow(ax,(9.3,4.5),(8.9,3.9))
    box(ax,.5,.75,5.9,1.35,'Branch A (study-specific evidence)\nSFN: KEAP1-NRF2 -> RNA -> protein / enzyme\nNAC: cysteine supply -> GSH / redox\nInflammation: assay-specific LPS responses',GREEN)
    box(ax,7,.75,6.2,1.35,'Branch B (NAC + VPA study context)\nNotch1 / NICD / Jagged1 / Hes proteins\nLC3B-II/I / Beclin1 / p62 abundance\nNo quantified autophagic flux or direct binding',PURPLE)
    arrow(ax,(6,2.8),(4,2.2));arrow(ax,(9,2.8),(10,2.2))
    ax.text(.3,7.7,'Mechanism review: dashed arrows are unresolved in the project setting.',color=GRAY)
    finish(fig,1,'M5–M7 anatomy and chemistry audit: parallel routes, separate readouts','Mechanism context: Son2021, Kurano2022, Reyes2016, Danilov2009, Zhang2023, Townsend2016. No target route is quantitatively validated.')
    fig,ax=plt.subplots(figsize=(13,5.5));ax.axis('off');ax.set_xlim(0,13);ax.set_ylim(0,5.5)
    box(ax,.3,3.8,3.2,.9,'A: measured free-parent C(t)\nopen donor; bounded interpolation')
    box(ax,.3,1.9,3.2,.9,'B: known R(t) + initial amount\nfinite donor; chemistry ledger')
    box(ax,4.3,2.8,3.3,1.1,'Choose A OR B\nJep = PSep x Cdonor\nNo duplicate source / loss')
    box(ax,8.3,3.5,3.8,1.1,'Direct delay + systemic pool\n-> lumped brain pool + clearance')
    box(ax,8.3,1.4,3.8,1.1,'Calibrated effective exposure?\n-> separate assay readouts\notherwise stop with evidence gap')
    arrow(ax,(3.6,4.2),(4.2,3.5),hyp=False);arrow(ax,(3.6,2.3),(4.2,3),hyp=False)
    arrow(ax,(7.7,3.4),(8.2,4),hyp=False);arrow(ax,(10.2,3.4),(10.2,2.6))
    ax.text(.4,.7,'Known interfaces and exact accounting are implemented. Biological coefficients remain null.',color=GRAY)
    finish(fig,2,'Minimal computational stages and supply contracts','Flux: nmol/h; amount: nmol; concentration: uM; time: h. Effect-site fractions and PD coefficients are not inferred from nominal doses.')
    fig,ax=plt.subplots(figsize=(11,5));ax.axis('off')
    fields=['Measured SFN/NAC time series','Free parent / recoverable parent identity','Matrix, volume and sampling','Replicates, controls, LOD/LLOQ','Transport / observation coefficients']
    cells=[[s,'Not supplied / not constrained'] for s in fields]
    tab=ax.table(cellText=cells,colLabels=['Project input requirement','Current evidence'],cellLoc='left',loc='center',colWidths=[.55,.45]);tab.auto_set_font_size(False);tab.set_fontsize(11);tab.scale(1,2)
    ax.text(.02,.08,'No synthetic input curve is plotted. Empty CSV/JSON templates accompany this audit.',transform=ax.transAxes,color=ORANGE)
    finish(fig,3,'Measured-input readiness: experiments are ongoing','User confirmed no experimental data yet. This is an input-status audit, not a concentration result or a validation figure.')
    fig,axes=plt.subplots(1,2,figsize=(12,4.8));sf=read('tables/son_comparison.csv');nk=read('tables/kurano_comparison.csv')
    t=np.array([float(r['time_min']) for r in sf]);axes[0].semilogy(t,[float(r['predicted_ng_mL']) for r in sf],color=BLUE,label='Frozen low-dose benchmark');axes[0].scatter(t,[float(r['observed_digitized_ng_mL']) for r in sf],color=ORANGE,label='Readable late literature points')
    axes[0].set(xlabel='Time (min, per Methods)',ylabel='Plasma parent SFN (ng/mL)',title='Rat PO 0.5 mg/kg: retained failure');axes[0].legend(fontsize=8)
    t=[float(r['time_min']) for r in nk];axes[1].plot(t,[float(r['predicted_total14C']) for r in nk],color=BLUE,label='Frozen signal model')
    axes[1].scatter(t,[float(r['calibration_total14C']) for r in nk],facecolors='none',edgecolors=GRAY,label='Free-formulation calibration')
    axes[1].errorbar(t,[float(r['heldout_total14C']) for r in nk],yerr=[float(r['approx_SE']) for r in nk],fmt='o',color=ORANGE,label='Micelle held-out, approximate SE')
    axes[1].set(xlabel='Time after administration completion (min)',ylabel='Plasma total 14C (%ID/mL)',title='Mouse IN NAC: original-study signal');axes[1].legend(fontsize=8)
    finish(fig,4,'Original-study PK comparisons remain separate from project prediction','Son2021 Fig8 time h/min conflict; Kurano2022 Fig2A digitized means. No parent-NAC brain or independent-study validation.')
    fig,axes=plt.subplots(1,2,figsize=(12,5));dan=read('literature_data/Danilov2009_Fig6_text.csv');treated=[r for r in dan if r['condition'] in ['vehicle_OGD','SFN_OGD']]
    axes[0].bar([0,1],[float(r['cell_death_percent']) for r in treated],yerr=[float(r['SEM_percent']) for r in treated],color=[GRAY,GREEN],capsize=4)
    axes[0].set_xticks([0,1],['OGD + vehicle','OGD + SFN 2.5 uM']);axes[0].set(ylabel='Cell death (%)',title='Rat astrocytes: 48 h post-treatment');axes[0].set_ylim(0,50)
    slices=read('literature_data/NAC_slice2026_Table2.csv');axes[1].bar(range(4),[float(r['GSH_total_nmol_mg_protein']) for r in slices],yerr=[float(r['SEM']) for r in slices],color=[GRAY,ORANGE,BLUE,GREEN],capsize=4)
    axes[1].set_xticks(range(4),['Control','OGD','OGD +\n100 uM NAC','OGD +\n1000 uM NAC']);axes[1].set(ylabel='Total GSH (nmol/mg protein)',title='Mouse cortical slices: 48 h endpoint')
    finish(fig,5,'Antioxidant branch: published endpoint context, no fitted pathway','Danilov2009 Results C / Fig6 (mean + SEM); NAC_slice2026 Table2 (mean + SEM, n=5). No EC50, uptake or time constant fitted.')
    fig,ax=plt.subplots(figsize=(12,5.8));ax.axis('off');rows=read('literature_data/Zhang2023_observation_definitions.csv')
    tab=ax.table(cellText=[[r['endpoint'],r['direction'],r['figure'],r['limitation']] for r in rows],colLabels=['Actual protein readout','NAC + VPA vs VPA','Source','Inference boundary'],cellLoc='left',loc='center',colWidths=[.2,.17,.1,.53]);tab.auto_set_font_size(False);tab.set_fontsize(9);tab.scale(1,1.7)
    finish(fig,6,'Notch/Hes and autophagy: observed directions and assay limits','Zhang2023: SH-SY5Y, VPA 4mM 24h, NAC 2mM 2h. WB protein and static markers. No invented fold changes, SD values or response curves.')
    fig,axes=plt.subplots(1,2,figsize=(12,4.8));ledger=read('tables/internal_ledger.csv');t=[float(r['time_h']) for r in ledger]
    axes[0].plot(t,[float(r['SFN_ledger_nmol'])*1e12 for r in ledger],label='SFN equivalent ledger',color=BLUE);axes[0].plot(t,[float(r['NAC_ledger_nmol'])*1e12 for r in ledger],label='NAC equivalent ledger',color=ORANGE)
    axes[0].set(xlabel='Numerical test time (h)',ylabel='Ledger residual (10^-12 nmol)',title='Open supply: transferred amount balanced');axes[0].legend(fontsize=8)
    axes[1].axis('off');axes[1].text(.02,.7,'24 internal tests passed\n\nZero input and all zero brain paths\nFinite donor + reversible conjugation\nNo double-counted boundary chemistry\nAnalytic delay and effect-site filters\nWashout recovery and solver comparison',va='center',fontsize=12)
    finish(fig,7,'Numerical verification: supply accounting and limiting cases','Synthetic numerical fixtures only; no physiological volume, transfer rate or EC50 is inferred. Internal pass is not biological validation.')
    fig,axes=plt.subplots(1,2,figsize=(12,4.8))
    axes[0].plot([float(r['time_min']) for r in sf],[float(r['E_log']) for r in sf],'o-',color=ORANGE,label='SFN high-dose late tail');axes[0].axhline(1,color=GRAY,ls='--',label='Permissive 10-fold boundary');axes[0].set(xlabel='Time (min)',ylabel='Absolute log10(predicted / observed)',title='All readable late points scored');axes[0].legend(fontsize=8)
    axes[1].plot([float(r['time_min']) for r in nk],[(float(r['predicted_total14C'])-float(r['heldout_total14C']))/float(r['approx_SE']) for r in nk],'o-',color=BLUE);axes[1].axhline(2,color=GRAY,ls='--');axes[1].axhline(-2,color=GRAY,ls='--');axes[1].set(xlabel='Time after dosing completion (min)',ylabel='Residual / approximate observed SE',title='Order agreement does not ensure 2-SE fit')
    finish(fig,8,'Residuals and retained failures: matching conditions matter','Within-study retrospective comparisons. Digitization uncertainty/covariance are not fully captured by SE distances. No matched independent validation.')
    captions=[
      'Mechanism audit distinguishes parallel direct/systemic transport and two separately evidenced PD branches. Dashed arrows denote unquantified project-setting links, not a required anatomical chain. Sources Son2021/Kurano2022/Shen2025/Danilov2009/Zhang2023/Reyes2016/Townsend2016; no axis for diagram.',
      'Computational contract: external measured concentration and finite donor are mutually exclusive. Effective delay and brain-side clearance are implemented; PD requires assay-specific calibration. All target coefficients remain in configs/project_unparameterized.json; no physiological prediction.',
      'Missing-input audit; the user confirmed experiments ongoing. No measured time series exists in the inspected workspace. Figure is status information, not a fabricated curve.',
      'Frozen Son2021 parent SFN oral high-dose late-point failure and Kurano2022 plasma total14C formulation holdout. Son time label conflict preserved; Kurano errors are approximately digitized SE. Curves are study-specific and cannot parameterize intact-parent nasal/brain exposure.',
      'Published means and SEM, exactly transcribed (not fitted curves). Rat astrocyte SFN post-treatment differs from 5uM pretreatment. Mouse slice NAC GSH readout is total glutathione per protein. The studies are separate; no cross-study causal network or EC50 inferred.',
      'Protein endpoint directions in Zhang2023. NICD was measured in cells and is separated from total Notch1. Static LC3/p62 abundance cannot quantify autophagic flux. Source figures could not be downloaded for reliable magnitude digitization; no magnitude/error is invented.',
      'New implementation internal checks use isolated test-only coordinates. Ledger residuals and count of tests are numerical evidence; no biological parameter has been identified from these runs.',
      'Every readable SFN late point and every Kurano held-out time point included. The 10fold screen is permissive and not a general accuracy criterion. Observed approximate SE distances do not include full parameter and time covariance.']
    (ROOT/'figures/captions.md').write_text('# Figure captions v0.3\n\n'+'\n\n'.join('## Figure '+str(i)+'\n\n'+c+' Parameter/data version: v0.3; frozen original-study PK coefficients in configs/literature_frozen.json, dataset roles in validation_registry.csv, sources in references.bib.' for i,c in enumerate(captions,1)),encoding='utf8')
if __name__=='__main__':main()
