from pathlib import Path
import urllib.request,urllib.parse,json,concurrent.futures,datetime,xml.etree.ElementTree as ET
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'sources';OUT.mkdir(parents=True,exist_ok=True)
IDS={'Bergstrom2011':'EXT_ID:20888844 AND SRC:MED','Dringen1999':'EXT_ID:10025562 AND SRC:MED','Townsend2016':'EXT_ID:PMC4713291 AND SRC:PMC','NAC_neuron2016':'EXT_ID:PMC4720670 AND SRC:PMC','Zhang2023':'EXT_ID:PMC10525405 AND SRC:PMC','Son2021':'EXT_ID:PMC8309207 AND SRC:PMC','Kurano2022':'EXT_ID:PMC9785447 AND SRC:PMC','Danilov2009':'EXT_ID:PMC2657190 AND SRC:PMC','Mi2010':'EXT_ID:20541518 AND SRC:MED'}
def get(url):
    req=urllib.request.Request(url,headers={'User-Agent':'SUSTECH-MED-stage-evidence/0.3'})
    with urllib.request.urlopen(req,timeout=30) as r:return r.read()
def fetch(item):
    key,query=item;row={'id':key,'query':query,'date':'2026-10-14'}
    query=query.replace('EXT_ID:PMC','PMCID:PMC').replace(' AND SRC:PMC','')
    endpoint='https://www.ebi.ac.uk/europepmc/webservices/rest/search?format=json&resultType=core&query='+urllib.parse.quote(query)
    try:
        raw=get(endpoint);data=json.loads(raw);(OUT/(key+'_metadata.json')).write_bytes(raw)
        results=data.get('resultList',{}).get('result',[])
        if not results:raise ValueError('No matched record')
        record=results[0];row.update(title=record.get('title'),doi=record.get('doi'),pmid=record.get('id'),pmcid=record.get('pmcid'),abstract=record.get('abstractText'),metadata_url=endpoint)
        pmcid=record.get('pmcid')
        if pmcid:
            url='https://www.ebi.ac.uk/europepmc/webservices/rest/'+pmcid+'/fullTextXML';row['fulltext_url']=url
            try:
                raw=get(url);xml=ET.fromstring(raw)
                if xml.tag!='article':raise ValueError('Not an article XML')
                (OUT/(key+'.xml')).write_bytes(raw)
                (OUT/(key+'.txt')).write_text('\n'.join(' '.join(p.itertext()) for p in xml.findall('.//body//p')),encoding='utf8')
                row['fulltext_status']='retrieved'
            except Exception as e:row['fulltext_status']='failed';row['fulltext_error']=str(e)
        else:row['fulltext_status']='no_PMC_fulltext_found'
        row['status']='metadata_retrieved'
    except Exception as e:row['status']='failed';row['error']=str(e)
    return row
if __name__=='__main__':
    with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:rows=list(pool.map(fetch,IDS.items()))
    (OUT/'retrieval_log.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2),encoding='utf8')
    for r in rows:print(r['id'],r['status'],r.get('fulltext_status'),r.get('title'))
