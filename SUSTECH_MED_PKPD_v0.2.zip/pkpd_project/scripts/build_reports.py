from pathlib import Path
import json,csv,hashlib,platform,sys,re
ROOT=Path(__file__).resolve().parents[1]
def write(name,text):(ROOT/name).write_text(text.strip()+'\n')
def build():
 r=json.loads((ROOT/'tables'/'computed_results.json').read_text());u=json.loads((ROOT/'tables'/'uncertainty_measurement.json').read_text());i=r['internal'];cur=r['literature_curves'];nk=cur['Kurano_heldout_micelle_plasma_label'];sf=cur['Son_PO05_late_subset']
 with (ROOT/'parameter_registry.csv').open() as f:params=list(csv.DictReader(f));fields=list(params[0])
 for name,val,unit,source,how,unc in [
  ('ke_rat_SFN_derived',r['son_frozen']['ke'],'min^-1','Son2021 IV CL/Vss','40.7/2268','Vss as one-compartment V is approximation'),
  ('ka_rat_SFN_derived',r['son_frozen']['ka'],'min^-1','Son2021 low-dose calibration','solve Tmax=log(ka/ke)/(ka-ke)','sampling/CL/Vss uncertainty not jointly estimated'),
  ('signal_amplitude_NAC_derived',r['kurano_frozen']['amplitude'],'%ID/mL plasma','Kurano2022 free group only','log-linear fit of 6 digitized means',str(u['amplitude_q025_q975'])),
  ('signal_decay_NAC_derived',r['kurano_frozen']['k_min'],'min^-1','Kurano2022 free group only','log-linear fit; not chemically specific CL',str(u['k_min_q025_q975']))]:
  row={k:'' for k in fields};row.update(parameter=name,symbol=name,module='M6 literature benchmark',meaning='derived study-specific effective model parameter',value=val,range=unc,original_unit=unit,model_unit=unit,source_url='https://doi.org/10.3390/pharmaceutics13070958' if 'SFN' in name else 'https://doi.org/10.3390/pharmaceutics14122590',source_location=source,species='rat' if 'SFN' in name else 'ddY mouse',tissue='plasma',route='IV/PO' if 'SFN' in name else 'intranasal',analyte='parent SFN' if 'SFN' in name else 'total14C signal',extraction=how,uncertainty=unc,conversion='minute benchmark; x60 gives h^-1',purpose='calibration_frozen_before_heldout',extrapolation_risk='not used as nasal brain or intact NAC coefficient',evidence='D',parameter_class='derived_mathematical_model_parameter')
  if unit!='min^-1':row['conversion']='identity'
  params=[z for z in params if z['parameter']!=name];params.append(row)
 with (ROOT/'parameter_registry.csv').open('w',newline='') as f:
  writer=csv.DictWriter(f,fieldnames=fields);writer.writeheader();writer.writerows(params)
 log=(ROOT/'tables'/'test_log.txt').read_text() if (ROOT/'tables'/'test_log.txt').exists() else 'Test log not saved'
 match=re.search(r'Ran (\d+) tests',log);count=match.group(1) if match else 'see test_log'
 cols=['模块','机制依据','参数依据','验证数据','验证指标','实际结果','证据等级','状态','主要限制','下一步']
 rows=[
 ['M1','鼻清除/外菌株驻留','无L168沉积/驻留参数','解析一阶清除','解析误差/非负','解析对照通过；无生理验证','E;背景C','证据不足','三区仅合并初值','喷雾存活/黏附CFU'],
 ['M2','资源限制一般机制','四株μ/死亡/竞争未知','无本项目CFU','资源耗尽/非负','内部资源测试通过；未拟合','E','证据不足','不能分株辨识','四株单独和混合分株CFU'],
 ['M3','化学计量/氨同化机制','计量D;路线和速率E','无Gln/NHx/Glu曲线','N账本漂移','N守恒通过；L168反应未证实','D/E','证据不足','产物账本非实际产物确认','同步N底物与产物定量'],
 ['M4','深层淋巴结构/人示踪限制','菌可及表面PS未知','零交换/无菌稳态基准','脑额外差/稳态','零交换差=0；生理通路未验证','E;机制C','证据不足','CSF淋巴≠鼻表面','屏障通量证据/双池原则验证'],
 ['M5','SFN-NAC干扰与分析物区分','L168产量与鼻化学常数缺失','当量/有限前体基准','当量守恒/零源','内部通过；无真实生产预测','E;计量D','证据不足','缺特异性胞外母体定量','LCMS生产/稳定性/共存'],
 ['M6','原始PK研究','大鼠基准B;鼻脑参数E','Son表1与图8;Kurano图2','log误差/AUC/时间尺度','NAC信号量级通过；SFN晚尾未通过','B限原研究;目标E','未通过','同研究留组≠独立研究;标记≠母体','匹配分析物/途径PK及新验证集'],
 ['M7','细胞NRF2/特定VPA-Notch','仅名义处理浓度B;EC50未知','处理条件汇总，无匹配PD曲线','具名PD拟合未执行','通用响应算例；具名网络暂缓','C/E','证据不足','浴液≠ECF/胞内','多剂量时间曲线与观测桥接'],
 ['M8','真实联立接口实现','全部工程能力尚未知','局部/单参数软件情景','敏感性/反推','已扫描；最优四菌配比未执行','E','未评估','无可信范围或组合验证','冻结单模块后预测独立组合']]
 with (ROOT/'tables'/'module_summary.csv').open('w',newline='') as f:w=csv.writer(f);w.writerow(cols);w.writerows(rows)
 table='| '+' | '.join(cols)+' |\n|'+ '|'.join(['---']*len(cols))+'|\n'+'\n'.join('| '+' | '.join(row)+' |' for row in rows)
 write('results_summary.md',f'''# SUSTECH-MED 多尺度 PK–PD 项目结果（v0.1）

完成了两份材料审查、原始证据检索、参数/验证数据登记、可运行最小联立模型、数值核验、文献条件留出比较、敏感性/反向分析和七张SVG/PNG图。**没有完成匹配的独立研究外部验证，也没有证明四菌鼻腔方案产生脑侧治疗效应。** 工作区无真实L168湿实验/原模型代码；缺口无法以合成测量填补。

## 可确认的计算结果

- {count}项内部测试通过；氮账本最大漂移{i['nitrogen_max_drift_nmol']:.3g} nmol N；SFN/NAC当量漂移分别{i['SFN_equivalent_max_drift_nmol']:.3g}/{i['NAC_equivalent_max_drift_nmol']:.3g} nmol。
- 零脑—鼻有效交换下，有菌/无菌脑浓度额外差为{i['zero_exchange_max_brain_difference']:.1f}；零药物源下暴露为{i['conservative_max_drug_nmol']:.1f}。求解器对照最大绝对差{i['reference_solver_max_abs']:.3g}（混合单位向量；逐项allclose测试亦通过）。
- Kurano2022同论文留出制剂组：6个血浆**总14C信号**时间点log10-RMSE={nk['log_RMSE']:.4f}，最大倍数误差{10**nk['max_Elog']:.3f}；AUC0–90预测{nk['predicted_AUC0_90']:.2f}、数字化观测{nk['observed_digitized_AUC0_90']:.2f} %ID/mL·min，相差{abs(nk['predicted_AUC0_90']/nk['observed_digitized_AUC0_90']-1)*100:.2f}%。峰值时间均为首个0min观测，不代表真实吸收达峰时间。
- 更严格的近似2SE覆盖未全部通过，最大偏差{nk['max_approx_SE_distance']:.2f} SE。数量级通过不等于预测已符合测量误差，更不等于完整NAC脑PK验证。
- Son2021冻结低剂量参数后：0.5mg/kg AUCinf预测9.56 vs 31.0 μg·min/mL（R=0.308）；半衰期38.63 vs 320min（R=0.121）。虽然都在10倍内，**5个可读晚期浓度点整体未通过**，最大Elog={sf['max_Elog']:.2f}；不能挑选峰值宣称模型成功。

## 按模块汇总

{table}

“通过”仅适用于列出的内部检查或指定筛查；总体状态如表。最优配比未评估。详见validation_report.md及tables/逐点结果。

## 对十二项完成标准的回答

1. 有依据的过程：鼻部乳酸菌适应性、资源限制、含氮化学计量、深层CSF淋巴外流、SFN-NAC干扰、SFN特定细胞NRF2响应、NAC特定VPA模型Notch/自噬关联。
2. 假设：L168四菌实际功能、表面驻留、脑→菌可及表面交换、两药自由母体鼻脑运输和脑ECF→细胞响应。
3. 来源：每个联立配置参数登记；目前无A，除坐标/计量外均E工程算例。文献PK为原条件B，外推到目标需C，未移植。
4. 真实可复用数值：Son Table1精确转录、IV完整9点数字化及高剂量5个可读晚期点；Kurano完整6点×2组数字化；SAS删失汇总；两项明确细胞处理条件。
5. 内部检查：守恒、零源、零交换、有限资源、稳态、非负、解析清除/双池/Erlang、步长/参考求解器通过。未用PDE，网格收敛不适用。
6. 独立数据验证：只完成同研究不同整条件留出比较；没有匹配的独立研究外部验证或L168湿实验留出验证。
7. 数量级/趋势/时间：NAC信号下降方向与AUC大致匹配，但早期点未全在2SE内；SFN线性模型失去高剂量长尾与更长半衰期，汇总量级筛查掩盖失败。SFN图小时/分钟冲突和5min采样问题已记录。
8. 仅合理性/情景：所有目标菌鼻部与脑部输出、细胞暴露比较、反向输入要求；没有人体PD或临床验证。
9. 敏感性：工程算例中SFN产率弹性约+1.00、活菌丢失约−0.985；这些排序依赖E参数，不能据此断言真实生理排序。
10. 主要瓶颈：是否存在到菌可及鼻表面的有效交换；真实胞外母体量、有限驻留、可用前体、相互作用/清除和自由药物到脑的递送比例。
11. 支持的结论：实现算术正确、某些原研究量级比较和失败诊断。条件性结论：给定PS和源项的脑变化；没有四菌优越性或ASD改善证据。
12. 下一轮：先确认构建/反应路线与分株CFU；同时测Gln/NHx/Glu/实际N产物和SFN/NAC特异胞外量；再做无菌稳定性/共存及冻结参数后的整组混合预测。

## 反向可行性的含义

无限汇、单池稳态下，10%研究性变化要求e/h至少0.111，50%要求至少1；真实条件一般更苛刻。这不是生理交换估计或临床目标。药物可达比例降10倍，所需生产提高10倍；比例为0时有限产量不能达到正目标。没有可信的PS/转运范围，当前不能判断这些要求可实现。

数值工程fixture给出的绝对脑浓度不作为生理结果推荐，原始数值保留在computed_results.json供复现。细胞5μM SFN/2mM NAC均不是脑细胞内阈值。
''')
 write('validation_report.md',f'''# 验证报告（v0.1）

## 证据分层与冻结

validation_plan.md先定义数据角色；这是已看过图和表的回顾性留组，非前瞻注册。联立鼻模型未校准。Son基准只取IV的CL/Vss与PO0.1的F/Tmax；Kurano只用free-NAC组拟合信号衰减。没有利用留出结果重新拟合。

## 内部核验

{count}项测试通过；完整输出见tables/test_log.txt。实际数值：

```json
{json.dumps(i,indent=2,ensure_ascii=False)}
```

这是求解实现核验，不是机制或人体效应验证。没有截断负状态；发现显著负值则报错。无空间模型，空间收敛未评估且不适用。

## 文献SFN基准：未通过完整预测要求

原始Table1，男SD大鼠，LC–MS/MS母体SFN，n=4。单室假设V=Vss，ke=CL/Vss={r['son_frozen']['ke']:.6f} min⁻¹；ka={r['son_frozen']['ka']:.6f} min⁻¹；F=0.778。口服0.2与0.5整剂量组留出。

精确汇总误差见son_heldout_metrics.csv（8个终点全部列出）。所有终点在10倍内，但多个终点不在2倍内。0.5剂量AUC低估3.24倍、终末时间尺度低估8.28倍；5个可读晚期点log-RMSE={sf['log_RMSE']:.3f}，最大Elog={sf['max_Elog']:.3f}，10倍筛查未通过。早期重叠点缺失而非补造，不称为整条口服曲线数字化验证。

IV9点同研究重现log-RMSE={cur['Son_IV_reproduction']['log_RMSE']:.3f}，10倍筛查通过但2倍未全通过。这些观测与CL/Vss来自同研究，不能叫独立验证。

失败排查：单位按方法改为min并保留图h冲突；原始表核对；剂量和分析物匹配；求解无异常。IV终末半衰期61.3min与CL/Vss单室推得38.63min不同，说明Vss并非唯一终末动力学体积；原研究还报告高剂量非线性和SFN-NAC形成。证据支持继续研究更丰富PK，却不足以唯一拟合其所有速率。本轮不在验证集上增加自由参数直到通过。

另外，方法口服采样从15min开始而0.2表列Tmax5min，尚未解决。reported F高剂量251.4%是相对剂量归一化AUC计算结果，不能当作有界吸收概率输入模型。

## NAC总标记基准：数量级筛查通过，严格误差仍有限制

图2A的6个点均使用；像素轴映射/点位/近似SE在extract_data.py。均值和SE为图像近似，额外像素误差记录；非作者个体原始数据。

冻结拟合A={r['kurano_frozen']['amplitude']:.6f} %ID/mL，k={r['kurano_frozen']['k_min']:.6f} min⁻¹。留出的另一制剂组log-RMSE={nk['log_RMSE']:.5f}，最大Elog={nk['max_Elog']:.5f}；6点均过2倍/10倍筛查；AUC差{abs(nk['predicted_AUC0_90']/nk['observed_digitized_AUC0_90']-1)*100:.2f}%。首点偏差约{nk['max_approx_SE_distance']:.2f} SE，2SE覆盖不是全部通过。

观测方向均为下降；峰值在首个0min时间点，不能检验此前吸收上升/真正达峰时间。仅证明这个简短信号基准对同研究另组有粗量级解释力。母体NAC脑ECF、标记代谢归属、鼻菌持续生产、跨物种与人体均未验证。

## 严格external validation与plausibility

匹配的独立研究external validation：**未完成，证据不足**。L168增长/代谢/生产、人体表面PS、两药自由脑暴露和具名PD：**证据不足**。SAS人CSF低检测率仅作为跨途径暴露限制，不给R分数；BQL留为删失。细胞处理条件不用于EC50拟合。

Peking层级思想用于区分内部数学测试、文献条件比较、工程情景和真实外推。公开AiiA公式复算D≈96.22μm²/s而表中0.0096，相差约10000倍；没有据此导入任何参数，未重跑其仓库。
''')
 write('uncertainty_analysis.md',f'''# 不确定性与可辨识性

## 三种来源分开处理

1. A类本项目测量：缺失，未传播，也未绘制虚构湿实验误差条。
2. 原研究测量：Son表保留原SD，Kurano均值/SE近似数字化。对free组采用1000次固定随机种子20261010的正值采样：独立正态均值误差+均匀像素误差，再拟合2参数衰减。A的2.5–97.5%区间{u['amplitude_q025_q975']}；k/min区间{u['k_min_q025_q975']}。这是近似测量误差传播，不是原始数据bootstrap、严格人群CI或鼻脑预测区间；跨时协方差未知。
3. 结构/生理未知：联立参数E没有可信分布。只做0/0.1/0.5/1/2/10倍相对工程fixture的确定性扰动；不能按此生成“虚拟人群”。未做Sobol/Morris/鲁棒优化，原因是范围不可信，额外抽样会制造伪统计精度。

## 控制因素

局部弹性见local_sensitivity.csv。当前fixture的SFN脑AUC对qS约+1.001、活菌丢失−0.985、系统分流+0.820、脑清除−0.777。递送/产率/驻留均为E，因此不是实证排序；改变零路径或更强缀合可能改变排序。

低浓度饱和反应只辨识q/K；仅最终脑输出常辨识q×递送比例而非两者。2参数NAC信号有效衰减不等于分开识别吸收、CL、V或脑运输。单剂量PD不能识别多通路自由参数。

## 分布无关的反推

reverse_exchange.csv为理想单池无限汇稳态所需e/h，目标只是研究数学比例。reverse_production.csv给出输入/(C_target V_B k_B)=1/(f a)。取值网格是坐标范围，不是生理范围。零交换/零递送是明确失败边界，不能靠增大菌产量消除。

## 优先测量

本项目最先需要真实胞外产率与净氮反应，随后鼻部活菌驻留和药物化学稳定性。表面可及交换与自由母体脑运输是生理桥接瓶颈：没有这些，四菌配比优化无法可信地排序。文献数据的化学分析物匹配优先于更多参数拟合。
''')
 write('limitations.md','''# 适用限制与未完成事项

- 未提供四株构建体/反应路线、湿实验原始数据、旧PKPD代码或完整细胞实验；没有A类参数。
- M1三区仅初始沉积，随后合并一表面池；没有区域驻留动力学、黏附状态或空间分辨PDE。
- M2/M3/M5可运行但只用显式工程算例；抽象资源账本不是碳/ATP网络，氮固定产物不是已确认缬氨酸。
- 脑—菌可及鼻表面交换未证实。CSF外流与表面汇分开；人MRI未检出不是所有小分子交换必为零的证明。
- SFN/NAC母体、缀合物、总标记、组织匀浆、ECF、CSF及细胞培养名义浓度不可互换。
- 联立模型缺匹配物种/部位体积、分配、宿主恢复、有效转运参数。体积1mL等仅为可复现的软件fixture，不是人体参数或生理范围。
- 只完成原研究内回顾性条件留出；图已先观察，不是盲法前瞻测试。没有独立研究全链验证。
- 数字化基于低分辨率图，均值/SE近似；SFN早期重叠点不编造；time h/min和5min采样矛盾保留。
- SFN一室线性模型高剂量晚尾失败，未在留出数据上升级结构并声称验证通过。
- M7通用响应未标定；具名NRF2/GSH/GPX4/Notch/炎症定量网络及ASD临床映射暂缓。
- 有限缀合物运输/解离模型缺全部代谢物、组织释放/活性和样本处理化学；其无效或安全性不由本模型证明。
- 无可信参数范围，所以未评估稳健最优四菌配比、Sobol指标或人体剂量；局部弹性只是算例性质。

允许的用途：检查守恒/接口，复现指定文献数值，公开失败和数据缺口，规划可辨识测量与条件性反推。当前不能用于人体治疗、鼻喷安全性或疗效剂量推断。
''')
 write('iteration_log.md',f'''# 版本与反馈记录

|阶段|发现/结果|修正或决定|证据与状态|
|---|---|---|---|
|v0.1审查|仅两份材料，无原代码/湿实验|新建最小模块；原输入不改|文件盘点；未推定A参数|
|结构审查|M5示意式遗漏显式黏液药物损失；氮净释氨率可能<1|补独立累计损失与未解析固定N账本|单位/计量依据；内部通过|
|基线审查|CSF外流+任意初值会漂移|固定宿主源并求每个匹配控制稳态|解析线性系统；无菌稳态通过|
|数据处理|MDPI图下载403、EuropePMC部分500|用PMC同原论文图与全文替代，保留访问日志|原图存档及哈希，未编造缺点|
|单位反馈|SFN图8标h，方法采样min；Tmax5min冲突|按方法min；5min未替作者修订|原文方法/表格；冲突仍未解决|
|拟合前简化|6个NAC均值不足以支撑4自由参数|拟合前将拟议双指数减成2参数单指数|可辨识性判断，未用留出误差选结构|
|数值核验|氮/两药/零效应/解析/求解器检查|通过{count}测试；未用截断掩盖负值|见test_log及computed_results|
|留出比较|NAC总信号量级通过；首点约{nk['max_approx_SE_distance']:.2f}SE|保留两种标准结果，不称母体脑验证|同研究整组留出；external不足|
|留出失败|SFN高剂量晚尾严重低估|不回调参数；说明线性/一室假设限制|原研究非线性与计量匹配；未通过|
|不确定性|宿主/产率范围不可约束|分开测量传播、结构扫描与反推|不生成虚拟人群或鲁棒最优配比|
|图表核查|四菌算例相同参数而曲线重叠；原报告需标注|图注明重叠与fixture；图6显示失败及总信号|PNG视觉核验；SVG/PNG同步|

未发生验证集反复调参。未来若根据SFN失败更换模型，当前高剂量组即转为开发信息，新的独立测试条件必须另行保留。
''')
 write('wiki_model_draft.md','''# Model — an evidence-audited four-function research framework

We developed an amount-based model to connect four candidate bacterial functions with nasal residence, nitrogen metabolism, chemical availability and conditional host exposure. The starting materials describe a proposed system; no target-strain wet-lab measurements were supplied. Accordingly, this implementation is a numerically verified research framework, not a validated physiological prediction of the four L168 strains.

## Mechanisms and model scope

Three deposition fractions define the initial accessible bacterial count. Subsequent residence is represented by one effective surface pool. Resource-limited growth and functional precursor pools prevent unlimited production. Gln contains two nitrogen atoms, and ammonia assimilation transfers nitrogen into an explicit product ledger. The precise target-strain route and products remain unconfirmed.

Brain ECF, CSF and nasal surface pools exchange amounts through paired fluxes. Normal CSF lymphatic drainage leaves the host model; it is not redirected to surface bacteria. Hong2026 supports a deeper lymphatic route, while Melin2020 provides a human tracer limitation. The effective surface-exchange parameter is therefore unknown and includes zero.

SFN and NAC have distinct free, transit, systemic, brain and CSF pools. A reversible 1:1 conjugation reaction transfers both drug equivalents into SFN-NAC. Mi2010 motivates chemical interference, but does not determine nasal reaction rates. Each transfer is debited and credited once. A two-stage Erlang chain represents delay mathematically. A generic response interface is uncalibrated and is not interpreted as a quantitative named pathway or clinical score.

## Parameters and validation

Every coupled-model coefficient is registered. Nonzero nasal parameters are explicit engineering fixtures, not inferred human values. A–E provenance is kept separate from validation status. Time is in hours, amounts in nmol and volumes in mL; nmol/mL equals micromolar concentration.

We tested nonnegativity, nitrogen and drug-equivalent balances, finite resources, source-free exposure, zero-exchange controls, analytic residence/two-pool/Erlang benchmarks and solver convergence. Literature PK benchmarks were evaluated in their original conditions and kept separate from the uncalibrated nasal model. Son2021 low-dose data constrain a frozen linear SFN benchmark; other dose conditions test its limits. Kurano2022 free-formulation plasma radiolabel data calibrate a two-parameter signal model, with the other formulation held out. These are retrospective within-study comparisons, not independent-study validation.

Measurement-error propagation is confined to the literature signal benchmark. Unconstrained physiological parameters are explored through deterministic scenarios and reverse feasibility equations, without assigning population distributions. Peking2025 motivates this layered reporting; its equations and success claims were not imported.

Code, input records, extraction coordinates, configurations, tests and data-role registries are included. References use the keys in references.bib. Figure captions explicitly distinguish archived literature observations from engineering scenarios.
''')
 write('wiki_results_draft.md',f'''# Results — verified calculations, literature comparisons and unresolved barriers

## Numerical checks

All {count} implemented checks passed. The nitrogen-ledger drift was {i['nitrogen_max_drift_nmol']:.3g} nmol N; the SFN and NAC equivalent drifts were below 1e-15 nmol in the nonzero engineering fixture. With effective brain-to-surface exchange set to zero, nasal bacteria produced no additional brain metabolite change. With no SFN/NAC source, drug exposure remained zero. These results verify the implementation of the selected equations, not the biological efficacy of the proposed strains.

## Literature comparisons and retained failure

For the held-out micelle group in Kurano2022, all six digitized plasma radiolabel means were within {10**nk['max_Elog']:.2f}-fold of the frozen signal model; log10-RMSE was {nk['log_RMSE']:.3f}. The predicted and digitized AUC0–90 were {nk['predicted_AUC0_90']:.2f} and {nk['observed_digitized_AUC0_90']:.2f} %ID/mL·min. Not every point met a stricter approximate two-SE criterion. This comparison concerns total carbon-14 signal, not intact NAC in brain ECF, and remains within one study.

The frozen linear SFN benchmark did not explain the high-dose oral tail in Son2021. At 0.5mg/kg, predicted AUCinf was 9.56 versus 31.0 μg·min/mL, and predicted half-life was 38.63 versus 320min. These summaries fell within a permissive ten-fold screen, yet the readable late concentration points failed it. We retained the failure rather than modifying parameters against the test data. Figure time labeling and a sampling/Tmax inconsistency are recorded in the extraction notes.

## Conditional design boundaries

The coupling model provides scenarios, not measured brain concentrations. A perfect-sink, single-host-pool steady-state analysis requires an exchange-to-homeostasis ratio of at least 0.111 for a hypothetical 10% change. This is a research comparison, not a physiological estimate or clinical target. At zero delivery fraction, no finite production rate reaches a positive brain-exposure target.

Within the arbitrary engineering fixture, SFN brain AUC is most sensitive to production and bacterial loss among the tested local perturbations. Because these parameters are unmeasured, this ranking cannot establish a real optimal strain ratio. No robust optimum was evaluated.

## Evidence status and next experiments

No matched independent-study validation or target-strain wet-lab calibration has been completed. The key missing links are actual extracellular parent-drug production, nitrogen-product identity, nasal residence, accessible surface exchange and chemically specific brain exposure. Next work should quantify strain-resolved counts, Gln/ammonia/Glu and nitrogen products, and SFN/NAC production and stability. Parameters should then be frozen before predicting a fully held-out mixed-strain condition. No ASD clinical improvement is inferred from these calculations.
''')
 captions=['Architecture: dashed target-setting links are unquantified. Mechanism context: Shen2025/Hong2026/Melin2020/Mi2010.',
 'Bacterial engineering fixture and analytic first-order residence. Equal counts/loss rates cause four curves to coincide. No experimental points.',
 'Candidate Gln/NHx rates and nitrogen-ledger numerical drift. Chemical stoichiometry is conserved; product route unconfirmed.',
 'One-host-pool perfect-sink upper envelope and matched-control coupled scenarios. PS labels are arbitrary perturbations, not measured physiological range.',
 'Finite-source SFN/NAC co-production and conjugation; all drug losses accounted. Reaction-rate values are uncalibrated. Mi2010 supplies mechanism context.',
 'Frozen SFN high-dose late-tail failure (Son2021); digitized NAC total14C held-out plasma comparison and approximate SE/measurement envelope (Kurano2022). Not brain PD validation.',
 'Local elasticity in engineering fixture and dimensionless reverse production requirements. No human optimal strain ratio or probabilistic robustness claim.']
 fixture_hash=hashlib.sha256((ROOT/'configs'/'engineering_fixture.json').read_bytes()).hexdigest()
 write('figures/captions.md','# Figure captions (v0.1)\n\nFixture SHA256: '+fixture_hash+'\n\n'+ '\n\n'.join('## Figure '+str(j)+'\n\n'+t+' Parameter version: v0.1; configs/engineering_fixture.json, or son_frozen.json/kurano_frozen.json for Figure6. Full sources: references.bib; data: validation_registry.csv. No missing wet-lab observations were synthesized.' for j,t in enumerate(captions,1)))
 write('README.md',f'''# SUSTECH-MED evidence-audited PK–PD research model v0.1

This is a runnable, numerically checked minimum framework plus literature benchmark analyses. **It is not an externally validated L168 nasal/brain efficacy model.** Read results_summary.md (Chinese) first, then model_audit.md and validation_report.md.

## Run offline

```bash
python run_all.py
```

Python 3.11+ with numpy, scipy, matplotlib. Exact tested package versions are in requirements-lock.txt. No requests/pandas/ML dependency is needed. Windows: use `py run_all.py` if `python` is unavailable. Inputs are archived; no network is needed for the main run. Source refetch is separate and optional: `python scripts/fetch_sources.py`; it can fail due to provider access restrictions and must not replace evidence with empty pages.

run_all rebuilds explicit fixture configs, transcribes/digitizes the archived data, executes tests, freezes study-specific parameters, scores held-out conditions, propagates approximate measurement error, generates figures and reports. It only writes generated files within this project; uploaded inputs and archived original measurements are not overwritten. It does not automatically update/fit target-strain parameters because no corresponding raw data were supplied.

## Contents

- src/model.py: coupled M1–M6 amount model and generic uncalibrated response.
- src/literature_pk.py: separate study-specific PK/signal benchmarks.
- configs/: zero-unverified-source default and nonzero engineering fixture, plus frozen benchmark fits.
- parameter_registry.csv / parameter_notes.md: all parameters, units, provenance and limits.
- calibration_datasets/ and validation_datasets/: distinct roles; exact transcriptions and approximate digitization. Dataset metadata in validation_registry.csv.
- inputs/: untouched uploaded proposals. No pre-existing code or wet data was present.
- literature_sources/: downloaded original texts, failed-access log, hashes; short challenge pages are explicitly not scientific evidence.
- figures/: seven SVG and PNG figures; captions.md.
- tables/: computed trajectories, per-point comparisons, all failures, sensitivities and module status.
- tests/ and tables/test_log.txt: numerical checks. Spatial grid convergence is inapplicable to this ODE model.
- reports: scientific audit, review, validation, iteration, uncertainty, limitations, Chinese summary and English Wiki drafts.

## Use boundaries

1. Fixture numbers including 1mL volumes are chosen software coordinates, not physiological priors or doses. All are E unless an exact coordinate/stoichiometric relation is D.
2. Literature values remain in their original rat/mouse/cell conditions. Total14C signal is never relabeled as intact NAC; oral SFN is never relabeled as nasal PK.
3. Within-study held-out-condition comparisons are not independent-study validation. SFN late-tail failure is preserved. A ten-fold screen is not proof of predictive accuracy.
4. Named PD networks and robust strain optimization are deferred for insufficient identifiable data. No clinical benefit/safety prediction is made.

For wet-lab data and observation mapping, see data_requirements.md. Parameter edits invalidate frozen report/manifest hashes until rerun. Source archives are included for traceability; respect each original publisher's license when redistributing text/figures.
''')
 # File-integrity manifest is refreshed after all generated files are written by run_all.
if __name__=='__main__':build()
