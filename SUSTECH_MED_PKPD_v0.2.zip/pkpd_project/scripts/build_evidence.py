from pathlib import Path
import csv,json,hashlib,re,html
ROOT=Path(__file__).resolve().parents[1]
REFS=[
 ('Shen2025','Engineered commensals for targeted nose-to-brain drug delivery','2025','10.1016/j.cell.2025.01.017','https://pubmed.ncbi.nlm.nih.gov/39914382/','M1/M6','PubMed/search metadata; quantitative full text not accessed','Engineered L. plantarum delivery in a different payload/animal system; target construct and SFN/NAC rates not verified.'),
 ('Hong2026','CSF clearance through arachnoid fenestrations to olfactory meningeal lymphatics','2026','10.1016/j.cell.2026.06.035','https://pubmed.ncbi.nlm.nih.gov/42480526/','M4','PubMed abstract accessed','Mouse tracers and primate anatomical comparison support lymphatic drainage to cervical nodes; no quantified lumen-accessible surface exchange.'),
 ('Melin2020','In vivo assessment of cerebrospinal fluid efflux to nasal mucosa in humans','2020','10.1038/s41598-020-72031-5','https://www.nature.com/articles/s41598-020-72031-5','M4','Full text','Human intrathecal MRI tracer study did not detect significant enrichment in nasal mucosal ROIs. Spatial resolution and tracer properties limit inference; not a bound on Gln PS.'),
 ('Shang2021','Prediction of nasal spray drug absorption influenced by mucociliary clearance','2021','10.1371/journal.pone.0246007','https://journals.plos.org/plosone/article?id=10.1371/journal.pone.0246007','M1','Full text','Nasal geometry and modeled mucus velocities provide transport framework. Model-selected average 6 mm/min is not a measured L168 residence rate.'),
 ('DeBoeck2020','Lactobacilli Have a Niche in the Human Nose','2020','10.1016/j.celrep.2020.107674','https://www.cell.com/cell-reports/fulltext/S2211-1247%2820%2930627-6','M1/M2','Publisher indexed text; no CFU time-series downloaded','L. casei AMBR2 nasal pilot supports strain-specific upper-airway adaptation and detection after dosing. Detection frequencies cannot determine L168 growth/clearance constants.'),
 ('Krismer2014','Nutrient Limitation Governs Staphylococcus aureus Metabolism and Niche Adaptation in the Human Nose','2014','10.1371/journal.ppat.1003862','https://journals.plos.org/plospathogens/article?id=10.1371/journal.ppat.1003862','M2/M3','Full text','Human nasal secretion chemistry supports nutrient limitation; Gln not found in analyzed samples. Do not equate non-detection with all noses having zero Gln.'),
 ('Kurano2022','Intranasal Administration of N-acetyl-L-cysteine Combined with Cell-Penetrating Peptide-Modified Polymer Nanomicelles as a Potential Therapeutic Approach for Amyotrophic Lateral Sclerosis','2022','10.3390/pharmaceutics14122590','https://www.mdpi.com/1999-4923/14/12/2590','M6','Full text and Fig2','Mouse intranasal free/micelle NAC: plasma Fig2 digitized in %ID/mL. Liquid scintillation gives total 14C, not chemically intact parent NAC or free brain ECF.'),
 ('Zolnourian2025','A Randomised Controlled Trial of SFX-01 After Subarachnoid Haemorrhage — The SAS Study','2025','10.1007/s12975-024-01278-1','https://link.springer.com/article/10.1007/s12975-024-01278-1','M6/M7','Full text; online publication 2024','Oral/NG stabilized SFN in SAH patients; paired CSF exposure mostly BQL. An important contrary exposure constraint, without matching nasal formulation or individual dataset.'),
 ('Mi2010','A cautionary note on using N-acetylcysteine as an antagonist to assess isothiocyanate-induced ROS-mediated apoptosis','2010','10.1016/j.ab.2010.06.015','https://pmc.ncbi.nlm.nih.gov/articles/PMC2992988/','M5','Full text','Hep3B cells: nominal 10 uM SFN with 5 mM NAC pretreatment, reduced labeled uptake. Supports extracellular chemical interference; does not supply nasal kf/kr or a universal antagonism coefficient.'),
 ('Son2021','Comparison of Pharmacokinetics and Anti-Pulmonary Fibrosis-Related Effects of Sulforaphane and Sulforaphane N-acetylcysteine','2021','10.3390/pharmaceutics13070958','https://www.mdpi.com/1999-4923/13/7/958','M5/M6','Full text Tables1/2 and Fig8','Parent-specific rat IV/PO SFN PK supports a frozen linear benchmark and held-out dose tests. High-dose nonlinear exposure and ambiguous time annotation limit the minimal model; no nasal-to-brain coefficients derived.'),
 ('Zhang2023','N-acetylcysteine improves autism-like behavior by recovering autophagic deficiency and decreasing Notch-1/Hes-1 pathway activity','2023','10.1177/15353702231179924','https://pmc.ncbi.nlm.nih.gov/articles/PMC10525405/','M7','Full text','Specific VPA rat/SH-SY5Y context supports pathway association. Cell treatment 2 mM for 2 h is a nominal bath exposure, not EC50, brain concentration or clinical threshold.'),
 ('Danilov2009','Sulforaphane protects astrocytes against oxidative stress and delayed death caused by oxygen and glucose deprivation','2009','10.1002/glia.20793','https://pmc.ncbi.nlm.nih.gov/articles/PMC2657190/','M7','Full text','Rat cortical astrocytes: 5 uM SFN for 48 h before OGD; 2.5 uM for 48 h after OGD. These are distinct exposure protocols, not EC50 values or a nasal/ASD threshold.'),
 ('Goffin2010','Understanding the physiology of Lactobacillus plantarum at zero growth','2010','10.1038/msb.2010.67','https://pmc.ncbi.nlm.nih.gov/articles/PMC2964122/','M2/M3','Full text','Resource-dependent L. plantarum metabolism and nitrogen pathways motivate finite-resource accounting; no matching L168 nasal parameter values extracted.'),
 ('Aggarwal2026','Engineered commensals for metabolic modulation of the gut-liver-brain axis','2026','10.1016/j.cell.2026.03.048','https://pubmed.ncbi.nlm.nih.gov/42034052/','M3','PubMed abstract accessed','Engineered WCFS1 in preclinical hepatic encephalopathy links ammonia assimilation/BCAA biosynthesis and Gln utilization. Different strain, route and host disease; quantitative methods/data not accessed.'),
 ('Assay2023','Bioavailable Sulforaphane Quantitation in Plasma by LC–MS/MS Is Enhanced by Blocking Thiols','2023','10.1021/acs.jafc.3c01367','https://pmc.ncbi.nlm.nih.gov/articles/PMC10472501/','M5/M6','EuropePMC full text XML','Thiol conjugate dissociation and sample processing can affect what an SFN assay measures. Record extraction/derivatization and distinguish native free from assay-recoverable SFN.'),
 ('Peking2025','Peking iGEM 2025 Model and Results','2025','','https://2025.igem.wiki/peking/model/','validation methodology','Model and Results read; code not rerun','Borrow modular validation and transparent negative controls. Published AiiA parameter table uses 9.6e-3 um2/s; its stated Stokes–Einstein inputs give about 96.2 um2/s, requiring a unit/version explanation.')]
def build():
 bib=[];rows=[];sections=['# 原始证据审查与可用数据\n\n检索日期 2026-10-10。来源优先原始论文、出版方、PubMed/PMC；综述不用于关键参数。完整链接、访问深度与外推限制逐项列出。\n']
 for id,title,year,doi,url,modules,access,summary in REFS:
  # Exact bibliography metadata beyond title/year/DOI is intentionally not invented.
  bib.append('@misc{'+id+',\n  title={'+title+'},\n  year={'+year+'},\n  url={'+url+'}'+(',\n  doi={'+doi+'}' if doi else '')+'\n}\n')
  rows.append(dict(id=id,title=title,year=year,doi=doi,url=url,modules=modules,access_depth=access,target_match='not directly matched to four L168 nasal strains',assessment=summary))
  sections.append('## '+id+' — '+modules+'\n\n['+title+']('+url+')。'+access+'。\n\n'+summary+'\n')
 (ROOT/'references.bib').write_text('\n'.join(bib))
 with (ROOT/'tables'/'literature_evidence.csv').open('w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=rows[0]);w.writeheader();w.writerows(rows)
 sections.append('## 未能建立的关键证据\n\n尚无 L168 四构建体鼻部产率、氨净处理动力学、菌可及表面 PS、SFN/NAC 母体鼻给脑 ECF 或脑暴露—通路剂量响应数据。未找到不代表不存在：本轮检索不是系统综述。GPX4/铁死亡及 IL6/TNF 的匹配定量曲线未完成提取，具名多通路网络暂缓。没有充分理由设定 EC50 或为获得疗效提升转运率。\n\n## 真实数据与验证界限\n\nSon Table1 与 Kurano Fig2 提供可重用定量基准，原始作者个体数据未获得；SAS 左删失汇总提供约束；两篇细胞研究提供明确的名义处理条件。没有任何匹配的独立研究验证集完成检验。完整留组的同论文比较与外部验证必须分开。\n')
 (ROOT/'literature_review.md').write_text('\n'.join(sections))
 # Append study-specific parameters exactly once; no use in coupled nasal config.
 with (ROOT/'parameter_registry.csv').open() as f:pars=list(csv.DictReader(f));fields=list(pars[0])
 extra=[
  ('CL_rat_SFN','M6',40.7,'mL/min/kg','2442 mL/h/kg','Son2021','Table1 IV0.1','rat','plasma','IV','parent SFN','mean±SD=3.4','x60','calibration'),
  ('Vss_rat_SFN','M6',2268,'mL/kg','2268 mL/kg','Son2021','Table1 IV0.1','rat','plasma','IV','parent SFN','mean±SD=337','identity','calibration; using Vss as one compartment V is approximation'),
  ('F_lowdose_SFN','M6',.778,'fraction','fraction','Son2021','Table1 PO0.1','rat','plasma','PO','parent SFN','uncertainty not reported','77.8% / 100','calibration'),
  ('Tmax_lowdose_SFN','M6',15,'min','0.25 h','Son2021','Table1 PO0.1','rat','plasma','PO','parent SFN','SD0; sampling limited','/60','calibration'),
  ('half_life_IV_SFN','M6',61.3,'min','1.02167 h','Son2021','Table1 IV0.1','rat','plasma','IV','parent SFN','SD36.2 min','/60','reference not used as ke; Vss discrepancy retained'),
  ('SFN_cell_nominal','M7',5,'uM','5 nmol/mL','Danilov2009','Methods preconditioning; Fig2 (before OGD, 48 h)','rat cells','culture bath','in vitro','nominal SFN','single condition not EC50','identity','context'),
  ('NAC_cell_nominal','M7',2,'mM','2000 nmol/mL','Zhang2023','Cell culture methods','human cell line','culture bath','in vitro','nominal NAC','single condition not EC50','x1000','context'),
  ('SFN_CSF_LLOQ','M6',5,'ng/mL','0.0282 uM (MW177.29)','Zolnourian2025','Fig3 caption','human SAH','CSF','oral/NG','parent SFN','left censored','ng/mL divided by177.29 ->uM','plausibility constraint not a concentration measurement'),
  ('N_Gln','M3',2,'N atoms/molecule','same','stoichiometry','Gln molecular formula','none','none','none','Gln','exact','identity','mass balance'),
  ('N_NHx','M3',1,'N atoms/molecule','same','stoichiometry','NH3/NH4 formula','none','none','none','total ammonia nitrogen','exact','identity','mass balance')]
 urlmap={r[0]:r[4] for r in REFS}
 for k,m,val,orig,new,source,loc,species,tissue,route,analyte,unc,conv,purpose in extra:
  row={f:'' for f in fields};row.update(parameter=k,symbol=k,module=m,meaning=analyte,value=val,range=unc,original_unit=orig,model_unit=new,source_url=urlmap.get(source,''),source_location=loc,species=species,tissue=tissue,route=route,analyte=analyte,extraction='exact published table/text or molecular formula',uncertainty=unc,conversion=conv,purpose=purpose,extrapolation_risk='study-specific only; would be C if borrowed to nasal model; not borrowed',evidence='D' if source=='stoichiometry' else 'B')
  pars=[r for r in pars if r['parameter']!=k];pars.append(row)
 for row in pars:
  row['parameter_class']='biological_unconstrained_fixture' if row['evidence']=='E' else 'coordinate_scale' if row['parameter']=='count_scale' else 'study_specific_or_stoichiometry'
 with (ROOT/'parameter_registry.csv').open('w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(pars[0]));w.writeheader();w.writerows(pars)
 # Every archived source has a content hash; challenge pages are rejected as scientific evidence.
 manifest=[]
 for f in sorted((ROOT/'literature_sources').glob('*')):
  if f.suffix not in ['.html','.xml']:continue
  data=f.read_bytes();text=data.decode(errors='replace')
  bad=len(data)<10000 and ('pubmed' in text.lower() or 'javascript' in text.lower())
  manifest.append(dict(file=str(f.relative_to(ROOT)),sha256=hashlib.sha256(data).hexdigest(),bytes=len(data),status='challenge_not_evidence' if bad else 'full_text_archive'))
 (ROOT/'literature_sources'/'archive_manifest.json').write_text(json.dumps(manifest,indent=2))
if __name__=='__main__':build()
