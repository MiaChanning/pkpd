"""Measurement-error propagation for the literature signal benchmark only.
No unmeasured nasal parameter is assigned a population distribution.
"""
from pathlib import Path
import sys,csv,json
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from literature_pk import fit_decay,decay
ROOT=Path(__file__).resolve().parents[1]
def run():
 with (ROOT/'calibration_datasets'/'Kurano2022_free_NAC.csv').open() as f:rows=list(csv.DictReader(f))
 t=np.array([float(r['time_min']) for r in rows]);y=np.array([float(r['value']) for r in rows]);se=np.array([float(r['SE_approx']) for r in rows]);pix=np.array([float(r['pixel_uncertainty']) for r in rows])
 rng=np.random.default_rng(20261010);grid=np.linspace(0,90,181);curves=[];pars=[]
 for i in range(1000):
  # Approximate independent normal mean errors + uniform extraction error.
  sample=rng.normal(y,se)+rng.uniform(-pix,pix)
  while np.any(sample<=0):sample=rng.normal(y,se)+rng.uniform(-pix,pix)
  fit=fit_decay(t,sample);curves.append(decay(grid,fit));pars.append([fit['amplitude'],fit['k_min']])
 quant=np.quantile(curves,[.025,.5,.975],axis=0)
 with (ROOT/'tables'/'kurano_measurement_envelope.csv').open('w',newline='') as f:
  w=csv.writer(f);w.writerow(['time_min','q025','median','q975','interpretation']);w.writerows((x,a,b,c,'approx_measurement_error_envelope_not_population_CI') for x,a,b,c in zip(grid,*quant))
 report={'draws':1000,'seed':20261010,'method':'independent normal mean SE plus uniform pixel error; approximate not raw-data bootstrap',
    'amplitude_q025_q975':np.quantile(np.asarray(pars)[:,0],[.025,.975]).tolist(),
    'k_min_q025_q975':np.quantile(np.asarray(pars)[:,1],[.025,.975]).tolist(),
    'A_wet_lab_uncertainty':'not available','nasal_E_parameter_probability_distributions':'not assigned',
    'limitations':'approx SE read from low resolution plot; unknown cross-time covariance; parameter fit not weighted; no joint PK/PD prediction interval'}
 (ROOT/'tables'/'uncertainty_measurement.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
if __name__=='__main__':run()
