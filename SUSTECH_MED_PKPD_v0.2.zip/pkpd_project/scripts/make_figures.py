from pathlib import Path
import sys,csv,json,copy
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from model import *
from literature_pk import *
ROOT=Path(__file__).resolve().parents[1]
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,'axes.spines.right':False,
                     'svg.fonttype':'none','figure.dpi':130,'savefig.dpi':250,'axes.titleweight':'bold'})
BLUE='#23618C';ORANGE='#C26B26';GREEN='#247B62';PURPLE='#725195';GRAY='#59636D'
def read(name):
 with (ROOT/'tables'/name).open() as f:return list(csv.DictReader(f))
def finish(fig,num,title,note):
 fig.suptitle(title,fontsize=14,fontweight='bold',y=.99)
 fig.text(.02,.015,'v0.1 | '+note,fontsize=8,color=GRAY,va='bottom',wrap=True)
 fig.tight_layout(rect=[0,.10,1,.94])
 for ext in ['png','svg']:fig.savefig(ROOT/'figures'/f'figure_{num}.{ext}',bbox_inches='tight')
 plt.close(fig)
def generate():
 p=load_config(ROOT/'configs'/'engineering_fixture.json');s=simulate(p);c=simulate(p,False)
 fig,ax=plt.subplots(figsize=(12,6));ax.set_xlim(0,12);ax.set_ylim(0,6);ax.axis('off')
 boxes=[(0.3,4.2,2.4,1,'Four candidate strains\nGln / NHx / SFN / NAC'),(3.4,4.2,2.3,1,'Surface bacteria\nresidence + resources'),
        (6.4,4.2,2.3,1,'Nasal free molecules\nand SFN-NAC'),(9.4,4.2,2.2,1,'Systemic + direct\ntransport hypotheses'),
        (3.4,1.4,2.3,1,'Nasal nitrogen\nGln / NHx / products'),(6.4,1.4,2.3,1,'CSF and brain ECF\namount pools'),
        (9.4,1.4,2.2,1,'Generic response\nuncalibrated; no efficacy')]
 for x,y,w,h,lab in boxes:
  ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle='round,pad=.08',facecolor='#EEF3F6',edgecolor=BLUE));ax.text(x+w/2,y+h/2,lab,ha='center',va='center')
 def arrow(a,b,dashed=True,label=None):
  ax.annotate('',xy=b,xytext=a,arrowprops=dict(arrowstyle='->',lw=1.7,color=ORANGE if dashed else GREEN,linestyle='--' if dashed else '-'))
  if label:ax.text((a[0]+b[0])/2,(a[1]+b[1])/2+.12,label,fontsize=9,ha='center')
 arrow((2.8,4.7),(3.3,4.7));arrow((5.8,4.7),(6.3,4.7));arrow((8.8,4.7),(9.3,4.7))
 arrow((4.6,4.1),(4.6,2.5),label='candidate metabolism')
 arrow((5.8,1.9),(6.3,1.9),label='unknown PS');arrow((6.3,1.65),(5.8,1.65))
 arrow((10.5,4.1),(7.6,2.5));arrow((8.8,1.9),(9.3,1.9))
 ax.text(.4,.65,'Dashed: unquantified in target setting. Conserved amount ledgers are implemented.\nChemistry and route existence have literature support; target-strain parameters are missing.',color=GRAY)
 finish(fig,1,'Four-function model architecture and evidence gaps','v0.1 | Model audit; Shen2025 / Hong2026 / Melin2020 / Mi2010. No L168 pathway is marked validated.')
 fig,axes=plt.subplots(1,2,figsize=(11,4.4))
 for i,(name,col) in enumerate(zip(['Gln','NHx','SFN','NAC'],[BLUE,ORANGE,GREEN,PURPLE])):
  axes[0].plot(s.t,s.y[i],label=name+' strain',color=col)
 axes[0].set(xlabel='Time (h)',ylabel='Bacteria (scaled counts)',title='Unit fixture: finite residence');axes[0].legend()
 t=np.linspace(0,24,241)
 for k in [.1,1,10]:axes[1].plot(t,np.exp(-k*t),label=f'loss = {k:g} h$^{{-1}}$')
 axes[1].set(xlabel='Time (h)',ylabel='N / N(0)',title='Analytic residence envelope');axes[1].legend()
 finish(fig,2,'Bacterial dynamics: numerical benchmark, no wet-lab validation','Fixture: equal initial weights and loss rates, so all four curves coincide. No measured growth curves supplied.')
 rates=np.array([microbial_rates(y,p)[1:3] for y in s.y.T])
 fig,axes=plt.subplots(1,2,figsize=(11,4.4))
 axes[0].plot(s.t,rates[:,0],color=BLUE,label='Gln conversion');axes[0].plot(s.t,rates[:,1],color=GREEN,label='NHx assimilation')
 axes[0].plot(s.t,p['ammonia_yield']*rates[:,0]-rates[:,1],color=ORANGE,label='Net NHx source')
 axes[0].axhline(0,color=GRAY,lw=.7);axes[0].set(xlabel='Time (h)',ylabel='Flux (nmol/h)',title='Conditional reaction rates');axes[0].legend()
 axes[1].plot(s.t,(nitrogen_total(s.y)-nitrogen_total(s.y)[0])*1e12,color=PURPLE)
 axes[1].set(xlabel='Time (h)',ylabel='Ledger drift (10$^{-12}$ nmol N)',title='Nitrogen atoms: source minus exits')
 finish(fig,3,'Nitrogen-conserving Gln and ammonia bookkeeping','Fixture beta=1; Gln -> Glu + NHx is a candidate route, not confirmed in L168. Unknown product N retained in explicit ledger.')
 fig,axes=plt.subplots(1,2,figsize=(11,4.4));x=np.r_[0,np.logspace(-4,2,200)]
 axes[0].plot(x,perfect_sink_reduction(x,1),color=BLUE);axes[0].scatter([0],[0],color=ORANGE,label='Zero exchange')
 axes[0].set_xscale('symlog',linthresh=1e-4);axes[0].set(xlabel='Effective exchange / homeostatic recovery',ylabel='Maximum steady fractional reduction',title='Perfect-sink upper envelope');axes[0].legend()
 for ps in [0,.01,.1,1]:
  q=copy.deepcopy(p);q['PSeff_G']=q['PSeff_A']=ps;z=simulate(q);b=simulate(q,False)
  axes[1].plot(z.t,100*(b.y[9]-z.y[9])/b.y[9],label=f'PS = {ps:g} mL/h')
 axes[1].set(xlabel='Time (h)',ylabel='Additional Gln reduction (%)',title='Coupled fixture: matched controls');axes[1].legend()
 finish(fig,4,'Brain-to-surface exchange feasibility and zero-effect boundary','Unknown anatomical exchange. Upper envelope is a separate one-host-pool idealization; no human flux range or clinical target.')
 fig,axes=plt.subplots(1,2,figsize=(11,4.4));q=copy.deepcopy(p);q['kf']=q['kr']=0;alone=simulate(q)
 axes[0].plot(s.t,s.y[19]/p['V_nose'],color=BLUE,label='Free SFN, co-production')
 axes[0].plot(s.t,alone.y[19]/p['V_nose'],color=BLUE,ls='--',label='SFN, no conjugation')
 axes[0].plot(s.t,s.y[26]/p['V_nose'],color=ORANGE,label='Free NAC');axes[0].plot(s.t,s.y[33]/p['V_nose'],color=PURPLE,label='SFN-NAC')
 axes[0].set(xlabel='Time (h)',ylabel='Nasal concentration (uM)',title='Conditional chemical availability');axes[0].legend(fontsize=8)
 for idx,label,col in [(34,'Produced',GREEN),(19,'Nasal free',BLUE),(33,'Conjugate',PURPLE),(25,'All irreversible exits',GRAY)]:axes[1].plot(s.t,s.y[idx],label=label,color=col)
 axes[1].plot(s.t,np.sum(s.y[20:25],axis=0),color=ORANGE,label='Transit + systemic / brain pools')
 axes[1].set(xlabel='Time (h)',ylabel='SFN equivalents (nmol)',title='Finite source and tracked losses');axes[1].legend(fontsize=8)
 finish(fig,5,'Production and availability: uncalibrated coupled scenario','Engineering fixture only; qS/qN/kf/kr are unconstrained. Mi2010 supports interference, not these nasal rate constants.')
 fig,axes=plt.subplots(1,2,figsize=(11,4.7));sf=read('son_PO05_comparison.csv');t=np.array([float(r['time_min']) for r in sf]);obs=np.array([float(r['observed_digitized_ng_mL']) for r in sf])
 fit=json.loads((ROOT/'configs'/'son_frozen.json').read_text());grid=np.linspace(1,1440,1000)
 axes[0].semilogy(grid,1000*oral_concentration(grid,.5,fit['F'],fit['CL'],fit['V'],fit['ka']),color=BLUE,label='Frozen linear model')
 axes[0].scatter(t,obs,color=ORANGE,label='Digitized readable late points');axes[0].set_ylim(1e-10,200)
 axes[0].set(xlabel='Time (min)',ylabel='Plasma parent SFN (ng/mL)',title='Rat oral 0.5 mg/kg: late-tail failure');axes[0].legend(fontsize=8)
 kur=read('kurano_comparison.csv');t=np.array([float(r['time_min']) for r in kur]);kf=json.loads((ROOT/'configs'/'kurano_frozen.json').read_text())
 axes[1].scatter(t,[float(r['calibration_free_digitized']) for r in kur],facecolors='none',edgecolors=GRAY,label='Calibration free-NAC signal')
 axes[1].errorbar(t,[float(r['heldout_micelle_digitized']) for r in kur],yerr=[float(r['heldout_SE_approx']) for r in kur],fmt='o',color=ORANGE,label='Held-out micelle signal, approx SE')
 axes[1].plot(np.linspace(0,90,200),decay(np.linspace(0,90,200),kf),color=BLUE,label='Frozen signal-decay prediction')
 env=read('kurano_measurement_envelope.csv')
 axes[1].fill_between([float(r['time_min']) for r in env],[float(r['q025']) for r in env],[float(r['q975']) for r in env],color=BLUE,alpha=.12,label='Approx. measurement envelope')
 axes[1].set(xlabel='Time (min)',ylabel='Total 14C signal (%ID/mL plasma)',title='Mouse intranasal: held-out plasma label');axes[1].legend(fontsize=8)
 finish(fig,6,'Literature PK comparisons: failure retained, analytes kept separate','Son2021 Fig8/Table1 (time-label conflict); Kurano2022 Fig2A digitized means. Within-study split; no brain/PD external validation.')
 sens=read('local_sensitivity.csv');names=[r['parameter'] for r in sens];vals=np.array([float(r['elasticity']) for r in sens]);order=np.argsort(abs(vals))
 fig,axes=plt.subplots(1,2,figsize=(11,4.8));axes[0].barh(np.array(names)[order],vals[order],color=[BLUE if v>=0 else ORANGE for v in vals[order]])
 axes[0].axvline(0,color=GRAY,lw=.6);axes[0].set(xlabel='Local elasticity (dimensionless)',title='SFN brain AUC: fixture sensitivity')
 f=np.logspace(-5,0,100)
 for av in [.1,.5,1]:axes[1].loglog(f,1/(f*av),label=f'Availability = {av:g}')
 axes[1].set(xlabel='Delivered fraction (hypothetical)',ylabel='Input / (target concentration x V x clearance rate)',title='Reverse production requirement');axes[1].legend(fontsize=8)
 finish(fig,7,'Design constraints and next measurements, no optimal strain ratio','Unknown ranges are not probability distributions. At delivered fraction=0 the required input is infinite. No robust optimum estimated.')
if __name__=='__main__':generate()
