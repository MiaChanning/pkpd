"""Retrieve publisher DOI metadata; archive responses, never infer missing fields."""
from pathlib import Path
import sys,json,urllib.request,concurrent.futures,datetime
sys.path.insert(0,str(Path(__file__).resolve().parent))
from build_evidence import REFS
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'literature_sources'/'metadata_v02'
OUT.mkdir(exist_ok=True)
def fetch(ref):
    key,title,year,doi,url,*_=ref
    if not doi:return {'id':key,'status':'no_doi_in_original_registry'}
    endpoint='https://api.crossref.org/works/'+urllib.parse.quote(doi,safe='')
    try:
        cached=OUT/(key+'.json')
        if cached.exists():raw=cached.read_bytes()
        else:
            request=urllib.request.Request(endpoint,headers={'User-Agent':'SUSTECHMED-EvidenceAudit/0.2'})
            with urllib.request.urlopen(request,timeout=25) as response:raw=response.read()
        data=json.loads(raw);(OUT/(key+'.json')).write_bytes(raw)
        m=data['message']
        return {'id':key,'status':'retrieved','doi':m.get('DOI'),'title':m.get('title'),
                'authors':m.get('author',[]),'journal':m.get('container-title',[]),
                'published':m.get('published',{}),'published_online':m.get('published-online',{}),
                'volume':m.get('volume'),'issue':m.get('issue'),'page':m.get('page'),
                'url':endpoint,'retrieved_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
    except Exception as exc:return {'id':key,'status':'failed','url':endpoint,'error':str(exc)}
if __name__=='__main__':
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:rows=list(pool.map(fetch,REFS))
    (OUT/'retrieval_log.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2),encoding='utf-8')
    for row in rows:print(row['id'],row['status'])
