"""Reproduce manually inspected figure digitization and exact table transcription.
Pixels refer to archived PMC JPEGs. No fabricated raw observations.
"""
from pathlib import Path
import csv,json,re
from html import unescape
ROOT=Path(__file__).resolve().parents[1]
def write(name,rows,folder='validation_datasets'):
 with (ROOT/folder/name).open('w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=rows[0]);w.writeheader();w.writerows(rows)
def extract():
 # NAC Fig2A: x=92 ->0 min, x=389 ->90 min; y=343 ->0, y=42 ->2.5 %ID/mL.
 time=[0,3,15,30,60,90];x=[92,102,141,191,290,389]
 groups={'free_NAC':([154,170,202,245,269,282],[(143,167),(154,185),(191,214),(235,255),(253,282),(271,294)]),
         'micelle':([126,144,222,244,268,282],[(109,146),(114,174),(206,237),(228,260),(250,282),(271,294)])}
 allrows=[]
 for group,(pixels,bars) in groups.items():
  rows=[]
  for t,px,py,(hi,lo) in zip(time,x,pixels,bars):
   row=dict(dataset='Kurano2022_Fig2A',group=group,time_min=t,value=(343-py)*2.5/301,
            SE_approx=(lo-hi)/2*2.5/301,pixel_uncertainty=3*2.5/301,unit='%ID/mL plasma',
            analyte='total 14C signal; not intact NAC',pixel_x=px,pixel_y=py,extraction='digitized_manual',
            purpose='calibration' if group=='free_NAC' else 'heldout_group')
   rows.append(row);allrows.append(row)
  write('Kurano2022_'+group+'.csv',rows,'calibration_datasets' if group=='free_NAC' else 'validation_datasets')
 write('Kurano2022_all_digitized.csv',allrows)
 # IV SFN log10 axis: y=35 ->1000 ng/mL; y=223 ->0.1 ng/mL.
 rows=[]
 for t,px,py in zip([1,5,15,30,45,60,120,180,240],[83,88,99,117,134,151,220,289,358],[81,93,104,112,122,130,157,166,171]):
  rows.append(dict(time_min=t,value_ng_mL=10**(3-(py-35)*4/188),pixel_x=px,pixel_y=py,
                   pixel_log10_uncertainty=3*4/188,analyte='parent SFN by LC-MS/MS',extraction='digitized_manual',
                   purpose='reproduction_same_study_not_independent'))
 write('Son2021_IV_digitized.csv',rows)
 # Late PO .5 markers are unambiguous. All unreadable early points explicitly missing.
 rows=[]
 for t,px,py in [(15,None,None),(30,None,None),(45,None,None),(60,None,None),(120,508,85),(180,520,92),(240,532,101),(480,579,117),(1440,770,152)]:
  rows.append(dict(time_min=t,value_ng_mL='' if py is None else 10**(3-(py-27)*4/194),pixel_x=px or '',pixel_y=py or '',
   pixel_log10_uncertainty=3*4/194,analyte='parent SFN by LC-MS/MS',extraction='digitized_manual' if py else 'unresolved_marker_overlap',
   purpose='heldout_condition_subset_not_whole_curve'))
 write('Son2021_PO05_digitized.csv',rows)
 # Exact Table1 values, mean and SD, n=4; units as printed. F is reported (not recomputed).
 data=[('IV',.1,2.35,.154,2.47,.205,61.3,36.2,'','','','',0),
       ('PO',.1,1.85,.377,1.92,.411,41.9,7.6,.036,.010,15,0,77.8),
       ('PO',.2,3.16,.073,3.57,.253,197.7,169,.065,.012,5,0,72.4),
       ('PO',.5,29.8,8.64,31,8.89,320,75.4,.143,.035,30,18.4,251.4)]
 fields=['route','dose_mg_kg','AUC_last_ug_min_mL','AUC_last_SD','AUC_inf_ug_min_mL','AUC_inf_SD','half_life_min','half_life_SD','Cmax_ug_mL','Cmax_SD','Tmax_min','Tmax_SD','reported_F_percent']
 table=[dict(zip(fields,r)) for r in data]
 for row in table:
  row['CL_mL_min_kg']=40.7 if row['route']=='IV' else ''
  row['Vss_mL_kg']=2268 if row['route']=='IV' else ''
 write('Son2021_Table1.csv',table)
 write('Son2021_calibration.csv',table[:2],'calibration_datasets')
 write('Son2021_heldout.csv',table[2:])
 # Preserve the publisher table fragments to independently check transcription.
 raw=(ROOT/'literature_sources'/'Son2021.html').read_text()
 tables=re.findall(r'<table\b.*?</table>',raw,re.S)
 (ROOT/'validation_datasets'/'Son2021_table_fragments.html').write_text('\n'.join(tables[:2]))
 write('human_SAS_constraints.csv',[
  dict(analyte='SFN',location='plasma',statistic='AUC_last',value=16.2,unit='ng h/mL',samples_above_LLOQ='',samples_tested='',LLOQ_ng_mL=5),
  dict(analyte='SFN-GSH',location='plasma',statistic='AUC_last',value=277,unit='ng h/mL',samples_above_LLOQ='',samples_tested='',LLOQ_ng_mL=10),
  dict(analyte='SFN-NAC',location='plasma',statistic='AUC_last',value=415,unit='ng h/mL',samples_above_LLOQ='',samples_tested='',LLOQ_ng_mL=5),
  dict(analyte='SFN',location='CSF substudy',statistic='above_LLOQ_count',value='',unit='count',samples_above_LLOQ=5,samples_tested=95,LLOQ_ng_mL=5),
  dict(analyte='SFN-GSH',location='CSF substudy',statistic='above_LLOQ_count',value='',unit='count',samples_above_LLOQ=5,samples_tested=96,LLOQ_ng_mL=10),
  dict(analyte='SFN-NAC',location='CSF substudy',statistic='above_LLOQ_count',value='',unit='count',samples_above_LLOQ=0,samples_tested=96,LLOQ_ng_mL=5)])
 write('PD_exposure_contexts.csv',[
  dict(source='Danilov2009',analyte='SFN',nominal_concentration_uM=5,time_h=48,model='rat cortical astrocytes OGD',endpoint='NRF2/NQO1 and protection',purpose='context_not_EC50_or_brain_threshold'),
  dict(source='Zhang2023',analyte='NAC',nominal_concentration_uM=2000,time_h=2,model='SH-SY5Y VPA',endpoint='Notch/autophagy related',purpose='context_not_EC50_or_brain_threshold')])
 registry=[]
 for id,file,purpose,var,conds,lim in [
  ('SON_T1','Son2021_Table1.csv','IV and PO0.1 calibration; PO0.2/0.5 heldout','parent SFN PK summaries','male SD rats 7-8 weeks n=4','within-study; no nasal/brain mapping'),
  ('SON_IV','Son2021_IV_digitized.csv','same-study curve reproduction','plasma parent SFN','IV 0.1 mg/kg','approx means; SD not digitized; figure h/min mismatch'),
  ('SON_PO05','Son2021_PO05_digitized.csv','heldout_condition_subset','plasma parent SFN','PO0.5 mg/kg rats','4 early markers unresolved; no complete curve score'),
  ('KUR_FREE','../calibration_datasets/Kurano2022_free_NAC.csv','calibration','total 14C plasma %ID/mL','ddY free NAC n=6 or 7','empirical decay only; postdose t0'),
  ('KUR_MIC','Kurano2022_micelle.csv','heldout_group','total 14C plasma %ID/mL','ddY micelle NAC n=6 or 7','same study; formulation different; not parent or brain'),
  ('SAS','human_SAS_constraints.csv','plausibility_constraint_not_scored','LCMS parent SFN and conjugates','oral/NG SFX-01 SAH humans','censored; no individual data; no matched model'),
  ('PD_CTX','PD_exposure_contexts.csv','mechanism_context_not_validation','nominal extracellular drug','cell models','not ECF/intracellular exposure')]:
  source='Son2021' if id.startswith('SON') else 'Kurano2022' if id.startswith('KUR') else 'Zolnourian2025' if id=='SAS' else 'Danilov2009;Zhang2023'
  registry.append(dict(dataset_id=id,source=source,original_file=f'literature_sources/{source}.html',processed_file='validation_datasets/'+file,
   extraction='exact table/text' if id in ['SON_T1','SAS','PD_CTX'] else 'digitized_manual',processing_code='scripts/extract_data.py',variable=var,
   conditions=conds,uncertainty='published SD/SE plus pixel error where available',purpose=purpose,directly_comparable='only specified study endpoint',limitations=lim))
  if id in ['SON_IV','SON_PO05']:registry[-1]['original_file']+=';validation_datasets/Son2021_figure.jpg'
  if id.startswith('KUR'):registry[-1]['original_file']+=';validation_datasets/Kurano2022_figure.jpg'
  if id=='PD_CTX':registry[-1]['original_file']='literature_sources/Danilov2009.html;literature_sources/Zhang2023.html'
 registry[0]['processed_file']='calibration_datasets/Son2021_calibration.csv;validation_datasets/Son2021_heldout.csv'
 write('validation_registry.csv',registry,folder='.')
 (ROOT/'validation_datasets'/'README.md').write_text('All records are literature table transcriptions or explicitly digitized figure means, not author-supplied raw observations. Extraction pixels and axis mappings are in scripts/extract_data.py. Archived figures are unmodified. Son Fig8 time label h conflicts with Methods minutes. Early oral markers and reported 5-min Tmax are unresolved. Calibration and held-out groups are specified before fitting in validation_plan.md; no independent-study matched validation exists.\n')
if __name__=='__main__':extract()
