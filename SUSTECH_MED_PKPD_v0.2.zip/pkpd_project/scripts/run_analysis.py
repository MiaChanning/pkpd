from pathlib import Path
import sys,csv,json,copy,hashlib
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from model import *
from literature_pk import *
ROOT=Path(__file__).resolve().parents[1]
def read(path):
 with (ROOT/path).open() as f:return list(csv.DictReader(f))
def save(name,rows):
 with (ROOT/'tables'/name).open('w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=rows[0]);w.writeheader();w.writerows(rows)
def analyse():
 p=load_config(ROOT/'configs'/'engineering_fixture.json');s=simulate(p);control=simulate(p,False)
 np.savez_compressed(ROOT/'tables'/'scenario_trajectories.npz',t=s.t,y=s.y,control=control.y,names=NAMES)
 save('scenario_trajectories.csv',[dict(time_h=t,**dict(zip(NAMES,y))) for t,y in zip(s.t,s.y.T)])
 c=load_config();zero=simulate(c)
 internal={'nitrogen_max_drift_nmol':float(np.max(np.abs(nitrogen_total(s.y)-nitrogen_total(s.y)[0]))),
 'SFN_equivalent_max_drift_nmol':float(np.max(np.abs(drug_total(s.y,'S')))),
 'NAC_equivalent_max_drift_nmol':float(np.max(np.abs(drug_total(s.y,'N')))),
 'min_state':float(s.y.min()),'conservative_max_drug_nmol':float(np.max(zero.y[19:36]))}
 a=simulate(p,max_step=.05);r=simulate(p,method='Radau')
 internal.update(max_step_change_max_abs=float(np.max(np.abs(s.y-a.y))),reference_solver_max_abs=float(np.max(np.abs(s.y-r.y))))
 pp=copy.deepcopy(p);pp['PSeff_G']=pp['PSeff_A']=0;zs=simulate(pp);zc=simulate(pp,False)
 internal['zero_exchange_max_brain_difference']=float(np.max(np.abs(zs.y[[9,12]]-zc.y[[9,12]])))
 # Fixed study-specific benchmark; no nasal config parameter is taken from it.
 tab=read('validation_datasets/Son2021_heldout.csv');fit=calibrate_son(read('calibration_datasets/Son2021_calibration.csv'))
 (ROOT/'configs'/'son_frozen.json').write_text(json.dumps(fit,indent=2))
 summaries=[]
 for row in tab:
  dose=float(row['dose_mg_kg']);cl,v,ka,ke,F=fit['CL'],fit['V'],fit['ka'],fit['ke'],fit['F']
  cmax=float(oral_concentration(fit['tmax'],dose,F,cl,v,ka))
  for metric,pred,key,sdkey in [('Cmax',cmax,'Cmax_ug_mL','Cmax_SD'),('AUCinf',dose*1000*F/cl,'AUC_inf_ug_min_mL','AUC_inf_SD'),
                             ('Tmax',fit['tmax'],'Tmax_min','Tmax_SD'),('half_life',np.log(2)/ke,'half_life_min','half_life_SD')]:
   obs=float(row[key]);sd=float(row[sdkey]);R=pred/obs;elog=abs(np.log10(R))
   summaries.append(dict(dataset='Son2021',dose_mgkg=dose,metric=metric,predicted=pred,observed=obs,SD=sd,R=R,E_log=elog,
     order_screen='通过' if elog<=1 else '未通过',twofold_screen='通过' if elog<=np.log10(2) else '未通过',
     SD_distance='' if sd==0 else abs(pred-obs)/sd,purpose='retrospective_heldout_condition_same_study',
     restriction='not nasal or brain validation; Tmax sampling discrepancy unresolved'))
 save('son_heldout_metrics.csv',summaries)
 iv=read('validation_datasets/Son2021_IV_digitized.csv');t=np.array([float(z['time_min']) for z in iv]);obs=np.array([float(z['value_ng_mL']) for z in iv])
 pred=.1*1e6/fit['V']*np.exp(-fit['ke']*t)
 curves={'Son_IV_reproduction':positive_metrics(pred,obs)}
 save('son_IV_comparison.csv',[dict(time_min=x,predicted_ng_mL=y,observed_digitized_ng_mL=z) for x,y,z in zip(t,pred,obs)])
 po=[z for z in read('validation_datasets/Son2021_PO05_digitized.csv') if z['value_ng_mL']];t=np.array([float(z['time_min']) for z in po]);obs=np.array([float(z['value_ng_mL']) for z in po]);pred=1000*oral_concentration(t,.5,fit['F'],fit['CL'],fit['V'],fit['ka'])
 curves['Son_PO05_late_subset']=positive_metrics(pred,obs)
 save('son_PO05_comparison.csv',[dict(time_min=x,predicted_ng_mL=y,observed_digitized_ng_mL=z) for x,y,z in zip(t,pred,obs)])
 free=read('calibration_datasets/Kurano2022_free_NAC.csv');mic=read('validation_datasets/Kurano2022_micelle.csv')
 t=np.array([float(z['time_min']) for z in free]);obs=np.array([float(z['value']) for z in free]);nfit=fit_decay(t,obs)
 (ROOT/'configs'/'kurano_frozen.json').write_text(json.dumps(nfit,indent=2))
 mp=np.array([float(z['value']) for z in mic]);npred=decay(t,nfit)
 curves['Kurano_heldout_micelle_plasma_label']=positive_metrics(npred,mp)
 curves['Kurano_heldout_micelle_plasma_label'].update(predicted_AUC0_90=float(np.trapezoid(npred,t)),observed_digitized_AUC0_90=float(np.trapezoid(mp,t)),
                       predicted_peak_time_min=float(t[np.argmax(npred)]),observed_peak_time_min=float(t[np.argmax(mp)]),
                       max_approx_SE_distance=float(np.max(abs(npred-mp)/np.array([float(z['SE_approx']) for z in mic]))),
                       all_within_two_approx_SE=bool(np.all(abs(npred-mp)<=2*np.array([float(z['SE_approx']) for z in mic]))))
 save('kurano_comparison.csv',[dict(time_min=x,calibration_free_digitized=y,heldout_micelle_digitized=z,predicted_total_label=n,heldout_SE_approx=float(e['SE_approx'])) for x,y,z,n,e in zip(t,obs,mp,npred,mic)])
 # Local elasticities are properties of arbitrary fixture, not population uncertainty.
 def endpoint(q):
  z=simulate(q);return float(np.trapezoid(z.y[23]/q['V_B'],z.t))
 base=endpoint(p);sens=[]
 for k in ['qS','kloss','kmuc','kf','kr','kabs_S','fdir_S','fsys_S','PSpb_S','kb_S']:
  lo=copy.deepcopy(p);hi=copy.deepcopy(p);lo[k]*=.95;hi[k]*=1.05
  ep=(endpoint(hi)-endpoint(lo))/(.1*base)
  sens.append(dict(parameter=k,endpoint='SFN brain_AUC',elasticity=ep,evidence='E',interpretation='engineering_fixture_local_only'))
 save('local_sensitivity.csv',sens)
 scans=[]
 for k in ['kloss','PSeff_G','qS','fdir_S','kf']:
  for factor in [0,.1,.5,1,2,10]:
   q=copy.deepcopy(p);q[k]=p[k]*factor;z=simulate(q);b=simulate(q,False)
   scans.append(dict(parameter=k,factor=factor,SFN_brain_AUC=float(np.trapezoid(z.y[23],z.t)),Gln_extra_change_at24=(b.y[9,-1]-z.y[9,-1])/b.y[9,-1],interpretation='epistemic_scenario_not_CI'))
 save('scenario_scan.csv',scans)
 # Distribution-free dimensionless feasibility maps, no guessed physiological bounds.
 rev=[]
 for delta in [.01,.05,.1,.2,.5]:rev.append(dict(target_fraction=delta,required_exchange_over_homeostasis=delta/(1-delta),status='perfect_sink_steady_upper_bound_not_clinical_target'))
 save('reverse_exchange.csv',rev)
 prod=[]
 for f in [0,1e-5,1e-4,.001,.01,.1,1]:
  for avail in [.1,.5,1]:prod.append(dict(delivery_fraction=f,availability=avail,required_input_per_Ctarget_V_kb=required_drug_input(1,1,1,f,avail),label='dimensionless_feasibility_grid_not_estimated_fractions'))
 save('reverse_production.csv',prod)
 # Parameter non-identifiability: normalized brain AUC is linear in q and f for a linear branch.
 # Such a branch identifies q*f, not its factors. This is analytical, not a fit to data.
 summary=dict(version='0.1',internal=internal,literature_curves=curves,son_frozen=fit,kurano_frozen=nfit,
   scenario=dict(SFN_produced_nmol=float(s.y[34,-1]),NAC_produced_nmol=float(s.y[35,-1]),SFN_brain_AUC_uM_h=base,
       SFN_brain_peak_uM=float(np.max(s.y[23]/p['V_B'])),NAC_brain_peak_uM=float(np.max(s.y[30]/p['V_B'])),
       Gln_extra_fraction24=float((control.y[9,-1]-s.y[9,-1])/control.y[9,-1])),
   independent_study_validation_completed=False)
 (ROOT/'tables'/'computed_results.json').write_text(json.dumps(summary,indent=2))
 print(json.dumps(summary,indent=2))
if __name__=='__main__':analyse()
