"""Offline v0.2 evidence dossier, data atlas and provenance checks.

No unmeasured biological coefficient is promoted to an experimental value.
The original zip is the immutable baseline; this script runs after original reports.
"""
from pathlib import Path
import csv,json,re,html,hashlib,xml.etree.ElementTree as ET
from html.parser import HTMLParser
from build_evidence import REFS
ROOT=Path(__file__).resolve().parents[1]

def readcsv(path):
    with (ROOT/path).open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
def csvout(path,rows):
    with (ROOT/path).open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
def write(path,text):(ROOT/path).write_text(text.strip()+'\n',encoding='utf-8')
def mdtable(rows):
    keys=list(rows[0]);clean=lambda x:str(x).replace('|','/').replace('\n',' ')
    return '| '+' | '.join(keys)+' |\n|'+'|'.join(['---']*len(keys))+'|\n'+'\n'.join('| '+' | '.join(clean(r.get(k,'')) for k in keys)+' |' for r in rows)
class TextParser(HTMLParser):
    def __init__(self):super().__init__();self.skip=0;self.lines=[];self.meta={}
    def handle_starttag(self,tag,attrs):
        a=dict(attrs)
        if tag in ['script','style','noscript']:self.skip+=1
        if tag=='meta':self.meta.setdefault(a.get('name',''),[]).append(a.get('content',''))
        if tag in ['p','div','section','h1','h2','h3','h4','tr','li']:self.lines.append('\n')
    def handle_endtag(self,tag):
        if tag in ['script','style','noscript']:self.skip=max(0,self.skip-1)
    def handle_data(self,data):
        if not self.skip:self.lines.append(data)
    def text(self):return '\n'.join(x.strip() for x in ''.join(self.lines).splitlines() if x.strip())

MAP=[
 ('M1','b_i(0)=b_total*w_i*sum(dep)*survival','Shang2021;DeBoeck2020;Shen2025','鼻部沉积及菌株特异适应性','数字dep/survival无匹配测量，均为E；三区仅用于初值','src/model.py:initial_state','none'),
 ('M2','db_i/dt=g_i-(death_i+kloss)b_i; g_i=mu_i*b_i*R/(K_R+R)/(1+sum(b)/capacity)','Goffin2010;Krismer2014','资源限制支持结构动机；该函数是最小现象学选择','未拟合L168；不是从原论文逐式复制的菌株动力学','src/model.py:microbial_rates;rhs','none'),
 ('M3','vG=qG*bG*CG/(KG+CG)*PG/(precK+PG); analogous vA','Goffin2010;Aggarwal2026','候选整菌饱和处理与资源约束','路线/产物及q/K均未知；其他菌株肠道证据不提供鼻部速率','src/model.py:microbial_rates','none'),
 ('M3','Gln(2N) -> Glu(1N)+beta*NHx(1N)+(1-beta)*unresolved_N','chemical_formula;Goffin2010','氮原子账本及候选反应','守恒式可核验；不等于已确认工程菌反应或缬氨酸产物','src/model.py:rhs;nitrogen_total','internal nitrogen tests'),
 ('M4','JBC=PSbc*(CB-CC); JCN=PSeff*(CC-Cnose)','Hong2026;Melin2020','深层CSF外流及人体鼻黏膜示踪限制','JCN为未验证合并通量；分配系数1为算例；不能将淋巴流量赋给PSeff','src/model.py:host_matrix','zero-exchange/steady-state tests only'),
 ('M5','Rj=qj*bj*Pj/(precK+Pj); r=kf*nS*nN/Vnose-kr*nSN','Mi2010;Son2021;Assay2023','化学干扰、缀合物再生母体和测定口径','前体是抽象当量；鼻部q/kf/kr/kd未知，缀合物运输暂缓','src/model.py:rhs;drug_total','no nasal production measurements'),
 ('M6','Jabs=kabs*n; direct Erlang chain and paired systemic/brain fluxes','Kurano2022;Shen2025','给药系统与运输可能性','实际鼻脑分流/屏障系数/时滞均E；Erlang为数学延迟结构','src/model.py:rhs','analytic Erlang test; not target PK'),
 ('M7','dE/dt=(CB/(EC+CB)-E)/PD_tau','Danilov2009;Zhang2023','特定条件下的通路响应','仅接口示范；EC=1为E；不能称NRF2/Notch模型或疗效','src/model.py:rhs','PD context records, no PD fit'),
 ('M6 benchmark','C=F*D*ka/[V*(ka-ke)]*(exp(-ke*t)-exp(-ka*t)); ke=CL/Vss','Son2021','原研究IV与PO低剂量表格约束','单室Vss近似；ke不是实测终末速率；单位min、ug/mL','src/literature_pk.py:oral_concentration;calibrate_son','SON_T1;SON_IV;SON_PO05'),
 ('M6 signal benchmark','y=A*exp(-k*t)','Kurano2022','原图血浆总14C信号','经验函数；不可当作母体NAC清除率或脑ECF浓度','src/literature_pk.py:fit_decay;decay','KUR_FREE;KUR_MIC'),
 ('M8','e_required/h=delta/(1-delta); R_required=target*V*kb/(delivery*availability)','mathematical_mass_balance','理想稳态下的反向可行性推导','条件性要求，不是生理参数估计；零递送时正目标无有限解','src/model.py:required_exchange;required_drug_input','reverse tables; no biological optimum')]

LOC={
 'Son2021':'Methods 2.3–2.5; Results 3.2–3.3; Table1; Fig5 and Fig8',
 'Kurano2022':'Methods 2.8; Fig2A caption (open circles free NAC, closed micelle); Fig3 tissue radiolabel',
 'Danilov2009':'Methods preconditioning; Results C; Fig2 pretreatment; Fig6 post-treatment; statistical analysis',
 'Zhang2023':'Cell culture methods (SH-SY5Y, VPA/NAC); Results Notch/autophagy assays',
 'Zolnourian2025':'Methods Pharmacokinetics; Results Sulforaphane and Metabolite Plasma and CSF Levels; Fig3 caption',
 'Mi2010':'Methods and Results on extracellular NAC/isothiocyanate interaction',
 'Goffin2010':'Retentostat methods; nitrogen metabolism discussion; Fig3 and supplements',
 'Krismer2014':'Nasal secretion metabolite analysis and defined nasal medium',
 'Melin2020':'Methods MRI tracer and ROI definition; Results nasal mucosa enrichment',
 'Shang2021':'Computational mucus clearance/absorption model and numerical assumptions',
 'DeBoeck2020':'AMBR2 epithelial adhesion and human nasal pilot; no L168 construct data',
 'Shen2025':'PubMed abstract independently checked; WCFS1/murine obesity/payload scope',
 'Hong2026':'Crossref bibliographic identity checked; quantitative surface flux not accessed',
 'Aggarwal2026':'Crossref bibliographic identity checked; target-setting rates unavailable',
 'Assay2023':'Archived EuropePMC XML, article DOI and LC-MS/MS sample-processing study',
 'Peking2025':'Official Model and Results pages; methodological comparison only'}

def enhance():
    metadata=json.loads((ROOT/'literature_sources/metadata_v02/retrieval_log.json').read_text(encoding='utf8'))
    meta={x['id']:x for x in metadata};sources=[];bib=[]
    normalized=ROOT/'literature_sources'/'normalized';normalized.mkdir(exist_ok=True)
    for key,title,year,doi,url,modules,access,assessment in REFS:
        files=[p for p in (ROOT/'literature_sources').glob(key+'.*') if p.suffix in ['.html','.xml','.txt']]
        p=next((p for p in files if p.suffix=='.html'),None); parser=TextParser()
        if p:parser.feed(p.read_text(encoding='utf8'));write('literature_sources/normalized/'+key+'.txt',parser.text())
        m=meta.get(key,{});m=m if m.get('status')=='retrieved' else {}
        authors=m.get('authors',[])
        if not authors and p:authors=[{'literal':x} for x in parser.meta.get('citation_author',[])]
        journal='; '.join(m.get('journal',[])) or ('; '.join(parser.meta.get('citation_journal_title',[])) if p else '')
        if key=='Assay2023':
            xml=ET.parse(ROOT/'literature_sources/Assay2023.xml')
            journal=xml.findtext('.//journal-title') or journal
            authors=[{'family':n.findtext('surname',''),'given':n.findtext('given-names','')} for n in xml.findall('.//contrib[@contrib-type="author"]/name')]
            write('literature_sources/normalized/Assay2023.txt','\n'.join(' '.join(e.itertext()) for e in xml.findall('.//body//p')))
        # Dates are separate: do not silently replace issue year with online publication year.
        row=dict(source_id=key,title=(m.get('title') or [title])[0],doi=doi,url=url,
                 authors='; '.join(x.get('literal') or (x.get('family','')+', '+x.get('given','')) for x in authors),
                 journal=journal,registry_year=year,published_date=json.dumps(m.get('published',{}),ensure_ascii=False),
                 online_date=json.dumps(m.get('published_online',{}),ensure_ascii=False),modules=modules,
                 metadata_status=meta.get(key,{}).get('status','not_requested'),original_access_record=access,
                 evidence_location=LOC[key],archive_files=';'.join(str(f.relative_to(ROOT)).replace('\\','/') for f in files),
                 numerical_use='yes: benchmark/context only' if key in ['Son2021','Kurano2022','Zolnourian2025','Danilov2009','Zhang2023'] else 'no target coefficient imported',
                 assessment=assessment)
        sources.append(row)
        fields={'title':row['title'],'year':year,'url':url}
        if doi:fields['doi']=doi
        if row['authors']:fields['author']=' and '.join(x.get('literal') or (x.get('family','')+', '+x.get('given','')) for x in authors)
        if journal:fields['journal']=journal
        for name in ['volume','issue','page']:
            if m.get(name):fields[{'issue':'number','page':'pages'}.get(name,name)]=str(m[name])
        if key in ['Danilov2009','Zolnourian2025']:fields['note']='Reference key uses journal issue year; online publication date separately archived.'
        bib.append('@'+('article' if doi else 'misc')+'{'+key+',\n'+',\n'.join('  '+k+'={'+v.replace('{','').replace('}','')+'}' for k,v in fields.items())+'\n}\n')
    csvout('tables/source_registry.csv',sources);write('references.bib','\n'.join(bib))
    eq=[dict(module=a,equation=b,reference_ids=c,supported_process=d,assumptions_and_limits=e,implementation=f,data_use=g) for a,b,c,d,e,f,g in MAP]
    csvout('tables/equation_evidence_map.csv',eq)
    # Every parameter has separate numeric model value and unit. Original columns remain for backwards compatibility.
    pars=readcsv('parameter_registry.csv')
    for p in pars:
        p['original_value']=p['value'];p['value_model']=p['value'];p['model_unit_normalized']=p['model_unit']
        conversions={'CL_rat_SFN':(2442,'mL/h/kg'),'Vss_rat_SFN':(2268,'mL/kg'),
                     'Tmax_lowdose_SFN':(.25,'h'),'half_life_IV_SFN':(61.3/60,'h'),
                     'SFN_cell_nominal':(5,'nmol/mL'),'NAC_cell_nominal':(2000,'nmol/mL'),
                     'SFN_CSF_LLOQ':(5/177.29,'nmol/mL')}
        if p['parameter'] in conversions:p['value_model'],p['model_unit_normalized']=conversions[p['parameter']]
        p['used_in']=('configs/engineering_fixture.json (software fixture only)' if p['evidence']=='E' else
                      'src/literature_pk.py (original-study benchmark)' if p['parameter'].endswith('_derived') or p['parameter'] in ['CL_rat_SFN','Vss_rat_SFN','F_lowdose_SFN','Tmax_lowdose_SFN'] else 'context or exact ledger; see purpose')
        if p['parameter'].startswith('V_'):p['module']='M4/M6' if p['parameter']!='V_P' else 'M6'
    csvout('parameter_registry.csv',pars)
    write('parameter_catalog.md','# 参数目录 v0.2\n\n逐项呈现原值、模型值、单位、来源位置和使用位置。E类工程算例没有匹配的文献数值；空来源不是漏引文，不能用机制论文补成实验参数。derived为推导或拟合值，其不确定性不等于原始测量误差。\n\n'+mdtable(pars))
    # New independent transcription: effect observations, not an invented dose-response series.
    pd=[dict(dataset_id='DAN_F6',condition=condition,nominal_SFN_uM=conc,treatment_timing='after 4h OGD; 48h REOX' if ogd else 'no OGD',
             cell_death_percent=mean,SEM_percent=sem,n='8–9 (Fig6 caption)',source_id='Danilov2009',
             source_location='Results C and Fig6; Statistical Analysis defines mean ± SEM',
             extraction='exact_text_transcription',purpose='descriptive_PD_context_not_calibration_or_validation')
        for condition,conc,mean,sem,ogd in [('vehicle_sham',0,2.3,.5,False),('SFN_sham',2.5,3.4,.5,False),('vehicle_OGD',0,37.5,1.4,True),('SFN_OGD',2.5,25.6,2.5,True)]]
    csvout('validation_datasets/Danilov2009_Fig6_text.csv',pd)
    pdctx=[r for r in readcsv('validation_datasets/PD_exposure_contexts.csv') if 'POST-treatment' not in r['model']];pdctx[0]['model']='rat cortical astrocytes; 48h SFN PRE-treatment before OGD'
    pdctx.append(dict(source='Danilov2009',analyte='SFN',nominal_concentration_uM=2.5,time_h=48,model='rat cortical astrocytes; POST-treatment during REOX',endpoint='Fig6 cell death',purpose='context_not_EC50_or_brain_threshold'))
    csvout('validation_datasets/PD_exposure_contexts.csv',pdctx)
    registry=[r for r in readcsv('validation_registry.csv') if r['dataset_id']!='DAN_F6']
    registry.append(dict(dataset_id='DAN_F6',source='Danilov2009',original_file='literature_sources/Danilov2009.html',processed_file='validation_datasets/Danilov2009_Fig6_text.csv',extraction='exact_text_transcription',processing_code='scripts/enhance_evidence.py',variable='cell death percent',conditions='rat cortical astrocytes; post-OGD 2.5uM SFN 48h',uncertainty='published mean ± SEM; n=8–9; no individual data',purpose='context_only_not_scored',directly_comparable='not comparable to generic response_S',limitations='one treated dose; cannot identify EC50/Hill/time constant'))
    source_urls={r['source_id']:r['url'] for r in sources}
    for row in registry:
        row['source_url']='; '.join(source_urls.get(k,'') for k in row['source'].split(';'))
        row['source_location']={'SON_T1':'Table1','SON_IV':'Fig8a','SON_PO05':'Fig8b; readable late subset','KUR_FREE':'Fig2A open circles','KUR_MIC':'Fig2A closed circles','SAS':'Results CSF levels; Fig3 LLOQ caption','PD_CTX':'Danilov pre/post protocols; Zhang cell culture','DAN_F6':'Results C, Fig6'}.get(row['dataset_id'],'')
        row['comparison_level']='within-study holdout' if row['dataset_id'] in ['KUR_MIC','SON_PO05'] else 'calibration/retrospective reproduction' if row['dataset_id'] in ['SON_T1','SON_IV','KUR_FREE'] else 'context only'
    csvout('validation_registry.csv',registry)
    # Full data atlas, includes missing entries rather than dropping unreadable markers.
    datasets=[('SON_TABLE','validation_datasets/Son2021_Table1.csv'),('SON_IV','validation_datasets/Son2021_IV_digitized.csv'),
              ('SON_PO05','validation_datasets/Son2021_PO05_digitized.csv'),('KUR_ALL','validation_datasets/Kurano2022_all_digitized.csv'),
              ('SAS','validation_datasets/human_SAS_constraints.csv'),('PD_CTX','validation_datasets/PD_exposure_contexts.csv'),('DAN_F6','validation_datasets/Danilov2009_Fig6_text.csv')]
    atlas=['# 模型实际使用的数据与原始研究条件','这是已纳入项目的全部观测记录和背景约束。数字化均值不是作者原始个体数据；不可读点保留为空。原图保存在 validation_datasets，坐标变换见 scripts/extract_data.py。文献机制存在不等于L168鼻部参数已测定。',
           '## 数据用途与来源',mdtable(registry)]
    for key,path in datasets:atlas.extend(['## '+key,'文件：['+path+']('+path+')',mdtable(readcsv(path))])
    atlas.extend(['## 数值处理与比较边界',
      'Kurano Fig2A：x轴0–90 min，y轴0–2.5 %ID/mL；y=(343-py)*2.5/301，误差条SE由像素近似读取，另设±3像素敏感性。时间0是给药完成后的首点，不是鼻腔开始输入的瞬时。',
      'Son Fig8：纵轴log10；IV y=10**(3-(py-35)*4/188)，PO y=10**(3-(py-27)*4/194)。原图横轴写Time(h)，方法与表1使用min，当前按min解释并保留冲突。此冲突使曲线级验证只能作为条件性比较。',
      'SAS低于LLOQ是左删失，不应置零或把图中LLOQ/2当成测量。只汇总检测计数，不拟合脑暴露。Danilov单剂量终点不是Hill曲线。',
      '新转录的Danilov后处理组：37.5%降至25.6%，差11.9个百分点；相对下降31.73%。这是原研究观测的描述统计，不是本项目PD预测；未估计该差值置信区间，也未据此设定EC50。'])
    write('data_atlas.md','\n\n'.join(atlas))
    dossier=['# 四菌 PK–PD 模型证据与应用数据审查 v0.2',
      '现有模型的可确认成果是守恒的计算框架和原研究条件下的文献基准。L168四构建体的体外产率、鼻部驻留、菌可及表面交换和自由母体脑暴露尚无匹配测量，因此不能给出已验证的疗效或最优四菌比例。此版本保留失败结果，并使每一类输入的出处和用途可查。',
      '## 1 方程为什么这样写',mdtable(eq),
      '饱和函数、单室近似、Erlang和通用Hill接口是数学选择；文献只支持相关过程动机，不支持把任意系数当作真实生理常数。M1没有空间求解；M2没有分株数据拟合；M7没有具名通路参数化。',
      '## 2 原始参考文献与实际用途',mdtable(sources),
      '## 3 参数分类与单位',
      'parameter_registry.csv保留原始字段，并新增 original_value、value_model、model_unit_normalized、used_in。A–E是参数来源分类，不是验证成功等级。当前没有项目实测A类参数。B仅适用于原论文对应条件；如用于L168鼻部，须重新标为C并证明外推。E数值只是测试坐标，不构成合理生理范围。',
      '## 4 已应用的数据',
      '完整数据点、条件、误差类型、数字化坐标和角色见 [data_atlas.md](data_atlas.md)。机器可读索引见 [validation_registry.csv](validation_registry.csv)。源资料和结果文件见HTML报告中的链接。',
      '## 5 审查中修正的内容',
      '- Danilov预处理是5 μM×48h，后处理是2.5 μM×48h；此前合并为5 μM pre/post不准确，已修正，并补入后处理细胞死亡均值与SEM。\n- 补齐Assay2023 DOI：10.1021/acs.jafc.3c01367（来自归档全文XML）。\n- 元数据保留在线日期与期刊年份差异：Danilov在线2008/期刊2009，SAS在线2024/期刊2025；没有把它们视为两篇不同论文。\n- 参数表数值、单位、换算结果拆开，避免2442 mL/h/kg写进单位栏而value仍为40.7。原研究基准继续使用分钟，不混入小时制联立模型。\n- 不把15项软件测试等同15项生物验证；单位测试只覆盖两个换算例，不是全模型自动量纲证明。\n- 宿主模型忽略分配系数差异、Gln↔氨脑内代谢耦合及其他全身反馈；氮账本通过并不证明这些机制已解析。',
      '## 6 验证与修改规则',
      '同研究留出剂量/制剂组与独立研究外部验证分开。现有留出结果已知，后续任何基于其失败的模型选择都将这些组转为开发数据，需要另取未见条件验证。本次证据与转录修订未重拟合PK。',
      '## 7 下一轮实验的直接用途',
      '优先：各株分株CFU与胞外特异性SFN/NAC；同步Gln、Glu、总氨氮和实际含氮产物；人工鼻液中的母体与缀合物稳定性。先用单菌和无菌对照估计源项，再固定参数预测完整留出的混合比例/批次。屏障接收侧特异性化学测量可检验运输接口，但不能替代真实脑—鼻解剖证据。']
    write('evidence_dossier.md','\n\n'.join(dossier))
    write('revision_v02.md','# v0.2 修订记录\n\n'+dossier[dossier.index('## 5 审查中修正的内容')+1]+'\n\n原始v0.1压缩包未修改。文献和观测转录保留原来源；未通过的SFN预测未调参改善。完整离线重建末尾执行scripts/enhance_evidence.py，避免补充内容被旧生成器覆盖。')
    for path in ['literature_review.md','model_audit.md','parameter_notes.md','validation_report.md','uncertainty_analysis.md','limitations.md','results_summary.md','wiki_model_draft.md','wiki_results_draft.md','figures/captions.md','iteration_log.md','README.md']:
        t=(ROOT/path).read_text(encoding='utf8')
        if '\n<!-- V02 -->' in t:t=t.split('\n<!-- V02 -->')[0]
        t=t.replace('5 uM SFN pre/post OGD','5 uM SFN before OGD; 2.5 uM after OGD')
        extra=('## v0.2 evidence and data links\n\nSee [evidence dossier](evidence_dossier.md), [complete data atlas](data_atlas.md), [equation/source mapping](tables/equation_evidence_map.csv), and [evidence report](evidence_report.html). Danilov2009 pre-treatment uses 5 uM; post-treatment uses 2.5 uM. These protocols do not define EC50. The generic response has not been fitted.\n' if path.startswith('wiki_') else '## v0.2 可追溯补充\n\n参见 [证据审查](evidence_dossier.md)、[全部应用数据](data_atlas.md)、[参数逐项说明](parameter_catalog.md)、[方程与来源对应表](tables/equation_evidence_map.csv)、[数据展示页](evidence_report.html)。Danilov预处理5 μM与后处理2.5 μM已分开；同论文留组比较仍不是独立研究验证。')
        if path=='README.md':extra+='\n\n## Windows run instructions\n\nUse `./run_windows.ps1 -PythonPath "C:/path/to/python.exe"` after installing `requirements-lock.txt`. For isolation: create a `.venv` with your Python, then run `.venv/Scripts/python.exe -m pip install -r requirements-lock.txt`. The launcher selects project .venv first, then PATH Python, then the Codex bundled runtime if present. This delivered project excludes dependency binaries; scientific dependencies must be available. Main rebuilding is offline; optional Crossref metadata retrieval is separate.\n\nModel computation version remains 0.1; evidence and data presentation revision is 0.2. Original zip SHA256 is recorded in revision_manifest.json. No target-strain wet measurements were added.\n'
        write(path,t+'\n\n<!-- V02 -->\n\n'+extra)
    # Freeze, hashes and audit checks make missing inputs visible.
    checks=[]
    def check(name,condition,detail):checks.append(dict(check=name,status='pass' if condition else 'fail',detail=detail))
    check('source IDs unique',len(sources)==len({x['source_id'] for x in sources}),str(len(sources)))
    check('all equation citations resolved',all(k in source_urls or k in ['chemical_formula','mathematical_mass_balance'] for row in eq for k in row['reference_ids'].split(';')),'Mechanism references are separate from mathematical derivations')
    check('processed dataset paths exist',all((ROOT/p.strip()).exists() for row in registry for p in row['processed_file'].split(';')),'Relative paths resolve within project')
    check('all config keys registered',set(json.loads((ROOT/'configs/engineering_fixture.json').read_text())['parameters'])<=set(p['parameter'] for p in pars),'No missing named fixture coefficient')
    check('calibration and heldout path roles disjoint',not ({'calibration_datasets/Kurano2022_free_NAC.csv','calibration_datasets/Son2021_calibration.csv'} & {'validation_datasets/Kurano2022_micelle.csv','validation_datasets/Son2021_heldout.csv'}),'Checks assigned file roles; no claim of prospective split')
    check('NAC units preserve total14C',all('14C' in row['analyte'] for row in readcsv('validation_datasets/Kurano2022_all_digitized.csv')),'No intact-parent interpretation')
    check('unreadable oral markers retained',sum(not x['value_ng_mL'] for x in readcsv('validation_datasets/Son2021_PO05_digitized.csv'))==4,'Four early points remain unresolved')
    check('Danilov post dose separated',float(pdctx[-1]['nominal_concentration_uM'])==2.5,'Not an EC50 fit')
    csvout('tables/provenance_checks.csv',checks)
    if any(x['status']=='fail' for x in checks):raise RuntimeError(checks)
    def htable(rows):
        if not rows:return ''
        keys=list(rows[0]);esc=lambda x:html.escape(str(x))
        return '<div class="scroll"><table><thead><tr>'+''.join('<th>'+esc(k)+'</th>' for k in keys)+'</tr></thead><tbody>'+''.join('<tr>'+''.join('<td>'+esc(r.get(k,''))+'</td>' for k in keys)+'</tr>' for r in rows)+'</tbody></table></div>'
    body='<h1>四菌 PK–PD 证据与数据 v0.2</h1><p>文献依据、实际观测、假设与验证结果集中展示。模型尚无匹配的L168外部验证。图中工程算例不是测量。</p><input id="search" placeholder="筛选当前表格：来源、模块、参数、数据用途…"><nav><a href="#eq">方程</a> · <a href="#refs">文献</a> · <a href="#params">参数</a> · <a href="#data">全部数据</a> · <a href="#results">结果</a></nav>'
    body+='<h2 id="eq">方程与证据</h2>'+htable(eq)+'<h2 id="refs">原始文献</h2>'+htable(sources)
    body+='<p>'+''.join('<a href="'+html.escape(r['url'])+'">'+r['source_id']+'</a> · ' for r in sources)+'</p>'
    body+='<h2 id="params">参数及换算</h2>'+htable(pars)+'<h2 id="data">数据用途</h2>'+htable(registry)
    for key,path in datasets:body+='<h3>'+key+'</h3><p><a href="'+path+'">CSV文件</a></p>'+htable(readcsv(path))
    body+='<h3>归档原图与提取说明</h3><p>原图来自原研究，版权与许可归原出版方；它们是数字化核对材料，不是本团队数据。</p><img src="validation_datasets/Kurano2022_figure.jpg"><img src="validation_datasets/Son2021_figure.jpg"><p>Kurano时间0为给药后首点；Son原图Time(h)与方法min冲突，当前按方法解释，不能隐藏该限制。</p>'
    body+='<h2 id="results">逐点比较与失败结果</h2>'
    for path in ['tables/son_heldout_metrics.csv','tables/son_IV_comparison.csv','tables/son_PO05_comparison.csv','tables/kurano_comparison.csv','tables/module_summary.csv','tables/local_sensitivity.csv','tables/provenance_checks.csv']:
        body+='<h3>'+path+'</h3>'+htable(readcsv(path))
    body+='<h2>模型图与报告</h2><p>图2–5、7为工程算例或条件性分析；图6为同论文文献比较。图注见figures/captions.md。</p>'+''.join('<figure><img src="figures/figure_'+str(i)+'.png"><figcaption>Figure '+str(i)+'</figcaption></figure>' for i in range(1,8))
    body+='<p><a href="evidence_dossier.md">中文证据审查</a> · <a href="data_atlas.md">数据说明</a> · <a href="validation_report.md">验证报告</a> · <a href="references.bib">BibTeX</a></p>'
    write('evidence_report.html','<!doctype html><html lang="zh"><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>PKPD 证据和数据</title><style>body{font:15px/1.6 system-ui;margin:30px auto;max-width:1450px;padding:0 22px;color:#243444}h1,h2{color:#174c62}a{color:#14678a}input{padding:12px;width:60%;font:inherit}.scroll{overflow:auto;max-height:600px;margin:20px 0;border:1px solid #ccd6dd}table{border-collapse:collapse;font-size:12px}th{background:#eaf1f5;position:sticky;top:0}td,th{padding:9px;border:1px solid #dae2e7;vertical-align:top;min-width:90px;max-width:420px}img{max-width:100%;display:block;margin:20px 0}figure{max-width:1100px}nav{padding:15px;background:#eef4f6}</style>'+body+'<script>document.querySelector("#search").addEventListener("input",e=>{const q=e.target.value.toLowerCase();document.querySelectorAll("tbody tr").forEach(r=>r.hidden=!r.textContent.toLowerCase().includes(q))})</script></html>')
    print('v0.2:',len(sources),'references;',len(pars),'parameters;',len(registry),'dataset roles;',len(checks),'provenance checks passed')

if __name__=='__main__':enhance()
