"""All non-literature numbers are named engineering fixtures, NOT physiological priors."""
from pathlib import Path
import json,csv
ROOT=Path(__file__).resolve().parents[1]
values={
 'V_nose':1.,'V_B':1.,'V_C':1.,'V_P':1.,'count_scale':1e8,
 'N0_scaled':1.,'weights':[.25]*4,'dep':[.2,.3,.1],'survival':1.,
 'mu':[0.]*4,'death':[0.]*4,'kloss':1.,'growth_K':1.,'capacity':10.,
 'growth_resource0':10.,'growth_cost':1.,'precursor0':[20.]*4,'prec_K':1.,
 'qG':.2,'qA':.2,'qS':.1,'qN':.3,'KG':.1,'KA':.1,'ammonia_yield':1.,
 'baseline_G':1.,'baseline_A':.1,'PSbc_G':1.,'PSbc_A':1.,'PSeff_G':.1,'PSeff_A':.1,
 'kh_G':.2,'kh_A':.2,'Qcsf':.1,'kmuc':1.,'kf':10.,'kr':.1,'kconj':.1,
 'tau':.5,'EC_S':1.,'EC_N':1.,'PD_tau':1.,
}
for j in ['S','N']:
 values.update({'kabs_'+j:.5,'fdir_'+j:.01,'fsys_'+j:.5,'PSpb_'+j:.1,'PSdrugbc_'+j:.1,
                'kd_'+j:.1,'kp_'+j:1.,'kb_'+j:.5,'kc_'+j:.1})
def unit(k):
 if k.startswith('V_'):return 'mL'
 if k=='count_scale':return 'CFU/scaled_count'
 if k=='N0_scaled' or k=='capacity':return 'scaled_count'
 if k in ['weights','dep','survival','ammonia_yield'] or k.startswith(('fdir','fsys')):return 'dimensionless'
 if k=='growth_cost':return 'abstract_resource_equivalent/scaled_count'
 if k.startswith('PS') or k=='Qcsf':return 'mL/h'
 if k in ['baseline_G','baseline_A','KG','KA','EC_S','EC_N']:return 'nmol/mL'
 if k in ['tau','PD_tau']:return 'h'
 if k.startswith('q'):return 'nmol/(h scaled_count)'
 if k=='kf':return 'mL/(nmol h)'
 if k in ['growth_resource0','growth_K','precursor0','prec_K']:return 'abstract_resource_equivalent'
 return 'h^-1'
def module(k):
 if k in ['N0_scaled','weights','dep','survival','kloss','count_scale']:return 'M1/M2'
 if k.startswith(('growth','mu','death')) or k=='capacity':return 'M2'
 if k in ['qG','qA','KG','KA','ammonia_yield']:return 'M3'
 if k.startswith(('baseline','PSbc','PSeff','kh')) or k=='Qcsf':return 'M4'
 if k.startswith(('qS','qN','prec','kf','kr','kconj','kd')) or k=='kmuc':return 'M5'
 if k.startswith(('EC_','PD_')):return 'M7'
 return 'M6'
def make(vals,label):
 return {'version':'0.1','label':label,'warning':'Engineering unit fixture; not fitted, not a human anatomy/dose, not a plausible range.',
 'parameters':{k:{'value':v,'unit':unit(k),'module':module(k),'evidence':'D' if k=='count_scale' else 'E',
 'source':'Exact coordinate rescaling' if k=='count_scale' else 'Explicitly chosen software fixture; no physiological evidence',
 'purpose':'internal_verification_and_scenario_only','constraint':'unconstrained in target setting'} for k,v in vals.items()}}
if __name__=='__main__':
 (ROOT/'configs'/'engineering_fixture.json').write_text(json.dumps(make(values,'nonzero coupled engineering fixture'),indent=2))
 conservative=values.copy()
 for k in ['qG','qA','qS','qN','PSeff_G','PSeff_A','fdir_S','fdir_N']:conservative[k]=0.
 (ROOT/'configs'/'conservative.json').write_text(json.dumps(make(conservative,'zero unverified function and surface exchange'),indent=2))
 rows=[]
 for k,v in make(values,'fixture')['parameters'].items():
  rows.append(dict(parameter=k,symbol=k,module=v['module'],meaning=k,value=json.dumps(v['value']),range='unknown; fixture only',original_unit=v['unit'],model_unit=v['unit'],source_url='',source_location='configs/engineering_fixture.json',species='none; engineering fixture',tissue='abstract amount pools',route='none',analyte='defined in equations.md',extraction='explicit fixture choice',uncertainty='not a probability distribution',conversion='identity; count scale exact',purpose=v['purpose'],extrapolation_risk='not valid for biological prediction',evidence=v['evidence']))
 with (ROOT/'parameter_registry.csv').open('w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=rows[0]);w.writeheader();w.writerows(rows)
