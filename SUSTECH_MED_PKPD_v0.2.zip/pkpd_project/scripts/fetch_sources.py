"""Fetch primary full texts without interpreting unavailable pages as evidence."""
from pathlib import Path
import urllib.request, concurrent.futures, json, hashlib, re
from html import unescape
ROOT=Path(__file__).resolve().parents[1]
SOURCES={
 'Son2021':'https://www.mdpi.com/1999-4923/13/7/958',
 'Kurano2022':'https://www.mdpi.com/1999-4923/14/12/2590',
 'Melin2020':'https://www.nature.com/articles/s41598-020-72031-5',
 'Zolnourian2025':'https://link.springer.com/article/10.1007/s12975-024-01278-1',
 'Krismer2014':'https://journals.plos.org/plospathogens/article?id=10.1371/journal.ppat.1003862',
 'Shang2021':'https://journals.plos.org/plosone/article?id=10.1371/journal.pone.0246007',
 'Zhang2023':'https://www.ebi.ac.uk/europepmc/webservices/rest/PMC10525405/fullTextXML',
 'Mi2010':'https://www.ebi.ac.uk/europepmc/webservices/rest/PMC2992988/fullTextXML',
 'Danilov2009':'https://www.ebi.ac.uk/europepmc/webservices/rest/PMC2657190/fullTextXML',
 'Assay2023':'https://www.ebi.ac.uk/europepmc/webservices/rest/PMC10472501/fullTextXML',
 'DeBoeck2020':'https://pubmed.ncbi.nlm.nih.gov/?term=10.1016%2Fj.celrep.2020.107674',
 'Shen2025':'https://pubmed.ncbi.nlm.nih.gov/39914382/',
 'Hong2026':'https://pubmed.ncbi.nlm.nih.gov/42480526/',
 'PekingModel':'https://2025.igem.wiki/peking/model/',
 'PekingResults':'https://2025.igem.wiki/peking/results/',
}
def fetch(item):
 key,url=item
 try:
  data=urllib.request.urlopen(url,timeout=30).read()
  raw=data.decode('utf-8','replace')
  if 'Checking your browser' in raw[:10000] or len(data)<1000: raise ValueError('challenge or empty page')
  ext='xml' if 'XML' in url else 'html'
  (ROOT/'literature_sources'/f'{key}.{ext}').write_bytes(data)
  txt=unescape(re.sub('<[^>]+>',' ',re.sub(r'<(script|style)\b.*?</\1>','',raw,flags=re.S)))
  txt=re.sub(r'[ \t]+',' ',txt)
  (ROOT/'literature_sources'/f'{key}.txt').write_text(txt)
  return dict(id=key,url=url,status='retrieved',bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
 except Exception as e: return dict(id=key,url=url,status='failed',reason=str(e))
if __name__=='__main__':
 with concurrent.futures.ThreadPoolExecutor(max_workers=8) as ex: rows=list(ex.map(fetch,SOURCES.items()))
 (ROOT/'literature_sources'/'retrieval_log.json').write_text(json.dumps(rows,indent=2))
 for r in rows: print(r['id'],r['status'],r.get('bytes',r.get('reason')))
