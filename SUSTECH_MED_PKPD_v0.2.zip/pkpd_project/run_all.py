"""Offline, deterministic rebuild. Raw user inputs are never written."""
from pathlib import Path
import subprocess,sys,json,hashlib,platform,os
os.environ['PYTHONUTF8']='1'  # UTF-8 child scripts and Chinese reports on Windows too.
ROOT=Path(__file__).resolve().parent
def run(script):
 r=subprocess.run([sys.executable,str(ROOT/script)],cwd=ROOT,capture_output=True,text=True,encoding='utf-8')
 print(script, 'OK' if r.returncode==0 else 'FAILED')
 if r.returncode:
  print(r.stdout,r.stderr);raise SystemExit(r.returncode)
def main():
 for s in ['scripts/build_configs.py','scripts/extract_data.py','scripts/build_evidence.py']:run(s)
 t=subprocess.run([sys.executable,'-m','unittest','discover','-s','tests','-v'],cwd=ROOT,capture_output=True,text=True,encoding='utf-8')
 (ROOT/'tables'/'test_log.txt').write_text(t.stdout+t.stderr)
 print(t.stdout+t.stderr)
 if t.returncode:raise SystemExit(t.returncode)
 for s in ['scripts/run_analysis.py','scripts/uncertainty.py','scripts/make_figures.py','scripts/build_reports.py','scripts/enhance_evidence.py']:run(s)
 import numpy,scipy,matplotlib
 (ROOT/'requirements-lock.txt').write_text(f'numpy=={numpy.__version__}\nscipy=={scipy.__version__}\nmatplotlib=={matplotlib.__version__}\n')
 (ROOT/'tables'/'environment.json').write_text(json.dumps({'python':sys.version,'platform':platform.platform()},indent=2))
 manifest=[]
 for p in sorted(ROOT.rglob('*')):
  if not p.is_file() or '__pycache__' in p.parts or p.name=='file_manifest.json':continue
  manifest.append(dict(path=str(p.relative_to(ROOT)),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
 (ROOT/'file_manifest.json').write_text(json.dumps(manifest,indent=2))
 print('Completed offline rebuild; independent-study biological validation remains insufficient.')
if __name__=='__main__':main()
