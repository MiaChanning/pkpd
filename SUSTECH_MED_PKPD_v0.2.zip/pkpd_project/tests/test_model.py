import unittest,sys,copy
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from model import *

class PhysicsChecks(unittest.TestCase):
 def setUp(self): self.p=load_config(ROOT/'configs'/'engineering_fixture.json')
 def test_nitrogen_ledger(self):
  for beta in [0,.5,1]:
   p=copy.deepcopy(self.p);p['ammonia_yield']=beta;s=simulate(p)
   self.assertLess(np.ptp(nitrogen_total(s.y)),1e-8)
 def test_drug_equivalents(self):
  s=simulate(self.p)
  for j in ['S','N']:self.assertLess(np.ptp(drug_total(s.y,j)),1e-9)
 def test_nonnegative_extremes(self):
  for kf in [0,10,1000]:
   p=copy.deepcopy(self.p);p['kf']=kf;s=simulate(p,method='Radau')
   self.assertGreater(s.y.min(),-1e-9)
 def test_zero_exchange_brain_effect(self):
  p=copy.deepcopy(self.p);p['PSeff_G']=p['PSeff_A']=0
  s=simulate(p);c=simulate(p,False)
  np.testing.assert_allclose(s.y[[9,10,12,13]],c.y[[9,10,12,13]],atol=1e-10,rtol=1e-9)
 def test_zero_drug_sources(self):
  p=copy.deepcopy(self.p);p['qS']=p['qN']=0;s=simulate(p)
  self.assertEqual(float(np.max(np.abs(s.y[19:]))),0.)
 def test_no_bacteria(self):
  s=simulate(self.p,False)
  self.assertEqual(float(np.max(np.abs(s.y[19:]))),0.)
 def test_host_steady_state(self):
  s=simulate(self.p,False)
  np.testing.assert_allclose(s.y[9:15],np.repeat(s.y[9:15,0,None],s.t.size,axis=1),atol=1e-10)
 def test_non_growth_residence_analytic(self):
  s=simulate(self.p);init=initial_state(self.p)[:4,None]
  np.testing.assert_allclose(s.y[:4],init*np.exp(-self.p['kloss']*s.t),atol=1e-10)
 def test_solver_and_step_convergence(self):
  s=simulate(self.p,max_step=.25);a=simulate(self.p,max_step=.05);r=simulate(self.p,method='Radau')
  np.testing.assert_allclose(s.y,a.y,atol=1e-8,rtol=1e-6)
  np.testing.assert_allclose(s.y,r.y,atol=1e-8,rtol=1e-6)
 def test_two_pool_exchange_analytic(self):
  # Unequal volumes, no source/sink. Conservation and relaxation are independent benchmarks.
  v1,v2,ps=2.,3.,.4;n0=np.array([2.,0.]);t=np.linspace(0,20,101)
  r=solve_ivp(lambda t,y:np.array([-1,1])*ps*(y[0]/v1-y[1]/v2),(0,20),n0,t_eval=t,rtol=1e-10,atol=1e-12)
  ceq=2/(v1+v2);expected=v1*(ceq+(1-ceq)*np.exp(-ps*(1/v1+1/v2)*t))
  np.testing.assert_allclose(r.y[0],expected,atol=1e-9)
 def test_erlang_delay_mean_and_mass(self):
  tau=.5;k=2/tau;t=np.linspace(0,10,2001)
  sol=solve_ivp(lambda t,y:[-k*y[0],k*(y[0]-y[1]),k*y[1]],(0,10),[1,0,0],t_eval=t,rtol=1e-10,atol=1e-12)
  flux=k*sol.y[1];mean=np.trapezoid(t*flux,t)/np.trapezoid(flux,t)
  self.assertAlmostEqual(mean,tau,places=4)
  np.testing.assert_allclose(sol.y.sum(axis=0),1,atol=1e-10)
  np.testing.assert_allclose(flux,k*k*t*np.exp(-k*t),atol=1e-8)
 def test_resource_limits(self):
  p=copy.deepcopy(self.p);p['mu']=[2.]*4;p['kloss']=0;s=simulate(p)
  self.assertGreaterEqual(s.y[4].min(),-1e-9)
  self.assertLessEqual(s.y[:4,-1].sum()-s.y[:4,0].sum(),p['growth_resource0']/p['growth_cost']+1e-7)
  for k,prec in [(34,7),(35,8)]:self.assertLessEqual(s.y[k,-1],p['precursor0'][prec-5]+1e-8)
 def test_invalid_config(self):
  p=copy.deepcopy(self.p);p['fdir_S']=.8;p['fsys_S']=.8
  with self.assertRaises(ValueError):simulate(p)
 def test_backsolve(self):
  self.assertAlmostEqual(perfect_sink_reduction(required_exchange(.1,.2),.2),.1)
  self.assertEqual(required_drug_input(1,1,1,0,1),float('inf'))
 def test_volume_scaling(self):
  self.assertEqual(1000*.001,1)  # mm^3 -> mL
  self.assertEqual(1e-9/1e-3*1e6,1)  # nmol/mL -> uM
if __name__=='__main__':unittest.main(verbosity=2)
