"""Study-specific PK benchmarks, kept separate from uncalibrated nasal physiology."""
import numpy as np
from scipy.optimize import brentq
def oral_concentration(t_min,dose_mgkg,F,CL_ml_min_kg,V_mlkg,ka_min):
    t=np.asarray(t_min);ke=CL_ml_min_kg/V_mlkg
    return dose_mgkg*1000/V_mlkg*F*ka_min/(ka_min-ke)*(np.exp(-ke*t)-np.exp(-ka_min*t))
def calibrate_son(table):
    # IV CL and Vss, oral0.1 F and Tmax only. Vss as V is a testable simplification.
    iv=next(r for r in table if r['route']=='IV')
    po=next(r for r in table if r['route']=='PO' and float(r['dose_mg_kg'])==.1)
    cl=float(iv['CL_mL_min_kg']);v=float(iv['Vss_mL_kg']);ke=cl/v
    tmax=float(po['Tmax_min']);F=float(po['reported_F_percent'])/100
    ka=brentq(lambda k:np.log(k/ke)/(k-ke)-tmax,ke*1.0001,100.)
    return dict(CL=cl,V=v,ke=ke,ka=ka,F=F,tmax=tmax)
def fit_decay(t,y):
    # Two identifiable effective parameters. No mechanism-specific CL or V inferred.
    slope,intercept=np.polyfit(np.asarray(t),np.log(y),1)
    return dict(amplitude=float(np.exp(intercept)),k_min=float(-slope),model='empirical_exponential_total_label')
def decay(t,fit):return fit['amplitude']*np.exp(-fit['k_min']*np.asarray(t))
def positive_metrics(pred,obs):
    pred=np.asarray(pred);obs=np.asarray(obs)
    if np.any(pred<=0) or np.any(obs<=0):raise ValueError('ratio requires positive values')
    logs=np.log10(pred/obs)
    return dict(log_RMSE=float(np.sqrt(np.mean(logs**2))),max_Elog=float(np.max(np.abs(logs))),
                median_R=float(np.median(pred/obs)),order_screen_all=bool(np.all(np.abs(logs)<=1)),
                twofold_screen_all=bool(np.all(np.abs(logs)<=np.log10(2))))
