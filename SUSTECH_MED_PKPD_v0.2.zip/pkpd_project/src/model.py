"""Amount-based four-function research model. No parameter is an inferred human value.

Time h; amounts nmol; volumes mL; concentration nmol/mL = uM.
Bacteria are scaled by count_scale CFU. Nitrogen and drug ledgers include exits.
"""
from pathlib import Path
import json, copy
import numpy as np
from scipy.integrate import solve_ivp

ROOT=Path(__file__).resolve().parents[1]
NAMES=['NG','NA','NS','NN','growth_resource','prec_G','prec_A','prec_S','prec_N',
       'G_B','G_C','G_nose','A_B','A_C','A_nose','Glu_nose','fixed_N','nitrogen_input','nitrogen_exit',
       'S_nose','S_T1','S_T2','S_P','S_B','S_C','S_exit',
       'N_nose','N_T1','N_T2','N_P','N_B','N_C','N_exit','SN_nose',
       'S_produced','N_produced','response_S','response_N']
IDX={s:i for i,s in enumerate(NAMES)}

def load_config(path=None):
    doc=json.loads(Path(path or ROOT/'configs'/'conservative.json').read_text())
    p={k:v['value'] for k,v in doc['parameters'].items()}
    validate(p)
    return p

def validate(p):
    if any(np.any(np.asarray(v)<0) for v in p.values()): raise ValueError('negative parameter')
    if any(p[k]<=0 for k in ['V_nose','V_B','V_C','V_P','count_scale','growth_K','capacity','tau','EC_S','EC_N','PD_tau','KG','KA','prec_K']):
        raise ValueError('positive scales required')
    if not np.isclose(sum(p['weights']),1) or sum(p['dep'])>1: raise ValueError('invalid fractions')
    if not 0<=p['survival']<=1: raise ValueError('invalid survival fraction')
    if any(len(p[k])!=4 for k in ['weights','mu','death','precursor0']):raise ValueError('four strain values required')
    if not 0<=p['ammonia_yield']<=1: raise ValueError('invalid nitrogen yield')
    for j in ['S','N']:
        if p['fdir_'+j]+p['fsys_'+j]>1: raise ValueError('absorption fractions exceed 1')

def microbial_rates(y,p):
    n=y[:4]; gr=y[4]
    growth=np.asarray(p['mu'])*n*gr/(p['growth_K']+gr)/(1+n.sum()/p['capacity'])
    prec=y[5:9]
    avail=prec/(p['prec_K']+prec)
    g=y[11]/p['V_nose']; a=y[14]/p['V_nose']
    vg=p['qG']*n[0]*g/(p['KG']+g)*avail[0]
    va=p['qA']*n[1]*a/(p['KA']+a)*avail[1]
    rs=p['qS']*n[2]*avail[2]; rn=p['qN']*n[3]*avail[3]
    return growth,vg,va,rs,rn

def host_sources(p):
    # Fix source once using the zero-surface-exchange steady state.
    src=[]
    for j in ['G','A']:
        b=p['baseline_'+j]
        c=p['PSbc_'+j]*b/(p['PSbc_'+j]+p['Qcsf'])
        src.append(p['kh_'+j]*p['V_B']*b+p['PSbc_'+j]*(b-c))
    return src

def host_matrix(p,j):
    vb,vc,vn=p['V_B'],p['V_C'],p['V_nose']; a=p['PSbc_'+j]; e=p['PSeff_'+j]
    return np.array([[-p['kh_'+j]-a/vb,a/vc,0],
                     [a/vb,-(a+p['Qcsf']+e)/vc,e/vn],
                     [0,e/vc,-e/vn-p['kmuc']]])

def initial_state(p,with_bacteria=True):
    y=np.zeros(len(NAMES))
    y[:4]=p['N0_scaled']*np.asarray(p['weights'])*sum(p['dep'])*p['survival'] if with_bacteria else 0
    y[4]=p['growth_resource0'];y[5:9]=p['precursor0']
    for j,k,s in zip(['G','A'],[9,12],host_sources(p)):
        y[k:k+3]=np.linalg.solve(-host_matrix(p,j),[s,0,0])
    return y

def rhs(t,y,p):
    dy=np.zeros_like(y)
    growth,vg,va,rs,rn=microbial_rates(y,p)
    dy[:4]=growth-(np.asarray(p['death'])+p['kloss'])*y[:4]
    dy[4]=-growth.sum()*p['growth_cost']
    dy[5:9]=[-vg,-va,-rs,-rn]  # abstract precursor equivalents, not a resolved carbon network
    source=host_sources(p)
    for j,k,s in zip(['G','A'],[9,12],source):
        dy[k:k+3]=host_matrix(p,j)@y[k:k+3]+np.array([s,0,0])
    beta=p['ammonia_yield']
    dy[11]-=vg;dy[14]+=beta*vg-va
    dy[15]=vg-p['kmuc']*y[15]
    dy[16]=(1-beta)*vg+va  # N atoms in unresolved assimilation/retention products
    dy[17]=2*source[0]+source[1]
    dy[18]=2*(p['kh_G']*y[9]+p['Qcsf']*y[10]/p['V_C']+p['kmuc']*y[11])
    dy[18]+=p['kh_A']*y[12]+p['Qcsf']*y[13]/p['V_C']+p['kmuc']*y[14]+p['kmuc']*y[15]
    conj=y[33]; r=p['kf']*y[19]*y[26]/p['V_nose']-p['kr']*conj
    conj_loss=(p['kconj']+p['kmuc'])*conj
    dy[33]=r-conj_loss
    for j,k,prod,ctr in [('S',19,rs,34),('N',26,rn,35)]:
        nose,t1,t2,pl,br,cs,ex=y[k:k+7]
        absflux=p['kabs_'+j]*nose
        fd,fs=p['fdir_'+j],p['fsys_'+j]
        tr=2/p['tau']
        jpb=p['PSpb_'+j]*(pl/p['V_P']-br/p['V_B'])
        jbc=p['PSdrugbc_'+j]*(br/p['V_B']-cs/p['V_C'])
        nasal_loss=(p['kmuc']+p['kd_'+j])*nose
        losses=[p['kp_'+j]*pl,p['kb_'+j]*br,p['kc_'+j]*cs]
        dy[k:k+7]=[prod-absflux-nasal_loss-r,fd*absflux-tr*t1,tr*(t1-t2),
                   fs*absflux-jpb-losses[0],tr*t2+jpb-jbc-losses[1],jbc-losses[2],
                   nasal_loss+(1-fd-fs)*absflux+sum(losses)+conj_loss]
        dy[ctr]=prod
        c=br/p['V_B']; ec=p['EC_'+j]
        dy[36+(j=='N')]=(c/(ec+c)-y[36+(j=='N')])/p['PD_tau']
    return dy

def simulate(p=None,with_bacteria=True,T=24,points=241,method='DOP853',rtol=1e-9,atol=1e-11,max_step=.25,y0=None):
    p=load_config() if p is None else p;validate(p)
    sol=solve_ivp(lambda t,y:rhs(t,y,p),(0,T),initial_state(p,with_bacteria) if y0 is None else y0,
                  t_eval=np.linspace(0,T,points),method=method,rtol=rtol,atol=atol,max_step=max_step)
    if not sol.success: raise RuntimeError(sol.message)
    if sol.y.min()<-1e-7: raise RuntimeError('negative state: no clipping performed')
    return sol

def nitrogen_total(y):
    return 2*np.sum(y[9:12],axis=0)+np.sum(y[12:15],axis=0)+y[15]+y[16]+y[18]-y[17]

def drug_total(y,j):
    k=19 if j=='S' else 26;ctr=34 if j=='S' else 35
    return np.sum(y[k:k+7],axis=0)+y[33]-y[ctr]

def unit_nasal_exposure(k_loss,T):
    """Integral of N/N0 for non-growing bacteria: h."""
    return T if k_loss==0 else -np.expm1(-k_loss*T)/k_loss

def perfect_sink_reduction(e,h):
    """Upper envelope for ONE combined host pool; e,h h^-1, infinite sink, steady state."""
    return e/(e+h)

def required_exchange(delta,h):
    if not 0<=delta<1 or h<=0: raise ValueError('invalid target')
    return h*delta/(1-delta)

def required_drug_input(target,V,kb,delivery_fraction,availability):
    """nmol/h steady-state requirement; infinity for a blocked path."""
    f=delivery_fraction*availability
    return float('inf') if f==0 else target*V*kb/f
