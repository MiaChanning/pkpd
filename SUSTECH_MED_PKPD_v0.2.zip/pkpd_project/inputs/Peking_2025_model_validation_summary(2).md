# Peking 2025：模型验证思路、实际证据与对我们 PK/PD 的启示

整理日期：2026-10-09。

本文区分**团队公开报告的结果、本文对证据的评价、面向我们项目的建议**。本次重新阅读了 Model 与 Results，并检查了部分公开代码和单位换算；没有重跑北大的完整仿真或 MD 轨迹，也没有逐篇复核网页引用的底层论文。

配套文档：[我们当前的 PK/PD 模型总结](E:/desk/IGEM_2026_final/description/PKPD_model_summary.md)。

资料来源主要是北京大学 iGEM 2025 官方 wiki 的 [Model](https://2025.igem.wiki/peking/model/)、[Results](https://2025.igem.wiki/peking/results/)、[Engineering](https://2025.igem.wiki/peking/engineering/)、[Experiments](https://2025.igem.wiki/peking/experiments/) 和 [Hardware](https://2025.igem.wiki/peking/hardware/) 页面。该网站标注采用 Creative Commons Attribution 4.0 International License，网页仓库在 iGEM GitLab，dry lab 代码另给出 [GitHub repository](https://github.com/JianzheLi/iGEM-Peking2025)。

## 一句话结论

北大把复杂递送系统拆成多个可检查的物理和生物环节，分别引入实验现象、文献与物理参数、已知系统对照，以及仿真内部检查。这为部分模块提供了证据，但不同模块的支持程度差别很大。在本次查阅的公开材料中，尚未看到整条“给药—体内递送—局部暴露—治疗结局”链路的独立预测验证，更不能据此声称完成了人体验证。

这点对我们很重要：我们也做不了真人鼻腔-脑递送实验，所以应该学习他们的 "layered validation" 思路，而不是试图声称整个 PKPD 系统已经被完整验证。

## 他们的仿真系统由哪些层组成

Peking 2025 的项目是面向幽门螺杆菌的工程酵母系统，空间模型主要涉及胃腔、胃黏液和局部分泌环境。它不是已经全面验证的人体肠道数字孪生。dry lab 页面把药物旅程拆成以下链条：

1. pH 敏感微球在胃酸中稳定、在近中性胃黏膜环境中释放。
2. 碳酸钙 Janus 微球在酸性环境中产生 CO2 推进。
3. 微球在胃内扩散并穿透胃黏液层。
4. 工程酵母通过 C1ND-HopQ 体系黏附到 H. pylori 相关位置。
5. NAMH/组胺相关 GPCR 感应系统触发 pFUS1 下游表达。
6. AiiA 蛋白扩散并抑制 quorum sensing / biofilm。
7. 用改进 SEIR 模型讨论群体层面感染和治疗趋势。

这套系统的验证不是一个实验完成的，而是每一层有不同证据类型：湿实验、文献参数、分子模拟、ODE 模拟、对照组、负结果讨论和未来实验计划。

## 来源对照

为便于之后写 wiki 或引用，下面把关键判断对应到官方页面：

- pH 微球、推进、胃内扩散、黏液穿透、黏附 MD、GPCR MD/ODE、AiiA 扩散、SEIR 和代码开放主要来自 [Model](https://2025.igem.wiki/peking/model/)。
- 微球尺寸、pH 解聚、TTC 酵母活性、Janus beads 酸中运动、C1ND-HopQAD 黏附、GPCR/mCherry 负结果、AiiA biofilm 抑制主要来自 [Results](https://2025.igem.wiki/peking/results/)。
- DBTL 迭代、dry-lab 与 wet-lab 的互相补充、胃模型/GPCR/SEIR 的工程循环主要来自 [Engineering](https://2025.igem.wiki/peking/engineering/)。
- 实验流程、micromotor propulsion test、biofilm staining、GPCR function assay 等方法细节来自 [Experiments](https://2025.igem.wiki/peking/experiments/)。
- 微流控芯片设计和网站许可/仓库信息可从 [Hardware](https://2025.igem.wiki/peking/hardware/) 页面交叉核对。

## 总体验证框架

他们的验证思路可以概括为四层。

第一层是模块可行性验证。比如微球能否包裹酵母、在酸中稳定、在中性条件释放；C1ND 和 HopQAD 能否表达并共定位；AiiA 是否能降低 biofilm；这些都是湿实验能触碰到的环节。

第二层是参数与机制合理性论证。比如微球溶解模型用一阶动力学表达 pH 依赖释放；推进模型用 Stokes drag 和碳酸钙反应；AiiA 扩散模型用 Stokes-Einstein、半衰期和文献中同源蛋白扩散系数；GPCR MD 模型用已知构象变化作为激活判据。这些为模型提供了来源与物理解释，但仍需检查适用条件、单位及实际实现。本文后面列出了部分公开说明中的数值不一致。

第三层是对照和内部一致性检查。GPCR 模块中，他们用 P2Y2-Gpap 作为正对照来检查 "H6 内移" 这类激活判据是否能在模拟中出现；GPCR ODE 里检查 receptor activation -> scaffold assembly -> MAPK cascade -> gene expression 的时间顺序是否连续；SEIR 模型里比较无药和给药后的感染趋势。

第四层是失败结果和边界说明。他们的 sensory wet-lab 功能验证没有得到清晰的 histamine 梯度响应，反而观察到无 histamine 时 fluorescence 也随时间增加，解释为 pFUS1/工程 GPCR 系统存在 basal leakage。这些负结果说明该感应系统尚未满足功能验证要求，并为进一步排查背景信号提供方向。

## 各模块验证证据表

| 模块 | 模型要证明什么 | 他们怎么验证 | 证据强度 | 局限 |
|---|---|---|---|---|
| pH 敏感微球溶解 | 胶在胃酸中保护酵母，在近中性黏膜层释放 | Model 页给出一阶溶解动力学；Results 页显示微球 40-200 μm，平均约 100 μm；约 200 s 时酸性条件仍完整，中性/碱性条件明显或完全解聚；TTC 显示释放后酵母活性无明显下降 | 材料行为的实验支持 | Model 页承认用于展示的 pH-time 表格是 simulated data；精确动力学仍需更完整时间梯度 |
| 推进与运动 | CaCO3 在酸中产气推动 Janus 微球运动 | Model 页用 CaCO3 + acid 反应、Stokes drag 建模；Results 页用较大 Janus gel beads 做宏观模拟，pH 1.2 模拟胃液中观察到运动 | 中等 proof-of-concept | 他们未做出目标尺寸和质量的 micro-Janus micromotor；尚未在 simulated mucus 中验证穿透 |
| 胃内扩散和黏液穿透 | 微球能覆盖胃壁并进入 H. pylori 所在黏液层 | Model 页做胃内扩散/速度场/黏液穿透模拟，Engineering 页通过 DBTL 迭代从简单扩散到参数化胃模型和改进速度场 | 主要是计算预测与设计迭代 | 缺少真实胃黏液或动物体内递送数据；实际黏液结构、流场和胃蠕动不确定 |
| 黏附系统 | 工程酵母可通过 CEACAM1 N端 C1ND 结合 H. pylori 的 HopQ | Results 页显示 C1ND 在酵母表面表达、HopQAD 在 E. coli 表达；modified ICF/免疫荧光显示 C1ND 酵母与 HopQAD 蛋白共定位，对照组无 HopQAD fluorescence | 局部相互作用的概念验证 | 用的是 HopQ 可溶片段 HopQAD，不是完整膜蛋白；未在胃液条件测动力学参数；底盘是 auxotrophic S. cerevisiae，不是最终 S. boulardii |
| GPCR/感应系统 | NAMH/组胺感应触发 pFUS1 表达 | Dry lab 用 docking/MD 筛选候选 GPCR，并用 P2Y2-Gpap 正对照验证激活判据；wet lab 构建了多种 plasmid，用 histamine + mCherry 测响应 | 计算筛选较完整，湿实验为负结果 | 实验未出现明显 histamine 梯度响应；有 basal leakage；最终 NAMH 验证尚未完成 |
| AiiA 扩散与功能 | 分泌蛋白的空间分布及抗生物膜作用 | 模型预测阈值半径；湿实验测外加纯化 AiiA 对替代菌生物膜的剂量响应 | 分子功能有实验支持，空间浓度场未被该实验直接验证 | 替代菌不同于 H. pylori；工程酵母原位分泌和实际空间暴露未由该试验建立 |
| SEIR/群体感染 | 治疗引入后感染趋势下降，能讨论 resistance | Model 页扩展 SEIR，引入 exposed、treated/medicated population 和 drug resistance；比较无药与给药场景 | 情景模拟 | 不是人体临床预测；更像展示治疗策略的定性公共卫生影响 |

## 他们每一步具体如何验证

### 1. pH 微球释放：用实验约束材料行为

Model 页首先提出一阶溶解模型：

```text
dM/dt = -k * M
M(t) = M0 * exp(-k t)
k = f(pH)
```

验证策略是：先用 pH-time 数据拟合每个 pH 下的 k，再拟合 k 与 pH 的关系，最后预测任意 pH 下的释放曲线。这里要注意，Model 页明确说由于实验量限制，表格中用于展示方法的数据是 simulated data；这说明该处更像方法演示，而不是完整参数拟合。

但他们又用 wet lab 给了关键方向性验证：Results 页报道微球直径主要在 40-200 μm，平均约 100 μm；SEM 显示微球包裹酵母；约 200 s 时 pH 2.01 酸中不解聚，pH 7.44 明显解聚并释放酵母，pH 9.97 完全解聚；TTC 染色显示释放后的酵母活性与新鲜酵母没有显著差异。Model 页还说强酸中微球能保持未降解约 1 小时，中性环境约 90 s 完全降解，接近预测。

上述实验支持 pH 响应的方向，但不能把约 90 s 与约 200 s 的不同描述当成同一条件下已经吻合的定量验证；需要对应配方、介质和终点定义。模拟数据拟合主要证明拟合流程可运行，不能代替独立实验检验。[来源：释放模型](https://2025.igem.wiki/peking/model/#dissolution-kinetics-modeling-of-ph-sensitive-microspheres)、[递送实验结果](https://2025.igem.wiki/peking/results/#delivery-system)

对我们鼻腔模型的对应做法：鼻腔分泌、黏膜穿透或分子释放模块也应该有最小湿实验锚点。例如用人工鼻液或黏蛋白凝胶测分子释放/保留曲线，再让 PKPD 模型读取同一批实验估计出的释放速率，而不是直接使用文献或假设参数。

### 2. 推进/穿透：用宏观模拟证明机制存在，但诚实标注没有完成目标尺度

他们的推进模型把 CaCO3 和胃酸反应生成 CO2 的质量通量转成 thrust，再用低 Reynolds number 的 Stokes drag 写运动方程。这个物理框架的目标是证明 "酸中产气能给微球足够运动能力"。

湿实验验证采取了降级方案：他们没能制备出目标质量和尺寸的 microfluidic micromotor，所以 Results 页改用更大的 Janus gel beads 做 macroscopic simulation，并在 pH 1.2 simulated gastric fluid 中录制运动，证明酸中确实能产生推进现象。Results 页同时明确说明，未来仍需制备目标尺寸 micromotor，并在 simulated mucus 中进一步验证功能。

Model 页预测约 20 μm/s，并与文献中的 20–150 μm/s 比较；这是量级参照。Results 页把速度与距离的定量测量列为未来工作。因此，已经观察到运动，不等于预测速度已被本项目实验核准。[来源：推进模型](https://2025.igem.wiki/peking/model/#propulsion-model-of-micropheres-in-acidic-solution)、[递送实验与展望](https://2025.igem.wiki/peking/results/#delivery-system)

对我们鼻腔项目来说，如果没有办法做真实鼻脑递送，也可以做类似降级验证：例如人工鼻黏液中的扩散/滞留、细胞层通透性、或 ex vivo 鼻黏膜组织上的跨膜趋势。文档里必须说明这只是 transport submodel 的验证，而不是真人脑递送验证。

### 3. 黏附系统：用可替代靶标做 proof-of-concept，再承认完整环境未验证

北大的黏附模块用 C1ND-HopQ 作为靶向逻辑。Results 页报告：

- C1ND 在 S. cerevisiae 表面表达，用 SDS-PAGE 和 Western blot 确认。
- HopQAD 在 E. coli 中表达，SDS-PAGE/Western blot 显示 45-55 kDa，与约 49.3 kDa 预期大小一致。
- Modified ICF/免疫荧光实验中，C1ND 酵母与 HopQAD 蛋白共定位；无 C1ND 或无 HopQ 的对照没有 Cy3 signal。

共定位及缺少任一组分的对照，支持 C1ND 酵母与 HopQAD 的局部相互作用。与此同时，实验使用的是 HopQAD 可溶片段；C1ND 提取物也存在片段化问题。页面将更完整的结合及胃液条件下的表征保留为后续工作，不能从该结果直接得到真实菌体黏附率或动力学常数。[来源：黏附结果与讨论](https://2025.igem.wiki/peking/results/#adhesion-system)

这个逻辑对我们很有用：如果我们的模型中存在 "鼻腔菌黏附/定植/局部释放" 模块，验证时可以先做局部替代系统的 proof-of-concept，但文档要说清楚它不能直接给出体内定植率或长期 colonization 参数。

### 4. GPCR/感应系统：计算筛选与湿实验负结果互相校正

这是北大最值得借鉴的一部分，因为它不是单纯报喜。

Dry lab 上，他们用 docking/MD 分析 GPCR-ligand-G protein 组合。激活判据来自 class D fungal GPCR Ste2 的构象机制：活化时 H6 内端向内移动约 12 Å；他们监测 H2-H6 距离，并把 P2Y2-Gpap 作为正对照。Model 页报告正对照从约 3.5 nm 降到 1.5-2.0 nm，认为这验证了激活判据；hH3R-Gpaq、CH3R、hH3R-Gpai 等显示不同程度的 activation-like behavior。

Wet lab 上，他们构建了多种 histamine receptor / G protein / reporter plasmid，用 histamine 诱导 mCherry 荧光，并记录 OD600 以排除生长差异。但 Results 页明确写出：receptor did not show obvious response to histamine gradient；即使没有 histamine，fluorescence intensity 也随时间增加，趋势基本不依赖 histamine concentration。他们解释为下游 promoter 或工程 GPCR 系统存在 transcriptional leakage，背景噪声掩盖了真实诱导响应。

还要注意，Results 页明确写到湿实验阳性参照也没有完全达到预期；泄漏是作者提出的解释之一，页面同时保留了构建或敲除不完整等技术原因。初筛使用 histamine，最终 NAMH 验证仍在计划中。因此，不能把这次结果描述为感应系统验证成功，也不能将其简化为对某一 MD 候选的彻底否定。[来源：感应实验、对照与讨论](https://2025.igem.wiki/peking/results/#sensory-system)

这里可借鉴的是已知参照、无刺激对照以及公开报告失败结果。计算中的阳性系统能提供参照，但不能保证整个流程的识别能力；不同受体能否采用同一构象判据也需要依据。

对我们的启发：如果我们现在 PKPD 模型中某个药效模块没有实验响应曲线，例如 SFN/NAC 对 IL6/TNF 的剂量-时间关系、谷氨酰胺降解对下游代谢指标的影响，就不能只靠模型曲线。最好的验证是设置空载菌、无分泌、单药、联合、不同剂量和不同时间点，让模型必须解释 "无作用也会涨/背景漂移" 这类负对照。

### 5. AiiA 扩散和 biofilm 抑制：用 surrogate assay 支撑治疗机制

Model 页对 AiiA 建立三维扩散模型，报告约 300 s 后某个无量纲浓度阈值的半径约为 25 μm，并进一步讨论覆盖范围和给药情景。这些是模型预测，不是已经测量的抑菌半径。无量纲阈值与实际浓度之间还需要映射；后文列出的单位问题也限制了这些定量结果的使用。[来源：AiiA 模型](https://2025.igem.wiki/peking/model/#aiia-protein-diffusion-modeling)

湿实验上，他们没有直接做 H. pylori biofilm，而是用 P. aeruginosa biofilm 作为 quorum sensing / biofilm surrogate。Results 页显示，purified AiiA 以 1-10 μg/mL 处理，crystal violet OD550 测 biofilm；AiiA 对 biofilm biomass 有 dose-dependent reduction，1 μg/mL 已有抑制，2 μg/mL 和 5 μg/mL 抑制增强。

这些结果支持外加 AiiA 在所测替代体系中的功能方向。它们没有直接测量模型的空间浓度场，也没有完成“工程酵母感知信号后原位分泌，再作用于 H. pylori”的整链验证。[来源：治疗模块实验](https://2025.igem.wiki/peking/results/#therapy-system)

对我们来说，如果某个分子作用于脑炎症或氨代谢，至少要有一个 surrogate wet assay 支撑方向：例如炎症细胞因子、代谢物 LC-MS、酶活或分泌量。然后模型中药效函数要绑定这个 assay 的效应大小，而不是直接绑定最终疾病改善。

### 6. SEIR/系统仿真：展示趋势，不当作临床预测

他们的 SEIR 模型属于系统层面的情景模拟。Model 页说传统 SIR 不包含 incubation、treatment、medication willingness 和 drug resistance，所以他们加入 exposed、treated/medicated population 和 resistance-related recovery rate。结果显示，模型先复现 H. pylori 广泛流行趋势，给药后感染人数下降、治疗效果维持、抗性缓慢增长。

公开代码在第 1000 天把治疗覆盖率乘以 3、目标初始治疗恢复率乘以 5，并将耐药发展参数减半。感染下降是这些干预设定下的条件性结果，不能反向证明产品实际能实现相应效应。复现某个基线患病率，也不能唯一确定整套参数。[来源：SEIR 原文](https://2025.igem.wiki/peking/model/#improved-seir-model-to-simulate-the-therapeutic-effect-of-hpbuster-on-h-pylori-infection)、[代码中的干预设定](https://github.com/JianzheLi/iGEM-Peking2025/blob/6b4c399aa08525bb169b9235501f6c76db7b4121/SEIR/simu.py#L61-L71)

对我们的 PKPD 模型也是一样：整体 NPI/KYNA/QUIN 或脑炎症趋势图不能直接证明疗效。它只能说明，在一组透明假设下，模型预测方向是什么。真正让它可信的是每个参数和每个模块有没有独立锚点。

## 他们如何证明 "整个仿真系统 work"

更谨慎的判断是：公开材料支持部分模块的可行性，并展示了模型用于提出假设、筛选设计和定位待解决问题的用途；整套预测系统的准确性仍需更直接的证据。

他们用了以下证据链：

1. 物理递送环节有 wet-lab anchor：微球尺寸、pH 稳定/释放、酵母活性、酸中运动。
2. 关键生物相互作用有 proof-of-concept：C1ND-HopQAD 共定位，AiiA 抑制 biofilm。
3. 难以直接湿实验的结构问题用分子模拟：adhesion MD、GPCR docking/MD、激活判据。
4. 难以直接整体验证的时空问题用 ODE/PDE/SEIR：释放、推进、扩散、信号转导、群体感染。
5. 他们有对照和负结果：计算阳性系统提供参照；wet lab 暴露背景响应，泄漏是待排查解释之一。
6. 他们公开部分代码和页面证据，便于核对；本次可见仓库不足以复现所有网页模块。

这些属于多种证据的互相约束。证据支持到什么程度，应逐项说明，不能因项目获奖或模型复杂就跳过独立预测检验。

## 最值得我们学习的点

### 1. 把模型输出分成三类

北大页面里的结果其实可以分成三类：

- 已有实验支持的模块行为：pH 释放、酵母活性、外加 AiiA 的生物膜抑制方向；这不表示对应模型曲线已定量验证。
- 机制合理但未完整实验的模型输出：推进穿透、AiiA 空间覆盖、adhesion kinetics。
- 需要重做或优化的模型输出：GPCR 感应系统，因为湿实验没有显示清晰剂量响应。

我们自己的 PKPD 文档也应该这么写，而不是把所有曲线等价展示。

### 2. 负对照比漂亮曲线更重要

北大 sensory system 的负结果非常关键：没有 histamine 时 fluorescence 也升高。这直接对应我们 PKPD 目前发现的一个问题：无分泌时 NPI 也会上升，说明绝对 NPI 阈值不能直接归因于药物。我们应该像他们一样把这个写成模型待修正点，而不是隐藏。

### 3. 用 wet-lab 数据约束最靠近实验的参数

他们没有试图从真人疗效反推所有参数，而是先约束微球溶解、酵母活性、biofilm 抑制这些可测环节。我们也应该先用 wet_lab.md 中四个功能菌对应的可测读数约束模型：

- SFN/NAC：分泌量、稳定性、细胞炎症因子响应曲线。
- 谷氨酰胺降解：底物消耗速率和产物/氨相关读数。
- 氨转缬氨酸：氨下降、缬氨酸生成、菌体代谢负担。
- 四菌配比：单菌、双菌、四菌的分泌/代谢互扰。

这些读数比 "最终脑功能改善" 更现实，也更容易成为模型参数。

### 4. 模型验证要写成证据等级，而不是成功宣言

建议我们后续 wiki/文档用类似格式：

| Claim | Evidence | Status |
|---|---|---|
| 目标菌能产生目标分子 | 与目标分子相匹配的定性/定量分析；报告基因只能支持对应表达 | 按实际数据填写，本文不预填通过 |
| 分子能通过鼻黏膜释放并保持稳定 | 人工鼻液/黏液凝胶/细胞层 | pending |
| 模型变化能否归因于分泌 | 匹配的有/无分泌对照 | 已发现基线漂移；绝对阈值不足以判断药物贡献 |
| 联合菌优于单菌 | 单菌、组合组 wet data + model fit | pending |
| 对人体有治疗效果 | 无真人实验 | hypothesis only |

这比简单说 "our PKPD model validates the treatment" 更可信。

## 对我们当前 PKPD 的直接改写建议

结合前一个文档中的 PKPD 现状，我们可以把北大的验证框架迁移成下面的修改方向。

第一，将目标设为“逐模块建立并检验受数据约束的仿真平台”。当前还不能称为已完成模块验证的平台：现有代码没有接入完整四菌模块，且无分泌条件下 NPI 也会上升。

第二，给每个功能菌建立一个可测 wet-lab anchor。四个功能菌都在鼻腔，分子向脑递送，所以模型至少需要：

- 鼻腔分泌/释放速率：每种菌的目标分子产量随时间变化。
- 鼻腔局部稳定性：人工鼻液、pH、酶环境下分子半衰期。
- 转运或到达脑端的桥接参数：文献、体外屏障、ex vivo 或 conservative sensitivity range。
- 脑端效应函数：细胞模型中的 inflammatory/metabolic readout。

第三，保留并强调反事实模拟。至少要有：

- no bacteria / no secretion；
- single module；
- four-module combination；
- parameter sweep；
- dose/time sensitivity；
- baseline drift correction。

我们应明确每条曲线的参数依据、对照和适用范围。当前优先核查单位、初始状态与基线动态，再按四菌实际机制扩展方程。无药状态不一定必须恒定，但其自然变化应被解释，药物贡献应由匹配对照区分。

## 需要补充的模型核查：哪些做法不能直接照搬

### 1. 内部一致性、校准、独立验证不是同一件事

| 检查层次 | 回答的问题 | 需要的证据 |
| --- | --- | --- |
| 数值验证 | 方程有没有算对 | 解析解、守恒、步长和网格收敛 |
| 参数约束 | 数值有没有合理来源 | 自己的测量、适用条件匹配的文献或理论推导 |
| 校准 | 能否解释调参使用的数据 | 拟合曲线、残差、参数不确定性 |
| 独立预测 | 固定参数后能否预测未见条件 | 留出的剂量、时间、组合或批次 |
| 串联验证 | 上游预测能否传到最终可测输出 | 同一条件下的接口数据与独立终点 |
| 人体外推 | 在人体条件下是否仍成立 | 需要相应人体证据，不能由前几层自动替代 |

北大 GPCR ODE 展示了受体、支架、MAPK 和表达的时间先后顺序，这属于机制一致性展示。公开页面没有在这一节展示完整时间曲线的留出数据误差。黏附 MD 的能量、温压、RMSD/Rg 等检查支持模拟环境与结构行为的合理性；稳定轨迹本身不提供活菌黏附率。[来源：GPCR ODE](https://2025.igem.wiki/peking/model/#ode-modeling-of-g-protein-pathway-signal-transduction)、[黏附 MD](https://2025.igem.wiki/peking/model/#molecular-dynamics-simulation-analysis-of-the-hopq-c1nd-protein-complex)

### 2. 胃壁黏附率与穿透率是预测，不是实测比例

胃腔模型报告约 80% 最终接触并黏附胃壁；该结果依赖几何、流向与黏附规则。穿透模块由厚度、速度、持续时间和入射角计算约 97.9% 的可达比例，使用了角度均匀分布假设。角度均匀与三维方向各向同性不是同一个假设。

推进节报告约 20 μm/s，穿透节采用约 50 μm/s；若把两节视为同一预测链，必须说明取值对应条件。Results 页中较大微球能运动的观察，没有直接检验这些百分比。[来源：胃腔分布](https://2025.igem.wiki/peking/model/#mathematical-modeling-of-microsphere-diffusion-in-the-stomach)、[黏液穿透](https://2025.igem.wiki/peking/model/#physical-modeling-of-the-penetration-process-of-microspheres-through-gastric-mucus-layer)

### 3. AiiA 扩散参数存在可直接核查的单位不一致

这部分是本文算术复核，不是北大团队自己报告的验证结果。

页面使用 Stokes–Einstein 公式：

$$
D=\frac{k_BT}{6\pi\eta r_h}.
$$

代入其给出的温度 298.15 K、黏度 0.8900056×10⁻³ Pa·s、水合半径 2.55 nm，可得约 **96.22 μm²/s**。但页面参数表为 **0.0096 μm²/s**，相差约四个数量级。

对页面列出的三维等间距显式差分：

$$
\Delta t\leq\frac{\Delta x^2}{6D}.
$$

取空间步长 2.5 μm，表格 D 对应上限约 **108.51 s**；推导的 D 对应约 **0.01083 s**。两者都不等于正文所写的 1.09 s。

这确认了公开说明之间不一致。没有与原图对应的完整配置，不能断言实际画图使用了哪组数值，更不能未经核查就沿用其扩散半径或给药频率。[来源：AiiA 推导、参数与稳定性说明](https://2025.igem.wiki/peking/model/#aiia-protein-diffusion-modeling)

页面还同时提到持续源、零通量边界、浓度上限和失活项，需要核对实际接入的机制。对持续正源且无损失的封闭系统，总量会增加；数值裁剪产生的平台不能当作生物稳态的证据。

### 4. 网页与代码需要对应到同一个版本

本次核对的公开提交为 6b4c399aa08525bb169b9235501f6c76db7b4121。

- pH 代码明确标注输入为假设数据、等待湿实验结果，与其拟合图例使用“实验数据”的字样需要区分。
- GPCR 网页 Hill 系数为 1，代码为 2；结合和转录等参数也存在差异。
- 该版本树中可见五个 Python 文件，分别涉及 pH、推进、胃腔扩散、GPCR ODE、SEIR。没有看到覆盖全部网页模块的统一求解器、完整 MD 轨迹或 AiiA 三维求解脚本。胃腔的 diffusion 文件不等于 AiiA 扩散实现。

这些仅说明本次公开仓库的可检查范围，不表示团队内部没有其他代码。[来源：代码快照](https://github.com/JianzheLi/iGEM-Peking2025/tree/6b4c399aa08525bb169b9235501f6c76db7b4121)、[pH 数据](https://github.com/JianzheLi/iGEM-Peking2025/blob/6b4c399aa08525bb169b9235501f6c76db7b4121/PH/fit_simu.py#L5-L18)、[GPCR 参数](https://github.com/JianzheLi/iGEM-Peking2025/blob/6b4c399aa08525bb169b9235501f6c76db7b4121/GPCR/simu.py#L5-L48)

## 我们怎样补上“整条仿真链的验证”

以下是面向本项目的建议，不是北大已经完成的工作，也不是我们已经取得的结果。

### 第一步：先修正计算和接口问题

以现有 PK/PD 总结为依据，优先统一分泌量、浓度、mL/mm³ 等单位，检查无分泌对照、质量平衡与数值收敛。当前 8 项测试通过，只说明测试覆盖的程序行为可运行。

对 Erlang 转运模块，使用已知输入检查延迟分布。持续分泌曲线的峰值时间，不等于脉冲转运的平均延迟；验证指标必须与输入形式相匹配。[本地依据：PK/PD 总结](E:/desk/IGEM_2026_final/description/PKPD_model_summary.md)

### 第二步：分别校准可测模块，保留独立条件

源项用菌量和产物数据约束；局部代谢用底物、产物和含氮收支约束；PD 用已知暴露与实际可测细胞读数约束。

使用部分条件调参后，固定模型与参数，再预测留出的完整剂量、时间条件、组合或批次。留出数据不能同时用于挑选参数。若根据失败结果修改了模型，需要用新的独立条件继续检验。

不要只报告拟合优度。应事先确定有单位的误差指标、响应方向、峰值/累计暴露、时间延迟及预测区间；接受标准依据实验重复性和模型用途设定。

### 第三步：检验模块接口与最终输出

验证链可以是：

> 给定菌量与条件 → 预测胞外产物时间曲线 → 预测接收侧暴露 → 预测细胞/代谢响应 → 与未参与调参的终点比较。

每个接口都要明确分子身份、单位、时间尺度、转移损失和适用环境。上游输出应实际驱动下游，而不是在每个下游模块重新指定一个“合理常数”。

中间读数用于定位偏差：若产物已预测准确而接收侧暴露不准，就先检查输运；若暴露符合但细胞响应不符，就检查 PD。若目前只能测产物与细胞响应，则先检验可观测的两段映射，将未测的鼻脑部分列为未验证。

### 第四步：单独说明四菌鼻腔方案的跨部位机制

四菌都在鼻腔。鼻腔菌消耗谷氨酰胺或同化氨，并不会仅凭局部反应就自动形成脑内同种底物的清除通路。必须明确哪些分子从鼻腔进入脑侧，以及它们怎样产生所预测的作用。

SFN/NAC 应采用与自身机制和读数对应的 PD。现有 KMO 模型的 NPI 不能仅通过更换分子名称就成为四菌疗效指标。对体外 IL6/TNF 等读数的预测，也不能直接升级成临床症状预测。

### 第五步：记录每个结论的证据范围

| 字段 | 要记录什么 |
| --- | --- |
| 待检验结论 | 分子、条件、时间和输出 |
| 模型版本 | 代码、参数、求解设置 |
| 数据来源 | 实测、文献、理论、假设或合成数据 |
| 数据用途 | 校准、独立验证或演示 |
| 对照 | 无药/无分泌、已知响应、简化算例等 |
| 事先预测 | 固定参数后保存的数值与区间 |
| 评价标准 | 有单位的误差及预先确定的接受条件 |
| 状态 | 通过、未通过、证据不足或未评估 |
| 适用范围 | 已检验的实验体系、剂量、时间 |
| 下一步 | 缺少什么数据，失败后检查哪个环节 |

没有人体实验，仍然可以证明模型在特定体外条件下具有预测能力、实现满足数学与物理约束、设计结论在某个参数范围内稳定。人体脑暴露和治疗效果仍是外推；虚拟人群与蒙特卡洛传播的是输入假设的不确定性，不能创造缺失的人体证据。

## 可用于组会或后续 wiki 的表述

以下使用计划语气，避免把尚未完成的验证写成成果：

> 我们将借鉴 Peking 2025 的模块化验证思路，对可测环节分别建立实验约束，并使用已知响应和无分泌等对照检查模型。校准数据与独立验证数据将分开使用；在固定模型和参数后，我们将检验留出条件与可实现串联体系中的预测能力。对尚缺鼻脑输运数据的部分，我们会明确标注外推假设和不确定性，不将体外或计算结果表述为人体验证。

## 来源与使用说明

Peking 2025 官方 Wiki 页脚标注 [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/) 许可。原始项目内容归 Peking 2025 团队；本文作中文概括并加入证据评价、算术复核和项目建议，不是官方结论的逐字翻译。

本文的判断基于截至整理日期公开可见的资料。“尚未看到”表示本次核查范围内未找到对应证据，不等于断言团队从未开展过该项工作。网页引用的底层论文未在本次逐篇复核，因此参数有引用键不等于本文已经独立确认其适用条件。
