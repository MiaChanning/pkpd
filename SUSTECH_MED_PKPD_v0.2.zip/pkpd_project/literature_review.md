# 原始证据审查与可用数据

检索日期 2026-10-10。来源优先原始论文、出版方、PubMed/PMC；综述不用于关键参数。完整链接、访问深度与外推限制逐项列出。

## Shen2025 — M1/M6

[Engineered commensals for targeted nose-to-brain drug delivery](https://pubmed.ncbi.nlm.nih.gov/39914382/)。PubMed/search metadata; quantitative full text not accessed。

Engineered L. plantarum delivery in a different payload/animal system; target construct and SFN/NAC rates not verified.

## Hong2026 — M4

[CSF clearance through arachnoid fenestrations to olfactory meningeal lymphatics](https://pubmed.ncbi.nlm.nih.gov/42480526/)。PubMed abstract accessed。

Mouse tracers and primate anatomical comparison support lymphatic drainage to cervical nodes; no quantified lumen-accessible surface exchange.

## Melin2020 — M4

[In vivo assessment of cerebrospinal fluid efflux to nasal mucosa in humans](https://www.nature.com/articles/s41598-020-72031-5)。Full text。

Human intrathecal MRI tracer study did not detect significant enrichment in nasal mucosal ROIs. Spatial resolution and tracer properties limit inference; not a bound on Gln PS.

## Shang2021 — M1

[Prediction of nasal spray drug absorption influenced by mucociliary clearance](https://journals.plos.org/plosone/article?id=10.1371/journal.pone.0246007)。Full text。

Nasal geometry and modeled mucus velocities provide transport framework. Model-selected average 6 mm/min is not a measured L168 residence rate.

## DeBoeck2020 — M1/M2

[Lactobacilli Have a Niche in the Human Nose](https://www.cell.com/cell-reports/fulltext/S2211-1247%2820%2930627-6)。Publisher indexed text; no CFU time-series downloaded。

L. casei AMBR2 nasal pilot supports strain-specific upper-airway adaptation and detection after dosing. Detection frequencies cannot determine L168 growth/clearance constants.

## Krismer2014 — M2/M3

[Nutrient Limitation Governs Staphylococcus aureus Metabolism and Niche Adaptation in the Human Nose](https://journals.plos.org/plospathogens/article?id=10.1371/journal.ppat.1003862)。Full text。

Human nasal secretion chemistry supports nutrient limitation; Gln not found in analyzed samples. Do not equate non-detection with all noses having zero Gln.

## Kurano2022 — M6

[Intranasal Administration of N-acetyl-L-cysteine Combined with Cell-Penetrating Peptide-Modified Polymer Nanomicelles as a Potential Therapeutic Approach for Amyotrophic Lateral Sclerosis](https://www.mdpi.com/1999-4923/14/12/2590)。Full text and Fig2。

Mouse intranasal free/micelle NAC: plasma Fig2 digitized in %ID/mL. Liquid scintillation gives total 14C, not chemically intact parent NAC or free brain ECF.

## Zolnourian2025 — M6/M7

[A Randomised Controlled Trial of SFX-01 After Subarachnoid Haemorrhage — The SAS Study](https://link.springer.com/article/10.1007/s12975-024-01278-1)。Full text; online publication 2024。

Oral/NG stabilized SFN in SAH patients; paired CSF exposure mostly BQL. An important contrary exposure constraint, without matching nasal formulation or individual dataset.

## Mi2010 — M5

[A cautionary note on using N-acetylcysteine as an antagonist to assess isothiocyanate-induced ROS-mediated apoptosis](https://pmc.ncbi.nlm.nih.gov/articles/PMC2992988/)。Full text。

Hep3B cells: nominal 10 uM SFN with 5 mM NAC pretreatment, reduced labeled uptake. Supports extracellular chemical interference; does not supply nasal kf/kr or a universal antagonism coefficient.

## Son2021 — M5/M6

[Comparison of Pharmacokinetics and Anti-Pulmonary Fibrosis-Related Effects of Sulforaphane and Sulforaphane N-acetylcysteine](https://www.mdpi.com/1999-4923/13/7/958)。Full text Tables1/2 and Fig8。

Parent-specific rat IV/PO SFN PK supports a frozen linear benchmark and held-out dose tests. High-dose nonlinear exposure and ambiguous time annotation limit the minimal model; no nasal-to-brain coefficients derived.

## Zhang2023 — M7

[N-acetylcysteine improves autism-like behavior by recovering autophagic deficiency and decreasing Notch-1/Hes-1 pathway activity](https://pmc.ncbi.nlm.nih.gov/articles/PMC10525405/)。Full text。

Specific VPA rat/SH-SY5Y context supports pathway association. Cell treatment 2 mM for 2 h is a nominal bath exposure, not EC50, brain concentration or clinical threshold.

## Danilov2009 — M7

[Sulforaphane protects astrocytes against oxidative stress and delayed death caused by oxygen and glucose deprivation](https://pmc.ncbi.nlm.nih.gov/articles/PMC2657190/)。Full text。

Rat cortical astrocytes: 5 uM SFN for 48 h before OGD; 2.5 uM for 48 h after OGD. These are distinct exposure protocols, not EC50 values or a nasal/ASD threshold.

## Goffin2010 — M2/M3

[Understanding the physiology of Lactobacillus plantarum at zero growth](https://pmc.ncbi.nlm.nih.gov/articles/PMC2964122/)。Full text。

Resource-dependent L. plantarum metabolism and nitrogen pathways motivate finite-resource accounting; no matching L168 nasal parameter values extracted.

## Aggarwal2026 — M3

[Engineered commensals for metabolic modulation of the gut-liver-brain axis](https://pubmed.ncbi.nlm.nih.gov/42034052/)。PubMed abstract accessed。

Engineered WCFS1 in preclinical hepatic encephalopathy links ammonia assimilation/BCAA biosynthesis and Gln utilization. Different strain, route and host disease; quantitative methods/data not accessed.

## Assay2023 — M5/M6

[Bioavailable Sulforaphane Quantitation in Plasma by LC–MS/MS Is Enhanced by Blocking Thiols](https://pmc.ncbi.nlm.nih.gov/articles/PMC10472501/)。EuropePMC full text XML。

Thiol conjugate dissociation and sample processing can affect what an SFN assay measures. Record extraction/derivatization and distinguish native free from assay-recoverable SFN.

## Peking2025 — validation methodology

[Peking iGEM 2025 Model and Results](https://2025.igem.wiki/peking/model/)。Model and Results read; code not rerun。

Borrow modular validation and transparent negative controls. Published AiiA parameter table uses 9.6e-3 um2/s; its stated Stokes–Einstein inputs give about 96.2 um2/s, requiring a unit/version explanation.

## 未能建立的关键证据

尚无 L168 四构建体鼻部产率、氨净处理动力学、菌可及表面 PS、SFN/NAC 母体鼻给脑 ECF 或脑暴露—通路剂量响应数据。未找到不代表不存在：本轮检索不是系统综述。GPX4/铁死亡及 IL6/TNF 的匹配定量曲线未完成提取，具名多通路网络暂缓。没有充分理由设定 EC50 或为获得疗效提升转运率。

## 真实数据与验证界限

Son Table1 与 Kurano Fig2 提供可重用定量基准，原始作者个体数据未获得；SAS 左删失汇总提供约束；两篇细胞研究提供明确的名义处理条件。没有任何匹配的独立研究验证集完成检验。完整留组的同论文比较与外部验证必须分开。


<!-- V02 -->

## v0.2 可追溯补充

参见 [证据审查](evidence_dossier.md)、[全部应用数据](data_atlas.md)、[参数逐项说明](parameter_catalog.md)、[方程与来源对应表](tables/equation_evidence_map.csv)、[数据展示页](evidence_report.html)。Danilov预处理5 μM与后处理2.5 μM已分开；同论文留组比较仍不是独立研究验证。
