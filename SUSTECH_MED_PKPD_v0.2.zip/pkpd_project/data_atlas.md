# 模型实际使用的数据与原始研究条件

这是已纳入项目的全部观测记录和背景约束。数字化均值不是作者原始个体数据；不可读点保留为空。原图保存在 validation_datasets，坐标变换见 scripts/extract_data.py。文献机制存在不等于L168鼻部参数已测定。

## 数据用途与来源

| dataset_id | source | original_file | processed_file | extraction | processing_code | variable | conditions | uncertainty | purpose | directly_comparable | limitations | source_url | source_location | comparison_level |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| SON_T1 | Son2021 | literature_sources/Son2021.html | calibration_datasets/Son2021_calibration.csv;validation_datasets/Son2021_heldout.csv | exact table/text | scripts/extract_data.py | parent SFN PK summaries | male SD rats 7-8 weeks n=4 | published SD/SE plus pixel error where available | IV and PO0.1 calibration; PO0.2/0.5 heldout | only specified study endpoint | within-study; no nasal/brain mapping | https://www.mdpi.com/1999-4923/13/7/958 | Table1 | calibration/retrospective reproduction |
| SON_IV | Son2021 | literature_sources/Son2021.html;validation_datasets/Son2021_figure.jpg | validation_datasets/Son2021_IV_digitized.csv | digitized_manual | scripts/extract_data.py | plasma parent SFN | IV 0.1 mg/kg | published SD/SE plus pixel error where available | same-study curve reproduction | only specified study endpoint | approx means; SD not digitized; figure h/min mismatch | https://www.mdpi.com/1999-4923/13/7/958 | Fig8a | calibration/retrospective reproduction |
| SON_PO05 | Son2021 | literature_sources/Son2021.html;validation_datasets/Son2021_figure.jpg | validation_datasets/Son2021_PO05_digitized.csv | digitized_manual | scripts/extract_data.py | plasma parent SFN | PO0.5 mg/kg rats | published SD/SE plus pixel error where available | heldout_condition_subset | only specified study endpoint | 4 early markers unresolved; no complete curve score | https://www.mdpi.com/1999-4923/13/7/958 | Fig8b; readable late subset | within-study holdout |
| KUR_FREE | Kurano2022 | literature_sources/Kurano2022.html;validation_datasets/Kurano2022_figure.jpg | validation_datasets/../calibration_datasets/Kurano2022_free_NAC.csv | digitized_manual | scripts/extract_data.py | total 14C plasma %ID/mL | ddY free NAC n=6 or 7 | published SD/SE plus pixel error where available | calibration | only specified study endpoint | empirical decay only; postdose t0 | https://www.mdpi.com/1999-4923/14/12/2590 | Fig2A open circles | calibration/retrospective reproduction |
| KUR_MIC | Kurano2022 | literature_sources/Kurano2022.html;validation_datasets/Kurano2022_figure.jpg | validation_datasets/Kurano2022_micelle.csv | digitized_manual | scripts/extract_data.py | total 14C plasma %ID/mL | ddY micelle NAC n=6 or 7 | published SD/SE plus pixel error where available | heldout_group | only specified study endpoint | same study; formulation different; not parent or brain | https://www.mdpi.com/1999-4923/14/12/2590 | Fig2A closed circles | within-study holdout |
| SAS | Zolnourian2025 | literature_sources/Zolnourian2025.html | validation_datasets/human_SAS_constraints.csv | exact table/text | scripts/extract_data.py | LCMS parent SFN and conjugates | oral/NG SFX-01 SAH humans | published SD/SE plus pixel error where available | plausibility_constraint_not_scored | only specified study endpoint | censored; no individual data; no matched model | https://link.springer.com/article/10.1007/s12975-024-01278-1 | Results CSF levels; Fig3 LLOQ caption | context only |
| PD_CTX | Danilov2009;Zhang2023 | literature_sources/Danilov2009.html;literature_sources/Zhang2023.html | validation_datasets/PD_exposure_contexts.csv | exact table/text | scripts/extract_data.py | nominal extracellular drug | cell models | published SD/SE plus pixel error where available | mechanism_context_not_validation | only specified study endpoint | not ECF/intracellular exposure | https://pmc.ncbi.nlm.nih.gov/articles/PMC2657190/; https://pmc.ncbi.nlm.nih.gov/articles/PMC10525405/ | Danilov pre/post protocols; Zhang cell culture | context only |
| DAN_F6 | Danilov2009 | literature_sources/Danilov2009.html | validation_datasets/Danilov2009_Fig6_text.csv | exact_text_transcription | scripts/enhance_evidence.py | cell death percent | rat cortical astrocytes; post-OGD 2.5uM SFN 48h | published mean ± SEM; n=8–9; no individual data | context_only_not_scored | not comparable to generic response_S | one treated dose; cannot identify EC50/Hill/time constant | https://pmc.ncbi.nlm.nih.gov/articles/PMC2657190/ | Results C, Fig6 | context only |

## SON_TABLE

文件：[validation_datasets/Son2021_Table1.csv](validation_datasets/Son2021_Table1.csv)

| route | dose_mg_kg | AUC_last_ug_min_mL | AUC_last_SD | AUC_inf_ug_min_mL | AUC_inf_SD | half_life_min | half_life_SD | Cmax_ug_mL | Cmax_SD | Tmax_min | Tmax_SD | reported_F_percent | CL_mL_min_kg | Vss_mL_kg |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| IV | 0.1 | 2.35 | 0.154 | 2.47 | 0.205 | 61.3 | 36.2 |  |  |  |  | 0 | 40.7 | 2268 |
| PO | 0.1 | 1.85 | 0.377 | 1.92 | 0.411 | 41.9 | 7.6 | 0.036 | 0.01 | 15 | 0 | 77.8 |  |  |
| PO | 0.2 | 3.16 | 0.073 | 3.57 | 0.253 | 197.7 | 169 | 0.065 | 0.012 | 5 | 0 | 72.4 |  |  |
| PO | 0.5 | 29.8 | 8.64 | 31 | 8.89 | 320 | 75.4 | 0.143 | 0.035 | 30 | 18.4 | 251.4 |  |  |

## SON_IV

文件：[validation_datasets/Son2021_IV_digitized.csv](validation_datasets/Son2021_IV_digitized.csv)

| time_min | value_ng_mL | pixel_x | pixel_y | pixel_log10_uncertainty | analyte | extraction | purpose |
|---|---|---|---|---|---|---|---|
| 1 | 105.0211079636667 | 83 | 81 | 0.06382978723404255 | parent SFN by LC-MS/MS | digitized_manual | reproduction_same_study_not_independent |
| 5 | 58.33879397552119 | 88 | 93 | 0.06382978723404255 | parent SFN by LC-MS/MS | digitized_manual | reproduction_same_study_not_independent |
| 15 | 34.034148825183074 | 99 | 104 | 0.06382978723404255 | parent SFN by LC-MS/MS | digitized_manual | reproduction_same_study_not_independent |
| 30 | 22.9986385396121 | 117 | 112 | 0.06382978723404255 | parent SFN by LC-MS/MS | digitized_manual | reproduction_same_study_not_independent |
| 45 | 14.090816855117318 | 134 | 122 | 0.06382978723404255 | parent SFN by LC-MS/MS | digitized_manual | reproduction_same_study_not_independent |
| 60 | 9.521895354084075 | 151 | 130 | 0.06382978723404255 | parent SFN by LC-MS/MS | digitized_manual | reproduction_same_study_not_independent |
| 120 | 2.5366194557577995 | 220 | 157 | 0.06382978723404255 | parent SFN by LC-MS/MS | digitized_manual | reproduction_same_study_not_independent |
| 180 | 1.6321721285632753 | 289 | 166 | 0.06382978723404255 | parent SFN by LC-MS/MS | digitized_manual | reproduction_same_study_not_independent |
| 240 | 1.2775649214671143 | 358 | 171 | 0.06382978723404255 | parent SFN by LC-MS/MS | digitized_manual | reproduction_same_study_not_independent |

## SON_PO05

文件：[validation_datasets/Son2021_PO05_digitized.csv](validation_datasets/Son2021_PO05_digitized.csv)

| time_min | value_ng_mL | pixel_x | pixel_y | pixel_log10_uncertainty | analyte | extraction | purpose |
|---|---|---|---|---|---|---|---|
| 15 |  |  |  | 0.061855670103092786 | parent SFN by LC-MS/MS | unresolved_marker_overlap | heldout_condition_subset_not_whole_curve |
| 30 |  |  |  | 0.061855670103092786 | parent SFN by LC-MS/MS | unresolved_marker_overlap | heldout_condition_subset_not_whole_curve |
| 45 |  |  |  | 0.061855670103092786 | parent SFN by LC-MS/MS | unresolved_marker_overlap | heldout_condition_subset_not_whole_curve |
| 60 |  |  |  | 0.061855670103092786 | parent SFN by LC-MS/MS | unresolved_marker_overlap | heldout_condition_subset_not_whole_curve |
| 120 | 63.69769416995303 | 508 | 85 | 0.061855670103092786 | parent SFN by LC-MS/MS | digitized_manual | heldout_condition_subset_not_whole_curve |
| 180 | 45.68712340164291 | 520 | 92 | 0.061855670103092786 | parent SFN by LC-MS/MS | digitized_manual | heldout_condition_subset_not_whole_curve |
| 240 | 29.800723235589526 | 532 | 101 | 0.061855670103092786 | parent SFN by LC-MS/MS | digitized_manual | heldout_condition_subset_not_whole_curve |
| 480 | 13.942154687651545 | 579 | 117 | 0.061855670103092786 | parent SFN by LC-MS/MS | digitized_manual | heldout_condition_subset_not_whole_curve |
| 1440 | 2.646551883316156 | 770 | 152 | 0.061855670103092786 | parent SFN by LC-MS/MS | digitized_manual | heldout_condition_subset_not_whole_curve |

## KUR_ALL

文件：[validation_datasets/Kurano2022_all_digitized.csv](validation_datasets/Kurano2022_all_digitized.csv)

| dataset | group | time_min | value | SE_approx | pixel_uncertainty | unit | analyte | pixel_x | pixel_y | extraction | purpose |
|---|---|---|---|---|---|---|---|---|---|---|---|
| Kurano2022_Fig2A | free_NAC | 0 | 1.569767441860465 | 0.09966777408637874 | 0.024916943521594685 | %ID/mL plasma | total 14C signal; not intact NAC | 92 | 154 | digitized_manual | calibration |
| Kurano2022_Fig2A | free_NAC | 3 | 1.43687707641196 | 0.1287375415282392 | 0.024916943521594685 | %ID/mL plasma | total 14C signal; not intact NAC | 102 | 170 | digitized_manual | calibration |
| Kurano2022_Fig2A | free_NAC | 15 | 1.1710963455149501 | 0.09551495016611296 | 0.024916943521594685 | %ID/mL plasma | total 14C signal; not intact NAC | 141 | 202 | digitized_manual | calibration |
| Kurano2022_Fig2A | free_NAC | 30 | 0.813953488372093 | 0.08305647840531562 | 0.024916943521594685 | %ID/mL plasma | total 14C signal; not intact NAC | 191 | 245 | digitized_manual | calibration |
| Kurano2022_Fig2A | free_NAC | 60 | 0.6146179401993356 | 0.12043189368770764 | 0.024916943521594685 | %ID/mL plasma | total 14C signal; not intact NAC | 290 | 269 | digitized_manual | calibration |
| Kurano2022_Fig2A | free_NAC | 90 | 0.5066445182724253 | 0.09551495016611296 | 0.024916943521594685 | %ID/mL plasma | total 14C signal; not intact NAC | 389 | 282 | digitized_manual | calibration |
| Kurano2022_Fig2A | micelle | 0 | 1.802325581395349 | 0.1536544850498339 | 0.024916943521594685 | %ID/mL plasma | total 14C signal; not intact NAC | 92 | 126 | digitized_manual | heldout_group |
| Kurano2022_Fig2A | micelle | 3 | 1.6528239202657806 | 0.24916943521594684 | 0.024916943521594685 | %ID/mL plasma | total 14C signal; not intact NAC | 102 | 144 | digitized_manual | heldout_group |
| Kurano2022_Fig2A | micelle | 15 | 1.004983388704319 | 0.1287375415282392 | 0.024916943521594685 | %ID/mL plasma | total 14C signal; not intact NAC | 141 | 222 | digitized_manual | heldout_group |
| Kurano2022_Fig2A | micelle | 30 | 0.8222591362126246 | 0.132890365448505 | 0.024916943521594685 | %ID/mL plasma | total 14C signal; not intact NAC | 191 | 244 | digitized_manual | heldout_group |
| Kurano2022_Fig2A | micelle | 60 | 0.6229235880398671 | 0.132890365448505 | 0.024916943521594685 | %ID/mL plasma | total 14C signal; not intact NAC | 290 | 268 | digitized_manual | heldout_group |
| Kurano2022_Fig2A | micelle | 90 | 0.5066445182724253 | 0.09551495016611296 | 0.024916943521594685 | %ID/mL plasma | total 14C signal; not intact NAC | 389 | 282 | digitized_manual | heldout_group |

## SAS

文件：[validation_datasets/human_SAS_constraints.csv](validation_datasets/human_SAS_constraints.csv)

| analyte | location | statistic | value | unit | samples_above_LLOQ | samples_tested | LLOQ_ng_mL |
|---|---|---|---|---|---|---|---|
| SFN | plasma | AUC_last | 16.2 | ng h/mL |  |  | 5 |
| SFN-GSH | plasma | AUC_last | 277 | ng h/mL |  |  | 10 |
| SFN-NAC | plasma | AUC_last | 415 | ng h/mL |  |  | 5 |
| SFN | CSF substudy | above_LLOQ_count |  | count | 5 | 95 | 5 |
| SFN-GSH | CSF substudy | above_LLOQ_count |  | count | 5 | 96 | 10 |
| SFN-NAC | CSF substudy | above_LLOQ_count |  | count | 0 | 96 | 5 |

## PD_CTX

文件：[validation_datasets/PD_exposure_contexts.csv](validation_datasets/PD_exposure_contexts.csv)

| source | analyte | nominal_concentration_uM | time_h | model | endpoint | purpose |
|---|---|---|---|---|---|---|
| Danilov2009 | SFN | 5 | 48 | rat cortical astrocytes; 48h SFN PRE-treatment before OGD | NRF2/NQO1 and protection | context_not_EC50_or_brain_threshold |
| Zhang2023 | NAC | 2000 | 2 | SH-SY5Y VPA | Notch/autophagy related | context_not_EC50_or_brain_threshold |
| Danilov2009 | SFN | 2.5 | 48 | rat cortical astrocytes; POST-treatment during REOX | Fig6 cell death | context_not_EC50_or_brain_threshold |

## DAN_F6

文件：[validation_datasets/Danilov2009_Fig6_text.csv](validation_datasets/Danilov2009_Fig6_text.csv)

| dataset_id | condition | nominal_SFN_uM | treatment_timing | cell_death_percent | SEM_percent | n | source_id | source_location | extraction | purpose |
|---|---|---|---|---|---|---|---|---|---|---|
| DAN_F6 | vehicle_sham | 0 | no OGD | 2.3 | 0.5 | 8–9 (Fig6 caption) | Danilov2009 | Results C and Fig6; Statistical Analysis defines mean ± SEM | exact_text_transcription | descriptive_PD_context_not_calibration_or_validation |
| DAN_F6 | SFN_sham | 2.5 | no OGD | 3.4 | 0.5 | 8–9 (Fig6 caption) | Danilov2009 | Results C and Fig6; Statistical Analysis defines mean ± SEM | exact_text_transcription | descriptive_PD_context_not_calibration_or_validation |
| DAN_F6 | vehicle_OGD | 0 | after 4h OGD; 48h REOX | 37.5 | 1.4 | 8–9 (Fig6 caption) | Danilov2009 | Results C and Fig6; Statistical Analysis defines mean ± SEM | exact_text_transcription | descriptive_PD_context_not_calibration_or_validation |
| DAN_F6 | SFN_OGD | 2.5 | after 4h OGD; 48h REOX | 25.6 | 2.5 | 8–9 (Fig6 caption) | Danilov2009 | Results C and Fig6; Statistical Analysis defines mean ± SEM | exact_text_transcription | descriptive_PD_context_not_calibration_or_validation |

## 数值处理与比较边界

Kurano Fig2A：x轴0–90 min，y轴0–2.5 %ID/mL；y=(343-py)*2.5/301，误差条SE由像素近似读取，另设±3像素敏感性。时间0是给药完成后的首点，不是鼻腔开始输入的瞬时。

Son Fig8：纵轴log10；IV y=10**(3-(py-35)*4/188)，PO y=10**(3-(py-27)*4/194)。原图横轴写Time(h)，方法与表1使用min，当前按min解释并保留冲突。此冲突使曲线级验证只能作为条件性比较。

SAS低于LLOQ是左删失，不应置零或把图中LLOQ/2当成测量。只汇总检测计数，不拟合脑暴露。Danilov单剂量终点不是Hill曲线。

新转录的Danilov后处理组：37.5%降至25.6%，差11.9个百分点；相对下降31.73%。这是原研究观测的描述统计，不是本项目PD预测；未估计该差值置信区间，也未据此设定EC50。
