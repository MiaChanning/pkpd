# Source access record supplement

Initial attempts to EuropePMC XML for Zhang2023, Mi2010 and Danilov2009 returned HTTP500. Subsequent PMC original-article HTML retrieval succeeded and supplied their `.html`/`.txt` archives. Goffin2010 PMC HTML retrieval also succeeded. Some PubMed requests in the initial batch returned short challenge pages, now flagged in archive_manifest.json; they are not evidence. Web retrieval of PubMed abstracts/metadata for Aggarwal2026/Hong2026 and indexed publisher information for DeBoeck/Shen was stored separately in web_retrievals.json; full quantitative data were not claimed.

MDPI-res direct PNG retrieval returned HTTP403. The original Son2021 Figure8 and Kurano2022 Figure2 were retrieved from the corresponding PMC article-image links and archived as JPEG. URLs were obtained from the actual PMC HTML, not synthesized data:

- https://cdn.ncbi.nlm.nih.gov/pmc/blobs/23e9/8309207/448a881bbddc/pharmaceutics-13-00958-g008.jpg
- https://cdn.ncbi.nlm.nih.gov/pmc/blobs/ee61/9785447/913c21591621/pharmaceutics-14-02590-g002.jpg

The `.html` archives for primary full text correspond to the publisher/PMC URLs in references.bib. No author raw participant-level dataset or complete supplement was downloaded. Original calibration/validation means are literature figure estimates, not measurements from SUSTECH-MED.
