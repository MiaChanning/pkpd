# Results — verified calculations, literature comparisons and unresolved barriers

## Numerical checks

All 15 implemented checks passed. The nitrogen-ledger drift was 2.58e-14 nmol N; the SFN and NAC equivalent drifts were below 1e-15 nmol in the nonzero engineering fixture. With effective brain-to-surface exchange set to zero, nasal bacteria produced no additional brain metabolite change. With no SFN/NAC source, drug exposure remained zero. These results verify the implementation of the selected equations, not the biological efficacy of the proposed strains.

## Literature comparisons and retained failure

For the held-out micelle group in Kurano2022, all six digitized plasma radiolabel means were within 1.27-fold of the frozen signal model; log10-RMSE was 0.071. The predicted and digitized AUC0–90 were 76.85 and 73.46 %ID/mL·min. Not every point met a stricter approximate two-SE criterion. This comparison concerns total carbon-14 signal, not intact NAC in brain ECF, and remains within one study.

The frozen linear SFN benchmark did not explain the high-dose oral tail in Son2021. At 0.5mg/kg, predicted AUCinf was 9.56 versus 31.0 μg·min/mL, and predicted half-life was 38.63 versus 320min. These summaries fell within a permissive ten-fold screen, yet the readable late concentration points failed it. We retained the failure rather than modifying parameters against the test data. Figure time labeling and a sampling/Tmax inconsistency are recorded in the extraction notes.

## Conditional design boundaries

The coupling model provides scenarios, not measured brain concentrations. A perfect-sink, single-host-pool steady-state analysis requires an exchange-to-homeostasis ratio of at least 0.111 for a hypothetical 10% change. This is a research comparison, not a physiological estimate or clinical target. At zero delivery fraction, no finite production rate reaches a positive brain-exposure target.

Within the arbitrary engineering fixture, SFN brain AUC is most sensitive to production and bacterial loss among the tested local perturbations. Because these parameters are unmeasured, this ranking cannot establish a real optimal strain ratio. No robust optimum was evaluated.

## Evidence status and next experiments

No matched independent-study validation or target-strain wet-lab calibration has been completed. The key missing links are actual extracellular parent-drug production, nitrogen-product identity, nasal residence, accessible surface exchange and chemically specific brain exposure. Next work should quantify strain-resolved counts, Gln/ammonia/Glu and nitrogen products, and SFN/NAC production and stability. Parameters should then be frozen before predicting a fully held-out mixed-strain condition. No ASD clinical improvement is inferred from these calculations.


<!-- V02 -->

## v0.2 evidence and data links

See [evidence dossier](evidence_dossier.md), [complete data atlas](data_atlas.md), [equation/source mapping](tables/equation_evidence_map.csv), and [evidence report](evidence_report.html). Danilov2009 pre-treatment uses 5 uM; post-treatment uses 2.5 uM. These protocols do not define EC50. The generic response has not been fitted.
