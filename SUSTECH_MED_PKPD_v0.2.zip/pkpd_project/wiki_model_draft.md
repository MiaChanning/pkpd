# Model — an evidence-audited four-function research framework

We developed an amount-based model to connect four candidate bacterial functions with nasal residence, nitrogen metabolism, chemical availability and conditional host exposure. The starting materials describe a proposed system; no target-strain wet-lab measurements were supplied. Accordingly, this implementation is a numerically verified research framework, not a validated physiological prediction of the four L168 strains.

## Mechanisms and model scope

Three deposition fractions define the initial accessible bacterial count. Subsequent residence is represented by one effective surface pool. Resource-limited growth and functional precursor pools prevent unlimited production. Gln contains two nitrogen atoms, and ammonia assimilation transfers nitrogen into an explicit product ledger. The precise target-strain route and products remain unconfirmed.

Brain ECF, CSF and nasal surface pools exchange amounts through paired fluxes. Normal CSF lymphatic drainage leaves the host model; it is not redirected to surface bacteria. Hong2026 supports a deeper lymphatic route, while Melin2020 provides a human tracer limitation. The effective surface-exchange parameter is therefore unknown and includes zero.

SFN and NAC have distinct free, transit, systemic, brain and CSF pools. A reversible 1:1 conjugation reaction transfers both drug equivalents into SFN-NAC. Mi2010 motivates chemical interference, but does not determine nasal reaction rates. Each transfer is debited and credited once. A two-stage Erlang chain represents delay mathematically. A generic response interface is uncalibrated and is not interpreted as a quantitative named pathway or clinical score.

## Parameters and validation

Every coupled-model coefficient is registered. Nonzero nasal parameters are explicit engineering fixtures, not inferred human values. A–E provenance is kept separate from validation status. Time is in hours, amounts in nmol and volumes in mL; nmol/mL equals micromolar concentration.

We tested nonnegativity, nitrogen and drug-equivalent balances, finite resources, source-free exposure, zero-exchange controls, analytic residence/two-pool/Erlang benchmarks and solver convergence. Literature PK benchmarks were evaluated in their original conditions and kept separate from the uncalibrated nasal model. Son2021 low-dose data constrain a frozen linear SFN benchmark; other dose conditions test its limits. Kurano2022 free-formulation plasma radiolabel data calibrate a two-parameter signal model, with the other formulation held out. These are retrospective within-study comparisons, not independent-study validation.

Measurement-error propagation is confined to the literature signal benchmark. Unconstrained physiological parameters are explored through deterministic scenarios and reverse feasibility equations, without assigning population distributions. Peking2025 motivates this layered reporting; its equations and success claims were not imported.

Code, input records, extraction coordinates, configurations, tests and data-role registries are included. References use the keys in references.bib. Figure captions explicitly distinguish archived literature observations from engineering scenarios.


<!-- V02 -->

## v0.2 evidence and data links

See [evidence dossier](evidence_dossier.md), [complete data atlas](data_atlas.md), [equation/source mapping](tables/equation_evidence_map.csv), and [evidence report](evidence_report.html). Danilov2009 pre-treatment uses 5 uM; post-treatment uses 2.5 uM. These protocols do not define EC50. The generic response has not been fitted.
