# 最小模型方程、单位和接口

版本 0.1。代码 `src/model.py` 是方程的可执行定义；所有数值在 `configs/*.json` 和登记表中。联立模型中没有从文献自动填入的鼻部未知生理常数。

## 单位与变量

时间 h；物质量 nmol；体积 mL；浓度 n/V 为 nmol/mL = μM。活菌变量 b=N/count_scale；count_scale=10⁸ CFU 是坐标缩放，并非鼻喷推荐量。非零配置为纯工程算例，各池体积均为 1 mL，不表示人体脑 ECF、CSF 或鼻液体积。

## M1–M2：沉积、驻留与资源

三区域沉积仅用于初值：b_i(0)=b_total w_i Σ_r f_dep,r s。由于缺少空间数据，沉积后合并为一个菌可及表面池；未实现三区间输运、PDE 或区域特异黏附。未沉积比例与失活部分为模型外初始损失。

g_i=μ_i b_i R/(K_R+R)/(1+Σb_i/K)，db_i/dt=g_i−(d_i+k_loss)b_i。

dR/dt=−c_growth Σg_i。默认 μ_i=0，不推定鼻部支持增长。一阶 k_loss 合并活菌驻留损失，不再在 M3/M5 重复扣除菌量；小分子的黏液丢失是独立通量 k_muc n。

## M3：含氮反应

v_G=q_G b_G C_G/(K_G+C_G) P_G/(K_P+P_G)；v_A 类似。每个功能资源池 dP/dt=−相应功能通量，保证有限功能源。P 是抽象可用前体当量，不等于已经解析的碳/ATP 网络。

Gln 去向：−v_G Gln，+v_G Glu，+βv_G NHx，+(1−β)v_G 未解析产物 N。每个 Gln 含两个 N；Glu、NHx 各含一个。氨同化 −v_A NHx，+v_A 固定产物 N。β∈[0,1] 不会丢失氮。

固定产物 N 是已转移但未分辨的 N 原子账本，不指定为缬氨酸，也不指定为生物量。真实功能路线须由湿实验确认。Glu 随黏液丢失进入 N_exit，固定产物暂留账本；不假定产物回流脑内。

## M4：宿主量池

J_BC=PS_BC(n_B/V_B−n_C/V_C)，J_CN=PS_eff(n_C/V_C−n_N/V_N)。当前分配系数固定为 1，只作算例；不同分析物有独立参数。

dn_B/dt=S_B−k_h n_B−J_BC；dn_C/dt=J_BC−Q_C n_C/V_C−J_CN；dn_N/dt=J_CN−k_muc n_N+M3反应。

正常 CSF 外流只进入宿主丢失账本，不进入鼻表面菌池。S_B 先在零表面交换稳态算出：C_C0=PS_BC C_B0/(PS_BC+Q_C)，S_B=k_h V_B C_B0+PS_BC(C_B0−C_C0)。各交换情景的有菌/无菌组使用相同 S_B；初值由该情景无菌线性系统的稳态求得，避免归因于基线漂移。

N_total=2Σ(Gln池)+Σ(NHx池)+Glu+固定N+累计N_exit−累计N_input。这个扩展账本应保持初值；宿主不是封闭系统，输入与输出必须纳入。

当 PS_eff=0，鼻侧反应没有影响脑侧的路径；有菌/无菌脑轨迹严格重合。

## M5：生产与缀合

R_S=q_S b_S P_S/(K_P+P_S)，R_N 类似；dP_j/dt=−R_j。没有前体或有效菌量时，生产为零。

r=k_f n_S n_N/V_N−k_r n_SN。自由 SFN 和 NAC 均减去 r，缀合物加 r。缀合物的丢失 k_conj+k_muc 同时加入两个药物当量损失账本。当前缀合物跨膜运输及胞内释放缺少证据，暂不实现；不能把这部分视为无活性已证实。

## M6：每药七个量池

鼻液、T1、T2、血浆、脑ECF、CSF、累计丢失。鼻吸收 J_abs=k_abs n_nose；只在鼻量方程扣一次。f_dir+f_sys≤1，余量进入损失。

dT1/dt=f_dir J_abs−k_tr T1；dT2/dt=k_tr(T1−T2)，k_tr=2/τ。两个转运池构成 Erlang 分布，平均时滞 τ；不宣称对应两处解剖结构。

J_PB=PS_PB(C_P−C_B)，J_BC,drug=PS_BC,drug(C_B−C_C)。同一跨池通量一处减、一处加。血浆/脑/CSF分别有一阶清除；均进入对应当量累计损失。未加入肠道再吸收和多器官代谢。

每药守恒式：Σ(七量池)+n_SN−累计生产=初始当量。鼻降解、黏液清除、吸收不可用分流与宿主清除都有明确账目。

## M7：未标定的通用响应接口

dE_j/dt=[C_B,j/(EC_j+C_B,j)−E_j]/τ_PD。

E∈[0,1] 为软件响应代理，不是 NRF2、GSH、GPX4、Notch、真实自噬通量或临床得分。EC_S=EC_N=1 μM 是纯算例数值，不由 5 μM SFN 或 2 mM NAC 文献处理条件推算。具名网络无可辨识参数而暂缓。

## 独立的文献基准

`src/literature_pk.py` 的大鼠口服 SFN 模型：C(t)=F D k_a/[V(k_a−k_e)]·(exp(−k_e t)−exp(−k_a t))，k_e=CL/V。该基准时间单位为 min，并与联立模型明确隔离。

用 IV CL/Vss 与低剂量 PO F/Tmax 冻结参数；Vss=单室V是近似，不把终末半衰期和 CL/Vss 偷换为相同速率。高剂量失败保留。

Kurano 基准 y=A exp(−kt) 拟合总14C血浆信号，只有两个有效参数。它不是母体 NAC 的 PK 腔室模型，不能传入联立模型作为脑运输率。

## 反向可行性

理想单宿主池、恒源、无限鼻汇、稳态下 δ=e/(h+e)，故 e_required/h=δ/(1−δ)。真实多池、有限汇和宿主补偿通常更苛刻；这个式子不是解剖 PS 的测量值。

理想稳态药物输入 R_required=C_target V_B k_B/(f_delivered a_available)；f 或 a 为零时输入要求为无穷。文献名义细胞处理浓度若用于指定研究目标，必须声明它不是脑内有效阈值。
