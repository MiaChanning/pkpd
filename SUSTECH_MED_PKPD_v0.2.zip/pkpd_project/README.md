# SUSTECH-MED evidence-audited PK–PD research model v0.1

This is a runnable, numerically checked minimum framework plus literature benchmark analyses. **It is not an externally validated L168 nasal/brain efficacy model.** Read results_summary.md (Chinese) first, then model_audit.md and validation_report.md.

## Run offline

```bash
python run_all.py
```

Python 3.11+ with numpy, scipy, matplotlib. Exact tested package versions are in requirements-lock.txt. No requests/pandas/ML dependency is needed. Windows: use `py run_all.py` if `python` is unavailable. Inputs are archived; no network is needed for the main run. Source refetch is separate and optional: `python scripts/fetch_sources.py`; it can fail due to provider access restrictions and must not replace evidence with empty pages.

run_all rebuilds explicit fixture configs, transcribes/digitizes the archived data, executes tests, freezes study-specific parameters, scores held-out conditions, propagates approximate measurement error, generates figures and reports. It only writes generated files within this project; uploaded inputs and archived original measurements are not overwritten. It does not automatically update/fit target-strain parameters because no corresponding raw data were supplied.

## Contents

- src/model.py: coupled M1–M6 amount model and generic uncalibrated response.
- src/literature_pk.py: separate study-specific PK/signal benchmarks.
- configs/: zero-unverified-source default and nonzero engineering fixture, plus frozen benchmark fits.
- parameter_registry.csv / parameter_notes.md: all parameters, units, provenance and limits.
- calibration_datasets/ and validation_datasets/: distinct roles; exact transcriptions and approximate digitization. Dataset metadata in validation_registry.csv.
- inputs/: untouched uploaded proposals. No pre-existing code or wet data was present.
- literature_sources/: downloaded original texts, failed-access log, hashes; short challenge pages are explicitly not scientific evidence.
- figures/: seven SVG and PNG figures; captions.md.
- tables/: computed trajectories, per-point comparisons, all failures, sensitivities and module status.
- tests/ and tables/test_log.txt: numerical checks. Spatial grid convergence is inapplicable to this ODE model.
- reports: scientific audit, review, validation, iteration, uncertainty, limitations, Chinese summary and English Wiki drafts.

## Use boundaries

1. Fixture numbers including 1mL volumes are chosen software coordinates, not physiological priors or doses. All are E unless an exact coordinate/stoichiometric relation is D.
2. Literature values remain in their original rat/mouse/cell conditions. Total14C signal is never relabeled as intact NAC; oral SFN is never relabeled as nasal PK.
3. Within-study held-out-condition comparisons are not independent-study validation. SFN late-tail failure is preserved. A ten-fold screen is not proof of predictive accuracy.
4. Named PD networks and robust strain optimization are deferred for insufficient identifiable data. No clinical benefit/safety prediction is made.

For wet-lab data and observation mapping, see data_requirements.md. Parameter edits invalidate frozen report/manifest hashes until rerun. Source archives are included for traceability; respect each original publisher's license when redistributing text/figures.


<!-- V02 -->

## v0.2 可追溯补充

参见 [证据审查](evidence_dossier.md)、[全部应用数据](data_atlas.md)、[参数逐项说明](parameter_catalog.md)、[方程与来源对应表](tables/equation_evidence_map.csv)、[数据展示页](evidence_report.html)。Danilov预处理5 μM与后处理2.5 μM已分开；同论文留组比较仍不是独立研究验证。

## Windows run instructions

Use `./run_windows.ps1 -PythonPath "C:/path/to/python.exe"` after installing `requirements-lock.txt`. For isolation: create a `.venv` with your Python, then run `.venv/Scripts/python.exe -m pip install -r requirements-lock.txt`. The launcher selects project .venv first, then PATH Python, then the Codex bundled runtime if present. This delivered project excludes dependency binaries; scientific dependencies must be available. Main rebuilding is offline; optional Crossref metadata retrieval is separate.

Model computation version remains 0.1; evidence and data presentation revision is 0.2. Original zip SHA256 is recorded in revision_manifest.json. No target-strain wet measurements were added.
