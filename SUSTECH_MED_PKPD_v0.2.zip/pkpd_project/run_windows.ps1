param([string]$PythonPath = '')
$ErrorActionPreference = 'Stop'
$env:PYTHONUTF8 = '1'
if (-not $PythonPath) {
    $localPython = Join-Path $PSScriptRoot '.venv\Scripts\python.exe'
    $bundledPython = Join-Path $env:USERPROFILE '.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe'
    if (Test-Path -LiteralPath $localPython) { $PythonPath = $localPython }
    elseif (Get-Command python -ErrorAction SilentlyContinue) { $PythonPath = (Get-Command python).Source }
    elseif (Test-Path -LiteralPath $bundledPython) { $PythonPath = $bundledPython }
    else { throw 'Python unavailable. Pass -PythonPath with an installed Python executable.' }
}
$workspaceDeps = Join-Path (Split-Path $PSScriptRoot -Parent) 'python_deps'
if (Test-Path -LiteralPath $workspaceDeps) {
    $env:PYTHONPATH = $workspaceDeps + [IO.Path]::PathSeparator + $env:PYTHONPATH
}
& $PythonPath (Join-Path $PSScriptRoot 'run_all.py')
if ($LASTEXITCODE -ne 0) { throw 'Rebuild failed. Install requirements-lock.txt in your project environment and inspect the error.' }
