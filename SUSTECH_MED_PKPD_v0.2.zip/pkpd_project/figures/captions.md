# Figure captions (v0.1)

Fixture SHA256: 187ffbf6c80223ef58b2ad35cd598fe1c90dca5c83ca63faedb2993c61fbb623

## Figure 1

Architecture: dashed target-setting links are unquantified. Mechanism context: Shen2025/Hong2026/Melin2020/Mi2010. Parameter version: v0.1; configs/engineering_fixture.json, or son_frozen.json/kurano_frozen.json for Figure6. Full sources: references.bib; data: validation_registry.csv. No missing wet-lab observations were synthesized.

## Figure 2

Bacterial engineering fixture and analytic first-order residence. Equal counts/loss rates cause four curves to coincide. No experimental points. Parameter version: v0.1; configs/engineering_fixture.json, or son_frozen.json/kurano_frozen.json for Figure6. Full sources: references.bib; data: validation_registry.csv. No missing wet-lab observations were synthesized.

## Figure 3

Candidate Gln/NHx rates and nitrogen-ledger numerical drift. Chemical stoichiometry is conserved; product route unconfirmed. Parameter version: v0.1; configs/engineering_fixture.json, or son_frozen.json/kurano_frozen.json for Figure6. Full sources: references.bib; data: validation_registry.csv. No missing wet-lab observations were synthesized.

## Figure 4

One-host-pool perfect-sink upper envelope and matched-control coupled scenarios. PS labels are arbitrary perturbations, not measured physiological range. Parameter version: v0.1; configs/engineering_fixture.json, or son_frozen.json/kurano_frozen.json for Figure6. Full sources: references.bib; data: validation_registry.csv. No missing wet-lab observations were synthesized.

## Figure 5

Finite-source SFN/NAC co-production and conjugation; all drug losses accounted. Reaction-rate values are uncalibrated. Mi2010 supplies mechanism context. Parameter version: v0.1; configs/engineering_fixture.json, or son_frozen.json/kurano_frozen.json for Figure6. Full sources: references.bib; data: validation_registry.csv. No missing wet-lab observations were synthesized.

## Figure 6

Frozen SFN high-dose late-tail failure (Son2021); digitized NAC total14C held-out plasma comparison and approximate SE/measurement envelope (Kurano2022). Not brain PD validation. Parameter version: v0.1; configs/engineering_fixture.json, or son_frozen.json/kurano_frozen.json for Figure6. Full sources: references.bib; data: validation_registry.csv. No missing wet-lab observations were synthesized.

## Figure 7

Local elasticity in engineering fixture and dimensionless reverse production requirements. No human optimal strain ratio or probabilistic robustness claim. Parameter version: v0.1; configs/engineering_fixture.json, or son_frozen.json/kurano_frozen.json for Figure6. Full sources: references.bib; data: validation_registry.csv. No missing wet-lab observations were synthesized.


<!-- V02 -->

## v0.2 可追溯补充

参见 [证据审查](evidence_dossier.md)、[全部应用数据](data_atlas.md)、[参数逐项说明](parameter_catalog.md)、[方程与来源对应表](tables/equation_evidence_map.csv)、[数据展示页](evidence_report.html)。Danilov预处理5 μM与后处理2.5 μM已分开；同论文留组比较仍不是独立研究验证。
