# 验证报告（v0.1）

## 证据分层与冻结

validation_plan.md先定义数据角色；这是已看过图和表的回顾性留组，非前瞻注册。联立鼻模型未校准。Son基准只取IV的CL/Vss与PO0.1的F/Tmax；Kurano只用free-NAC组拟合信号衰减。没有利用留出结果重新拟合。

## 内部核验

15项测试通过；完整输出见tables/test_log.txt。实际数值：

```json
{
  "nitrogen_max_drift_nmol": 2.5757174171303632e-14,
  "SFN_equivalent_max_drift_nmol": 8.673617379884035e-18,
  "NAC_equivalent_max_drift_nmol": 3.469446951953614e-17,
  "min_state": 0.0,
  "conservative_max_drug_nmol": 0.0,
  "max_step_change_max_abs": 3.113491341054366e-11,
  "reference_solver_max_abs": 3.113523450294627e-11,
  "zero_exchange_max_brain_difference": 0.0
}
```

这是求解实现核验，不是机制或人体效应验证。没有截断负状态；发现显著负值则报错。无空间模型，空间收敛未评估且不适用。

## 文献SFN基准：未通过完整预测要求

原始Table1，男SD大鼠，LC–MS/MS母体SFN，n=4。单室假设V=Vss，ke=CL/Vss=0.017945 min⁻¹；ka=0.166427 min⁻¹；F=0.778。口服0.2与0.5整剂量组留出。

精确汇总误差见son_heldout_metrics.csv（8个终点全部列出）。所有终点在10倍内，但多个终点不在2倍内。0.5剂量AUC低估3.24倍、终末时间尺度低估8.28倍；5个可读晚期点log-RMSE=4.390，最大Elog=9.362，10倍筛查未通过。早期重叠点缺失而非补造，不称为整条口服曲线数字化验证。

IV9点同研究重现log-RMSE=0.221，10倍筛查通过但2倍未全通过。这些观测与CL/Vss来自同研究，不能叫独立验证。

失败排查：单位按方法改为min并保留图h冲突；原始表核对；剂量和分析物匹配；求解无异常。IV终末半衰期61.3min与CL/Vss单室推得38.63min不同，说明Vss并非唯一终末动力学体积；原研究还报告高剂量非线性和SFN-NAC形成。证据支持继续研究更丰富PK，却不足以唯一拟合其所有速率。本轮不在验证集上增加自由参数直到通过。

另外，方法口服采样从15min开始而0.2表列Tmax5min，尚未解决。reported F高剂量251.4%是相对剂量归一化AUC计算结果，不能当作有界吸收概率输入模型。

## NAC总标记基准：数量级筛查通过，严格误差仍有限制

图2A的6个点均使用；像素轴映射/点位/近似SE在extract_data.py。均值和SE为图像近似，额外像素误差记录；非作者个体原始数据。

冻结拟合A=1.421265 %ID/mL，k=0.012679 min⁻¹。留出的另一制剂组log-RMSE=0.07105，最大Elog=0.10316；6点均过2倍/10倍筛查；AUC差4.63%。首点偏差约2.48 SE，2SE覆盖不是全部通过。

观测方向均为下降；峰值在首个0min时间点，不能检验此前吸收上升/真正达峰时间。仅证明这个简短信号基准对同研究另组有粗量级解释力。母体NAC脑ECF、标记代谢归属、鼻菌持续生产、跨物种与人体均未验证。

## 严格external validation与plausibility

匹配的独立研究external validation：**未完成，证据不足**。L168增长/代谢/生产、人体表面PS、两药自由脑暴露和具名PD：**证据不足**。SAS人CSF低检测率仅作为跨途径暴露限制，不给R分数；BQL留为删失。细胞处理条件不用于EC50拟合。

Peking层级思想用于区分内部数学测试、文献条件比较、工程情景和真实外推。公开AiiA公式复算D≈96.22μm²/s而表中0.0096，相差约10000倍；没有据此导入任何参数，未重跑其仓库。


<!-- V02 -->

## v0.2 可追溯补充

参见 [证据审查](evidence_dossier.md)、[全部应用数据](data_atlas.md)、[参数逐项说明](parameter_catalog.md)、[方程与来源对应表](tables/equation_evidence_map.csv)、[数据展示页](evidence_report.html)。Danilov预处理5 μM与后处理2.5 μM已分开；同论文留组比较仍不是独立研究验证。
